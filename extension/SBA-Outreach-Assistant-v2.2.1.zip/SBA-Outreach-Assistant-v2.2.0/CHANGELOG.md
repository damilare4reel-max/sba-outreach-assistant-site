
### v2.2.1
- Removed the duplicate Help sidebar item; the full How to Use guide is now the single help entry.
- Added automatic outreach recovery/watchdog behavior for interrupted or stalled runs when pending prospects remain.
- Start button now becomes "Resume Automatic Outreach" when unsent work remains or a recoverable error exists.
- Added website-based version checking and an in-app update notification with a stable download link.

### v2.2.0
- New "How to Use" tab in the sidebar -- a real in-app guide for customers covering first-time setup, running a campaign, other features, and common questions. No more figuring it out from scratch.
