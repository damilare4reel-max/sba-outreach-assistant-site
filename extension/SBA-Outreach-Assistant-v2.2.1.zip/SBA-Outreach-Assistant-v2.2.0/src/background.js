const DEFAULTS={
 campaign:{
   region:'US',
   us:{senderName:'',senderTitle:'',senderCompany:'',senderEmail:'',senderPhone:'',senderWebsite:''},
   uk:{senderName:'',senderTitle:'',senderCompany:'',senderEmail:'',senderPhone:'',senderWebsite:''},
   name:'Maps Outreach',serviceContext:'',objective:'Start a relevant business conversation around the selected opportunity.',tone:'Professional',dailyLimit:25,
   contract:null
 },
 settings:{geminiApiKey:'',geminiModel:'gemini-3.5-flash-lite',minDelay:30,maxDelay:60,maxReviews:25},
 prospects:[],stats:{found:0,sent:0,failed:0,skipped:0},gmailConnected:false,paused:false,
 outreach:{running:false,phase:'idle',sent:0,failed:0,processed:0,currentCompany:'',currentEmail:'',currentAction:'',startedAt:null,updatedAt:null,lastResult:'',batches:0,rowsCollected:0,error:'',mapsTabId:null,lastBatchSignature:'',recoveryAttempts:0,lastRecoveryAt:null}
};
const JOB_ALARM='maps-outreach-job';
const RECOVERY_ALARM='maps-outreach-recovery';
const UPDATE_CHECK_ALARM='sba-update-check';
const UPDATE_URL='https://dgtandassociatesuk.tech/extension/version.json';
const RECOVERY_STALE_MS=4*60*1000;
const MAX_RECOVERY_ATTEMPTS=3;


async function getState(){const s=await chrome.storage.local.get(DEFAULTS);return {...DEFAULTS,...s,campaign:{...DEFAULTS.campaign,...(s.campaign||{}),us:{...DEFAULTS.campaign.us,...((s.campaign||{}).us||{})},uk:{...DEFAULTS.campaign.uk,...((s.campaign||{}).uk||{})}},settings:{...DEFAULTS.settings,...(s.settings||{})},outreach:{...DEFAULTS.outreach,...(s.outreach||{})}}}
async function save(o){await chrome.storage.local.set(o)}
function idForMaps(l){let key=l.mapsUrl||l.name||'';try{if(l.mapsUrl){const u=new URL(l.mapsUrl);key=u.origin+u.pathname}}catch{}return btoa(unescape(encodeURIComponent(key.toLowerCase()))).replace(/[^a-z0-9]/gi,'').slice(0,48)}
function activeSender(campaign){return campaign.region==='UK'?campaign.uk:campaign.us}

// ---- Account / plan (Supabase) ----
// background.js is a separate execution context from the popup, so it has
// no access to auth.js's globals -- it reads the session chrome.storage
// left behind by login and talks to Supabase directly.
const SBA_SUPABASE_URL="https://uauvktlbxywlzdmxxzrj.supabase.co";
const SBA_SUPABASE_KEY="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVhdXZrdGxieHl3bHpkbXh4enJqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODk1NTk5NjksImV4cCI6MjEwNTEzNTk2OX0.Qb6Mip2OjAV3VHA-Xd9a-fhytIQm3Ws6FNBbfXvtUvk";
async function sbaSession(){return (await chrome.storage.local.get('sba_session')).sba_session||null}
async function sbaDeviceToken(){return (await chrome.storage.local.get('sba_device_token')).sba_device_token||null}
function sbaAuthHeaders(session){return {apikey:SBA_SUPABASE_KEY,Authorization:`Bearer ${session.access_token}`,'Content-Type':'application/json'}}
// Access tokens expire after about an hour. Rather than fail with a
// cryptic 401 once that happens mid-session (or mid automatic-outreach
// run), use the stored refresh_token to get a new one transparently.
async function sbaRefreshSession(session){
  if(!session?.refresh_token)return null;
  const r=await fetch(`${SBA_SUPABASE_URL}/auth/v1/token?grant_type=refresh_token`,{method:'POST',headers:{apikey:SBA_SUPABASE_KEY,'Content-Type':'application/json'},body:JSON.stringify({refresh_token:session.refresh_token})});
  const data=await r.json().catch(()=>({}));
  if(!r.ok)return null;
  await chrome.storage.local.set({sba_session:data});
  return data;
}
// Every authenticated call to Supabase goes through this: it attaches the
// current access token, and if that's expired (401), refreshes it once
// and retries automatically before giving up.
async function sbaFetch(url,opts={}){
  let session=await sbaSession();
  if(!session?.access_token)throw new Error('You are signed out. Reopen the extension and sign in.');
  let r=await fetch(url,{...opts,headers:{...sbaAuthHeaders(session),...(opts.headers||{})}});
  if(r.status===401){
    const refreshed=await sbaRefreshSession(session);
    if(refreshed){
      session=refreshed;
      r=await fetch(url,{...opts,headers:{...sbaAuthHeaders(session),...(opts.headers||{})}});
    }
  }
  return r;
}
// The ONLY function allowed to increase usage -- it's a Postgres RPC
// (increment_email_usage, see supabase-migration.sql) that checks the
// caller's plan and usage server-side and rejects the call if they're
// over their limit. A user cannot fake this result by editing the
// extension, because the check happens on Supabase, not here.
async function sbaCheckAndIncrementUsage(){
  const deviceToken=await sbaDeviceToken();
  const r=await sbaFetch(`${SBA_SUPABASE_URL}/rest/v1/rpc/increment_email_usage`,{method:'POST',body:JSON.stringify({p_device_token:deviceToken})});
  const data=await r.json().catch(()=>({}));
  if(!r.ok){
    const msg=data.message||data.error_description||data.hint||`Could not verify your plan/usage (HTTP ${r.status}).`;
    const limitHit=/LIMIT_REACHED/i.test(msg);
    const signedOutElsewhere=/SIGNED_OUT_ELSEWHERE/i.test(msg);
    if(signedOutElsewhere)await sbaSignOut();
    const err=new Error(msg.replace(/^(LIMIT_REACHED|SIGNED_OUT_ELSEWHERE):\s*/i,''));
    err.limitReached=limitHit;
    err.signedOutElsewhere=signedOutElsewhere;
    throw err;
  }
  return data;
}
async function sbaGetAccount(){
  const session=await sbaSession();
  if(!session?.user?.id)throw new Error('Not signed in.');
  const deviceToken=await sbaDeviceToken();
  if(deviceToken){
    const checkRes=await sbaFetch(`${SBA_SUPABASE_URL}/rest/v1/rpc/check_device`,{method:'POST',body:JSON.stringify({p_device_token:deviceToken})});
    if(!checkRes.ok){
      const d=await checkRes.json().catch(()=>({}));
      const msg=d.message||'';
      if(/SIGNED_OUT_ELSEWHERE/i.test(msg)){
        await sbaSignOut();
        const err=new Error(msg.replace(/^SIGNED_OUT_ELSEWHERE:\s*/i,''));
        err.signedOutElsewhere=true;
        throw err;
      }
    }
  }
  const uid=session.user.id;
  const month=new Date().toISOString().slice(0,7);
  const [profileRes,usageRes]=await Promise.all([
    sbaFetch(`${SBA_SUPABASE_URL}/rest/v1/profiles?id=eq.${uid}&select=full_name,email,plan,status,role`),
    sbaFetch(`${SBA_SUPABASE_URL}/rest/v1/email_usage?user_id=eq.${uid}&month=eq.${month}&select=emails_sent`)
  ]);
  if(!profileRes.ok){const d=await profileRes.json().catch(()=>({}));throw new Error(d.message||`Could not load your profile (HTTP ${profileRes.status}). Did you run supabase-migration.sql?`)}
  const profiles=await profileRes.json().catch(()=>[]);
  const usage=usageRes.ok?await usageRes.json().catch(()=>[]):[];
  const profile=profiles?.[0];
  if(!profile)throw new Error('No profile row found for your account yet.');
  const cap={FREE:10,VIP:500,LIFETIME:-1}[profile.plan]??10;
  return {id:uid,email:profile.email||session.user.email,plan:profile.plan||'FREE',status:profile.status||'active',role:profile.role||'user',used:usage?.[0]?.emails_sent||0,cap};
}
async function sbaSubmitPayment({plan,amount}){
  const session=await sbaSession();
  if(!session?.user?.id)throw new Error('Not signed in.');
  const r=await sbaFetch(`${SBA_SUPABASE_URL}/rest/v1/payments`,{method:'POST',headers:{Prefer:'return=minimal'},body:JSON.stringify({user_id:session.user.id,plan_requested:plan,amount:amount||null,status:'pending'})});
  if(!r.ok){const data=await r.json().catch(()=>({}));throw new Error(data.message||`Could not submit payment claim (HTTP ${r.status}).`)}
  return {ok:true};
}
async function sbaAdminListUsers(){
  const r=await sbaFetch(`${SBA_SUPABASE_URL}/rest/v1/profiles?select=id,email,plan,status,role&order=email.asc`);
  const profiles=await r.json().catch(()=>[]);
  if(!r.ok)throw new Error(profiles?.message||`Could not load users (HTTP ${r.status}) -- are you an admin?`);
  return profiles;
}
async function sbaAdminSetPlan({userId,plan,status}){
  const r=await sbaFetch(`${SBA_SUPABASE_URL}/rest/v1/profiles?id=eq.${userId}`,{method:'PATCH',headers:{Prefer:'return=minimal'},body:JSON.stringify({plan,status:status||'active'})});
  if(!r.ok){const data=await r.json().catch(()=>({}));throw new Error(data.message||`Could not update that user (HTTP ${r.status}) -- are you an admin?`)}
  return {ok:true};
}
async function sbaSignOut(){await chrome.storage.local.remove(['sba_session','sba_device_token']);return {ok:true}}

// ---- Gmail ----
async function gmailToken(interactive=true){const result=await chrome.identity.getAuthToken({interactive});const token=typeof result==='string'?result:result?.token;if(!token)throw new Error('Chrome did not return a Gmail OAuth token.');return token}
function b64(s){return btoa(unescape(encodeURIComponent(s))).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'')}
function mime(to,subject,body,extra=''){return `To: ${to}\r\nSubject: ${subject}\r\nContent-Type: text/plain; charset="UTF-8"\r\n${extra}\r\n${body}`}
async function gmailSend({to,subject,body}){const token=await gmailToken();const raw=b64(mime(to,subject,body));const r=await fetch('https://gmail.googleapis.com/gmail/v1/users/me/messages/send',{method:'POST',headers:{Authorization:`Bearer ${token}`,'Content-Type':'application/json'},body:JSON.stringify({raw})});if(!r.ok)throw new Error(await r.text());return r.json()}
async function checkGmail(){try{const token=await gmailToken(false);const r=await fetch('https://gmail.googleapis.com/gmail/v1/users/me/profile',{headers:{Authorization:`Bearer ${token}`}});if(!r.ok)throw new Error(`Gmail check failed (${r.status}).`);const d=await r.json();await save({gmailConnected:true,gmailEmail:d.emailAddress||''});return {ok:true,email:d.emailAddress||''}}catch(e){await save({gmailConnected:false});return {ok:false,error:e.message}}}
async function connect(){
  await chrome.identity.clearAllCachedAuthTokens().catch(()=>{});
  let result=await chrome.identity.getAuthToken({interactive:true});
  let token=typeof result==='string'?result:result?.token;
  let granted=typeof result==='string'?[]:(result?.grantedScopes||[]);
  if(!token)throw new Error('Chrome did not return a Gmail OAuth token. Close the popup and try Connect / Reconnect Gmail again.');
  let r=await fetch('https://gmail.googleapis.com/gmail/v1/users/me/profile',{headers:{Authorization:`Bearer ${token}`}});
  if(!r.ok&&(r.status===401||r.status===403)){
    await chrome.identity.removeCachedAuthToken({token}).catch(()=>{});
    await chrome.identity.clearAllCachedAuthTokens().catch(()=>{});
    result=await chrome.identity.getAuthToken({interactive:true});
    token=typeof result==='string'?result:result?.token;
    granted=typeof result==='string'?[]:(result?.grantedScopes||[]);
    if(token)r=await fetch('https://gmail.googleapis.com/gmail/v1/users/me/profile',{headers:{Authorization:`Bearer ${token}`}});
  }
  if(!r.ok){let detail='';try{detail=await r.text()}catch{};await save({gmailConnected:false});throw new Error(`Gmail authorization failed (${r.status}). ${detail||'Google rejected the current authorization.'}`)}
  let profile={};try{profile=await r.json()}catch{}
  await save({gmailConnected:true,grantedScopes:granted,gmailEmail:profile.emailAddress||''});
  return {ok:true,message:'Gmail connected successfully.'}
}

// ---- Gemini (direct, no local server -- see the SBA Outreach Assistant build for background) ----
const GEMINI_SYSTEM_PROMPT=`You are an expert B2B outreach writer working on behalf of small consulting firms. Write like a real professional wrote this personally to one specific company, not a mail-merge template. Every email must: (1) open by naming the sender and their company in the first sentence; (2) reference concrete, specific details from the supplied opportunity/contract (its title, client, and especially its scope) in the sender's own words, not copy-pasted; (3) connect that opportunity to something specific and plausible about the recipient's business (their apparent service area, based only on what's supplied) rather than a generic compliment; (4) close with a clear, low-pressure call to action. Use only facts supplied in the input -- never invent certifications, contracts, relationships, capabilities, eligibility, awards, deadlines, or client relationships, and never invent a sender detail that wasn't supplied. Avoid spammy language, ALL CAPS, excessive exclamation points, misleading subject lines, false urgency, guarantees, or manipulation -- this must read as a genuine, spam-filter-safe professional email, not a mass blast. Do NOT write a closing signature block (no "Best regards, [name]" etc.) -- a signature is appended separately and automatically, so writing your own would duplicate it. Return valid JSON when requested.`;
async function geminiChat(userContent){const s=await getState();const key=(s.settings.geminiApiKey||'').trim();if(!key)throw new Error('Add your free Gemini API key in Settings before using AI features.');const model=s.settings.geminiModel||'gemini-3.5-flash-lite';const r=await fetch('https://generativelanguage.googleapis.com/v1beta/openai/chat/completions',{method:'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${key}`},body:JSON.stringify({model,messages:[{role:'system',content:GEMINI_SYSTEM_PROMPT},{role:'user',content:userContent}]})});if(!r.ok)throw new Error(`Gemini API error ${r.status}: ${await r.text()}`);const data=await r.json();return data.choices?.[0]?.message?.content||''}
function stripJsonFence(t){return (t||'').replace(/^```json\s*/,'').replace(/^```\s*/,'').replace(/\s*```$/,'')}
async function geminiJson(userContent){const text=await geminiChat(userContent);return JSON.parse(stripJsonFence(text))}
async function checkAI(){const s=await getState();const key=(s.settings.geminiApiKey||'').trim();if(!key)return {ok:false,configured:false,error:'Add your free Gemini API key in Settings.'};try{const r=await fetch('https://generativelanguage.googleapis.com/v1beta/openai/models',{headers:{Authorization:`Bearer ${key}`}});if(!r.ok)throw new Error(`Gemini rejected the key (${r.status}).`);return {ok:true,configured:true,model:s.settings.geminiModel||'gemini-3.5-flash-lite'}}catch(e){return {ok:false,configured:false,error:e.message}}}

function buildSignature(sender){const lines=[];if(sender.senderName)lines.push(sender.senderName);if(sender.senderTitle)lines.push(sender.senderTitle);const bits=[sender.senderEmail,sender.senderPhone,sender.senderWebsite].filter(Boolean);if(bits.length)lines.push(bits.join('  ·  '));return lines.join('\n')}
function draftPrompt(prospect,campaign,contract,sender){return `Write an outreach email from the sender below to this company found via Google Maps, about the opportunity described. Sender (do not invent a name/company if blank, just omit that part): ${JSON.stringify({name:sender.senderName,title:sender.senderTitle,company:sender.senderCompany})} Company: ${JSON.stringify({name:prospect.name,website:prospect.website,phone:prospect.phone,context:prospect.rawText})} Service/offer and tone: ${JSON.stringify({serviceContext:campaign.serviceContext,objective:campaign.objective,tone:campaign.tone})} Opportunity/contract (use its title, client, and especially its scope in your own words -- this is the reason for the email): ${JSON.stringify(contract)} Return JSON exactly {"subject":"...","body":"..."}. Keep it under 150 words. Propose a relevant business conversation, teaming, subcontracting, or referral path without claiming the recipient has been selected for anything.`}
async function draft(p){const s=await getState();const sender=activeSender(s.campaign);if(!(sender.senderName||'').trim()||!(sender.senderCompany||'').trim())throw new Error(`Add your ${s.campaign.region} sender name and company in the Campaign tab first.`);const r=await geminiJson(draftPrompt(p,s.campaign,s.campaign.contract,sender));const sig=buildSignature(sender);return {subject:r.subject,body:sig?`${(r.body||'').trim()}\n\n${sig}`:(r.body||'').trim()}}

// ---- Google Maps tab helpers ----
async function activeTab(){const ts=await chrome.tabs.query({active:true,currentWindow:true});return ts[0]}
function waitForTabLoad(tabId,timeout=15000){return new Promise((resolve,reject)=>{const start=Date.now();const check=async()=>{let tab;try{tab=await chrome.tabs.get(tabId)}catch(e){return reject(e)}if(tab.status==='complete')return resolve(tab);if(Date.now()-start>timeout)return reject(new Error('Timed out waiting for the page to load.'));setTimeout(check,300)};check()})}
async function collectVisibleBatch(tabId){const r=await chrome.tabs.sendMessage(tabId,{type:'EXTRACT_MAPS_LISTINGS'}).catch(()=>null);return r?.listings||[]}
async function scrollForMore(tabId){await chrome.tabs.sendMessage(tabId,{type:'SCROLL_MAPS_FEED'}).catch(()=>null);await new Promise(res=>setTimeout(res,1500))}
function batchSignature(listings){return listings.map(l=>(l.mapsUrl||l.name||'').toLowerCase()).sort().join('|')}
// Google Maps shows review counts as "4.7(2,341)" or "4.7 (89)" right next
// to the star rating -- requiring a rating digit immediately before the
// parenthesized number is what keeps this from misreading a phone number's
// area code, e.g. "(555) 123-4567", as a review count.
function extractReviewCount(text){const m=(text||'').match(/\d(?:\.\d)?\s*\((\d{1,3}(?:,\d{3})*)\)/);if(!m)return null;return parseInt(m[1].replace(/,/g,''),10)}

// Finds an email on a company's website by opening it in a background tab
// (never focused/visible to the user) and scanning for a mailto: link or an
// email-shaped string in the page text. Tries the homepage first, then a
// couple of common contact-page paths as a fallback. Heuristic, not
// guaranteed -- many sites hide contact info behind a form instead of a
// plain email address.
async function scanTabForEmail(tabId){try{const results=await chrome.scripting.executeScript({target:{tabId},func:()=>{const mailtoEl=document.querySelector('a[href^="mailto:"]');if(mailtoEl){const m=(mailtoEl.getAttribute('href')||'').replace('mailto:','').split('?')[0].trim();if(m)return m}const text=document.body?document.body.innerText:'';const matches=text.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi)||[];const bad=/\.(png|jpg|jpeg|gif|svg|webp|css|js)$/i;const noise=/example\.(com|org)|sentry\.io|wixpress\.com|godaddy\.com|schema\.org/i;const good=matches.find(m=>!bad.test(m)&&!noise.test(m));return good||''}});return results?.[0]?.result||''}catch{return ''}}
async function resolveWebsiteFromMaps(mapsUrl){
  if(!mapsUrl)return '';
  let tabId;
  try{
    const tab=await chrome.tabs.create({url:mapsUrl,active:false});
    tabId=tab.id;
    await waitForTabLoad(tabId,15000).catch(()=>{});
    await new Promise(res=>setTimeout(res,1500));
    const r=await chrome.tabs.sendMessage(tabId,{type:'EXTRACT_WEBSITE_DETAIL'}).catch(()=>null);
    return r?.website||'';
  } finally {
    if(tabId)chrome.tabs.remove(tabId).catch(()=>{});
  }
}
async function findEmailOnWebsite(url){
  if(!url)return '';
  let tabId,origin;
  try{origin=new URL(url).origin}catch{return ''}
  try{
    const tab=await chrome.tabs.create({url,active:false});
    tabId=tab.id;
    await waitForTabLoad(tabId,15000).catch(()=>{});
    await new Promise(res=>setTimeout(res,1000));
    let email=await scanTabForEmail(tabId);
    if(!email){
      for(const path of ['/contact','/contact-us','/contact-us/','/about/contact','/contactus']){
        try{
          await chrome.tabs.update(tabId,{url:origin+path});
          await waitForTabLoad(tabId,10000).catch(()=>{});
          await new Promise(res=>setTimeout(res,800));
          email=await scanTabForEmail(tabId);
          if(email)break;
        }catch{}
      }
    }
    return email||'';
  } finally {
    if(tabId)chrome.tabs.remove(tabId).catch(()=>{});
  }
}

// ---- Merging / dedup ----
// New listings start as 'discovered' (has a website, email not looked up
// yet) or 'skipped' (no website at all -- nothing to look up). Discovery
// later flips 'discovered' -> 'queued' (email found) or 'skipped' (not
// found). Re-collecting the same visible batch (which scrolling can do)
// never regresses a prospect's status once assigned.
function mergeListings(existing,listings,maxReviews){
  const map=new Map(existing.map(p=>[p.id,p]));
  for(const raw of listings){
    const id=idForMaps(raw);
    if(!map.has(id)){
      const reviewCount=extractReviewCount(raw.rawText);
      const overReviews=!!maxReviews&&reviewCount!=null&&reviewCount>maxReviews;
      let status,skipReason;
      // No inline website on the list card doesn't mean no website at all --
      // that link usually only shows on the place's own detail page, which
      // gets checked during discovery. Only skip here for the review filter.
      if(overReviews){status='skipped';skipReason=`Has ${reviewCount} reviews (over your ${maxReviews}-review limit)`}
      else{status='discovered';skipReason=''}
      const p={...raw,id,reviewCount,status,skipReason,createdAt:Date.now()};
      map.set(id,p);
    } else {
      const old=map.get(id);
      map.set(id,{...old,name:raw.name||old.name,phone:raw.phone||old.phone,mapsUrl:raw.mapsUrl||old.mapsUrl,rawText:raw.rawText||old.rawText});
    }
  }
  return [...map.values()];
}
function nextAction(prospects){
  const discover=prospects.find(p=>p.status==='discovered'&&!p.suppressed);
  if(discover)return {type:'discover',prospect:discover};
  const send=prospects.find(p=>p.status==='queued'&&p.email&&!p.suppressed);
  if(send)return {type:'send',prospect:send};
  return null;
}

async function updateProgress(patch){const s=await getState();await save({outreach:{...s.outreach,...patch,updatedAt:Date.now()}})}
function randomDelay(min,max){const lo=Math.max(30,Number(min)||30),hi=Math.max(lo,Number(max)||lo);return (lo+Math.random()*(hi-lo))*1000}
async function scheduleJob(ms=0){await chrome.alarms.clear(JOB_ALARM);chrome.alarms.create(JOB_ALARM,{when:Date.now()+Math.max(0,ms)})}
async function scheduleRecovery(ms=60000){await chrome.alarms.clear(RECOVERY_ALARM);chrome.alarms.create(RECOVERY_ALARM,{when:Date.now()+Math.max(0,ms)})}
function hasPendingWork(s){return !!s.prospects?.some(p=>(p.status==='discovered'||p.status==='queued')&&!p.suppressed)}
async function checkForStalledOutreach(){
  const s=await getState(),o=s.outreach||{};
  if(s.paused||!hasPendingWork(s))return;
  const age=o.updatedAt?Date.now()-o.updatedAt:Infinity;
  if(o.running){
    if(age>=RECOVERY_STALE_MS){
      if((o.recoveryAttempts||0)>=MAX_RECOVERY_ATTEMPTS){
        await updateProgress({running:false,phase:'error',currentAction:'Automatic recovery stopped after several unsuccessful attempts. Click Start Automatic Outreach to continue.',lastResult:'Recovery attempt limit reached.'});
        return;
      }
      await save({outreach:{...o,running:true,recoveryAttempts:(o.recoveryAttempts||0)+1,lastRecoveryAt:Date.now(),currentAction:'Automatic outreach appears stalled. Attempting to resume…',updatedAt:Date.now()}});
      await scheduleJob(0);
    }
    return;
  }
  if(o.phase==='error' && (o.recoveryAttempts||0)<MAX_RECOVERY_ATTEMPTS){
    await save({outreach:{...o,running:true,recoveryAttempts:(o.recoveryAttempts||0)+1,lastRecoveryAt:Date.now(),currentAction:'Recovering interrupted automatic outreach…',updatedAt:Date.now()}});
    await scheduleJob(0);
  }
}

const MAX_BATCHES_SAFETY_CAP=40;
async function advanceBatch(s){
  await updateProgress({phase:'scrolling',currentAction:'Scrolling for more companies…'});
  try{
    if(s.outreach.batches>=MAX_BATCHES_SAFETY_CAP){await updateProgress({running:false,phase:'complete',currentCompany:'',currentEmail:'',currentAction:`Stopped as a safety precaution after ${MAX_BATCHES_SAFETY_CAP} scrolls. Check the Prospects list before restarting.`,lastResult:'Hit the batch safety cap.'});return}
    await scrollForMore(s.outreach.mapsTabId);
    const listings=await collectVisibleBatch(s.outreach.mapsTabId);
    const sig=batchSignature(listings);
    if(!listings.length||sig===s.outreach.lastBatchSignature){await updateProgress({running:false,phase:'complete',currentCompany:'',currentEmail:'',currentAction:'Automatic outreach complete — reached the end of the results list.',lastResult:'No more new companies found.'});return}
    const latest=await getState();
    const prospects=mergeListings(latest.prospects,listings,latest.settings.maxReviews);
    const batches=latest.outreach.batches+1;
    await save({prospects,stats:{...latest.stats,found:prospects.length},outreach:{...latest.outreach,batches,rowsCollected:latest.outreach.rowsCollected+listings.length,lastBatchSignature:sig,currentAction:`Loaded more results (scroll ${batches}) — ${prospects.length} companies found so far.`,updatedAt:Date.now()}});
    await scheduleJob(0);
  }catch(e){await updateProgress({running:false,phase:'error',currentCompany:'',currentEmail:'',currentAction:'Automatic outreach was interrupted. Recovery will retry automatically if there is remaining work.',lastResult:e.message,error:e.message});await scheduleRecovery(60000)}
}

async function startAutomaticOutreach(){
  const s=await getState();
  if(s.outreach.running)return {ok:true,message:'Automatic outreach is already running.'};
  if(!s.gmailConnected)throw new Error('Connect Gmail before starting automatic outreach.');
  const sender=activeSender(s.campaign);
  if(!(sender.senderName||'').trim()||!(sender.senderCompany||'').trim())throw new Error(`Add your ${s.campaign.region} sender name and company in the Campaign tab before starting.`);
  if(!s.campaign.contract?.title&&!s.campaign.contract?.scope)throw new Error('Add the opportunity/contract you\'re reaching out about first.');
  const tab=await activeTab();
  if(!tab?.url?.includes('google.com/maps')&&!tab?.url?.includes('maps.google.com'))throw new Error('Open a Google Maps search results page first.');
  await save({paused:false,outreach:{...DEFAULTS.outreach,running:true,phase:'scrolling',startedAt:Date.now(),updatedAt:Date.now(),currentAction:'Reading visible Google Maps results…',mapsTabId:tab.id,recoveryAttempts:0,lastRecoveryAt:null}});
  try{
    const listings=await collectVisibleBatch(tab.id);
    const st=await getState();
    const prospects=mergeListings(st.prospects,listings,st.settings.maxReviews);
    await save({prospects,stats:{...st.stats,found:prospects.length},outreach:{...st.outreach,running:true,phase:'ready',batches:1,rowsCollected:listings.length,lastBatchSignature:batchSignature(listings),currentAction:`Found ${listings.length} compan${listings.length===1?'y':'ies'} on screen.`,updatedAt:Date.now()}});
    await scheduleJob(0);
    return {ok:true,message:`Started. Found ${listings.length} compan${listings.length===1?'y':'ies'} visible so far.`};
  }catch(e){await updateProgress({running:false,phase:'error',error:e.message,currentAction:'Automatic outreach was interrupted. Recovery will retry automatically if there is remaining work.',lastResult:e.message});await scheduleRecovery(60000);throw e}
}

async function processAutomaticOne(){
  let s=await getState();
  if(!s.outreach.running)return;
  if(s.paused){await updateProgress({running:false,phase:'paused',currentAction:'Paused by user.'});return}
  const sentToday=s.prospects.filter(p=>p.lastSentAt&&new Date(p.lastSentAt).toDateString()===new Date().toDateString()).length;
  if(sentToday>=s.campaign.dailyLimit){await updateProgress({running:false,phase:'limit',currentAction:`Daily limit reached (${s.campaign.dailyLimit}).`,lastResult:'Daily send limit reached.'});return}
  const action=nextAction(s.prospects);
  if(!action){await advanceBatch(s);return}
  if(action.type==='discover'){
    const p=action.prospect;
    let website=p.website;
    if(!website){
      await updateProgress({phase:'finding_email',currentCompany:p.name,currentEmail:'',currentAction:`Opening ${p.name}'s Maps listing to find their website…`});
      try{website=await resolveWebsiteFromMaps(p.mapsUrl)}catch{website=''}
    }
    if(!website){
      const latest=await getState();
      const prospects=latest.prospects.map(x=>x.id===p.id?{...x,status:'skipped',skipReason:'No website listed on this business\'s Maps page',checkedAt:Date.now()}:x);
      await save({prospects,outreach:{...latest.outreach,currentAction:`No website found for ${p.name} — skipped.`,recoveryAttempts:0,lastRecoveryAt:null,updatedAt:Date.now()}});
      await scheduleJob(1200);
      return;
    }
    await updateProgress({phase:'finding_email',currentCompany:p.name,currentEmail:'',currentAction:`Checking ${website} for an email…`});
    let email='';
    try{email=await findEmailOnWebsite(website)}catch{email=''}
    const latest=await getState();
    const prospects=latest.prospects.map(x=>x.id===p.id?{...x,website,email,status:email?'queued':'skipped',skipReason:email?'':'No email found on the website',checkedAt:Date.now()}:x);
    await save({prospects,outreach:{...latest.outreach,currentAction:email?`Found an email for ${p.name}.`:`No email found for ${p.name} — skipped.`,recoveryAttempts:0,lastRecoveryAt:null,updatedAt:Date.now()}});
    await scheduleJob(1200);
    return;
  }
  const p=action.prospect;
  await updateProgress({phase:'preparing',currentCompany:p.name,currentEmail:p.email,currentAction:`Checking your plan before drafting for ${p.name}…`});
  try{
    await sbaCheckAndIncrementUsage();
  }catch(e){
    if(e.signedOutElsewhere){
      await updateProgress({running:false,phase:'signed_out',currentAction:`Stopped: signed in on another device. ${e.message}`,lastResult:e.message});
    }else if(e.limitReached){
      await updateProgress({running:false,phase:'limit',currentAction:`Stopped: ${e.message}`,lastResult:e.message});
    }else{
      await updateProgress({running:false,phase:'error',currentAction:`Stopped: ${e.message}`,lastResult:e.message,error:e.message});
    }
    return;
  }
  await updateProgress({phase:'preparing',currentCompany:p.name,currentEmail:p.email,currentAction:`Drafting an email for ${p.name}…`});
  try{
    const r=await draft(p);
    await updateProgress({phase:'sending',currentAction:`Sending to ${p.name}…`});
    await gmailSend({to:p.email,subject:r.subject,body:r.body});
    const latest=await getState();
    const prospects=latest.prospects.map(x=>x.id===p.id?{...x,status:'active',lastSentAt:Date.now(),lastSubject:r.subject}:x);
    await save({prospects,stats:{...latest.stats,sent:latest.stats.sent+1},outreach:{...latest.outreach,sent:latest.outreach.sent+1,processed:latest.outreach.processed+1,currentAction:`Sent to ${p.name}.`,lastResult:`Sent to ${p.name}.`,recoveryAttempts:0,lastRecoveryAt:null,updatedAt:Date.now()}});
  }catch(e){
    const latest=await getState();
    const prospects=latest.prospects.map(x=>x.id===p.id?{...x,status:'failed',lastError:e.message}:x);
    await save({prospects,stats:{...latest.stats,failed:latest.stats.failed+1},outreach:{...latest.outreach,failed:latest.outreach.failed+1,processed:latest.outreach.processed+1,currentAction:`Failed for ${p.name}: ${e.message}`,lastResult:e.message,recoveryAttempts:0,lastRecoveryAt:null,updatedAt:Date.now()}});
  }
  const s2=await getState();
  await scheduleJob(randomDelay(s2.settings.minDelay,s2.settings.maxDelay));
}

async function clearUnsentProspects(){const s=await getState();const kept=s.prospects.filter(p=>p.lastSentAt);const removed=s.prospects.length-kept.length;await save({prospects:kept,stats:{...s.stats,found:kept.length}});return {message:`Removed ${removed} prospect(s) that hadn't been emailed yet. ${kept.length} already-contacted prospect(s) kept so they won't be emailed again.`}}
async function resetEverything(){await save({prospects:[],stats:{found:0,sent:0,failed:0,skipped:0},outreach:{...DEFAULTS.outreach}});return {message:'Cleared. Note: duplicate protection for previously emailed companies was also reset.'}}

chrome.runtime.onInstalled.addListener(async()=>{
  await getState();
  await chrome.alarms.create(RECOVERY_ALARM,{periodInMinutes:1});
  await chrome.alarms.create(UPDATE_CHECK_ALARM,{periodInMinutes:360});
});
chrome.runtime.onStartup?.addListener(async()=>{
  const s=await getState();
  await chrome.alarms.create(RECOVERY_ALARM,{periodInMinutes:1});
  await chrome.alarms.create(UPDATE_CHECK_ALARM,{periodInMinutes:360});
  if(s.outreach.running&&!s.paused)await scheduleJob(0);
  else if(s.outreach.phase==='error'&&!s.paused&&hasPendingWork(s))await scheduleRecovery(30000);
});
chrome.alarms.onAlarm.addListener(a=>{
  if(a.name===JOB_ALARM)processAutomaticOne().catch(async e=>{
    await updateProgress({running:false,phase:'error',currentAction:'Automatic outreach was interrupted. Recovery will retry automatically if there is remaining work.',error:e.message});
    await scheduleRecovery(60000);
  });
  if(a.name===RECOVERY_ALARM)checkForStalledOutreach().catch(()=>{});
  if(a.name===UPDATE_CHECK_ALARM)checkForUpdate().catch(()=>{});
});
// ---- Extension update checker ----
async function checkForUpdate(){
  try{
    const controller=new AbortController();
    const timer=setTimeout(()=>controller.abort(),8000);
    const r=await fetch(UPDATE_URL,{cache:'no-store',signal:controller.signal});
    clearTimeout(timer);
    if(!r.ok)return {ok:false};
    const data=await r.json();
    const current=chrome.runtime.getManifest().version;
    const latest=String(data.version||'').trim();
    if(!latest)return {ok:false};
    const compareVersions=(a,b)=>{
      const aa=String(a).split('.').map(x=>parseInt(x,10)||0),bb=String(b).split('.').map(x=>parseInt(x,10)||0);
      for(let i=0;i<Math.max(aa.length,bb.length);i++){if((aa[i]||0)!==(bb[i]||0))return (aa[i]||0)>(bb[i]||0)?1:-1;}
      return 0;
    };
    const result={ok:true,currentVersion:current,latestVersion:latest,newer:compareVersions(latest,current)>0,downloadUrl:data.downloadUrl||'https://dgtandassociatesuk.tech/extension/SBA-Outreach-Assistant-latest.zip',releaseNotes:data.releaseNotes||''};
    await chrome.storage.local.set({sba_update:result,sba_update_checked_at:Date.now()});
    return result;
  }catch(e){return {ok:false,error:e.message}}
}

chrome.runtime.onMessage.addListener((m,sr,send)=>{(async()=>{try{switch(m.type){
  case 'STATE':return {ok:true,...await getState()};
  case 'CONNECT_GMAIL':return await connect();
  case 'CHECK_GMAIL':return await checkGmail();
  case 'CHECK_AI':return await checkAI();
  case 'START_AUTOMATIC':return await startAutomaticOutreach();
  case 'PAUSE':{const st=await getState();await save({paused:true,outreach:{...st.outreach,running:false,phase:'paused',currentAction:'Paused by user.',updatedAt:Date.now()}});await chrome.alarms.clear(JOB_ALARM);return {message:'Sending paused.'}}
  case 'SAVE_CAMPAIGN':await save({campaign:m.campaign});return {message:'Campaign saved.'};
  case 'SAVE_SETTINGS':{const settings={...DEFAULTS.settings,...(m.settings||{})};settings.geminiApiKey=String(settings.geminiApiKey||'').trim();settings.geminiModel=String(settings.geminiModel||'gemini-3.5-flash-lite').trim()||'gemini-3.5-flash-lite';settings.minDelay=Math.max(0,Number(settings.minDelay)||30);settings.maxDelay=Math.max(settings.minDelay,Number(settings.maxDelay)||60);await save({settings});return {message:'Settings saved.',settings}}
  case 'DRAFT_INITIAL':return {ok:true,...await draft(m.prospect)};
  case 'SEND_MANUAL':{const p=m.prospect;if(!p?.email)throw new Error('This company has no email on file.');await sbaCheckAndIncrementUsage();await gmailSend({to:p.email,subject:m.subject,body:m.body});const st=await getState();const prospects=st.prospects.map(x=>x.id===p.id?{...x,status:'active',lastSentAt:Date.now(),lastSubject:m.subject}:x);await save({prospects,stats:{...st.stats,sent:st.stats.sent+1}});return {message:`Sent to ${p.name}.`}}
  case 'GET_ACCOUNT':return {ok:true,account:await sbaGetAccount()};
  case 'SUBMIT_PAYMENT':return await sbaSubmitPayment(m);
  case 'ADMIN_LIST_USERS':return {ok:true,users:await sbaAdminListUsers()};
  case 'ADMIN_SET_PLAN':return await sbaAdminSetPlan(m);
  case 'SBA_SIGN_OUT':return await sbaSignOut();
  case 'CLEAR_UNSENT':return await clearUnsentProspects();
  case 'RESET_ALL':return await resetEverything();
  case 'CHECK_UPDATE':return await checkForUpdate();
  case 'GET_UPDATE_INFO':return (await chrome.storage.local.get('sba_update')).sba_update||await checkForUpdate();
  case 'OPEN_UPDATE':{const u=(await chrome.storage.local.get('sba_update')).sba_update;const url=u?.downloadUrl||'https://dgtandassociatesuk.tech/extension/SBA-Outreach-Assistant-latest.zip';await chrome.tabs.create({url});return {ok:true,url};}
  default:return {error:'Unknown action'}
  }}catch(e){return {ok:false,error:e.message,signedOutElsewhere:!!e.signedOutElsewhere,limitReached:!!e.limitReached}}})().then(send);return true});
