const $=id=>document.getElementById(id);
// Fields restored from an unsaved draft (see below) stay protected from the
// 1s poll's normal overwrite until the user explicitly saves -- otherwise
// the very next poll tick would stomp the just-restored text right back out.
const restoredIds=new Set();
function setVal(id,v){const el=$(id);if(!el)return;if(document.activeElement===el)return;if(restoredIds.has(id))return;const nv=v==null?'':String(v);if(el.value!==nv)el.value=nv}
function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function send(msg){return new Promise(res=>chrome.runtime.sendMessage(msg,res))}
function flash(msg,type='success'){const el=$('status');if(!el||!msg)return;el.textContent=msg;el.style.display='block';el.style.background=type==='error'?'#fdecea':'#e7f8ef';el.style.color=type==='error'?'#b42318':'#087443';clearTimeout(flash._t);flash._t=setTimeout(()=>el.style.display='none',3500)}

let state=null,poll=null;
if($('sbaSidebarVersion'))$('sbaSidebarVersion').textContent='ASSISTANT · v'+chrome.runtime.getManifest().version;

// --- Popup-close survival: the popup's entire DOM/JS state is destroyed the
// instant it loses focus. To survive that, every keystroke and every tab
// switch is snapshotted into chrome.storage.session (cleared on browser
// close, unlike .local -- this is transient UI state, not real data). On
// reopen, a snapshot newer than 60s restores both the active tab and any
// unsaved field text; anything staler is discarded so you're never looking
// at a days-old ghost draft.
const DRAFT_KEY='uiDraft',DRAFT_TTL=60000;
let persistTimer=null;
async function persistUi(){
  const activeTab=document.querySelector('.navitem.active')?.dataset.tab||'dashboard';
  const values={};
  document.querySelectorAll('main input[id],main textarea[id],main select[id]').forEach(el=>{values[el.id]=el.value});
  await chrome.storage.session.set({[DRAFT_KEY]:{tab:activeTab,values,ts:Date.now()}});
}
function schedulePersist(){clearTimeout(persistTimer);persistTimer=setTimeout(persistUi,300)}
async function clearDraft(){restoredIds.clear();await chrome.storage.session.remove(DRAFT_KEY).catch(()=>{})}
async function restoreDraftIfFresh(){
  const r=await chrome.storage.session.get(DRAFT_KEY).catch(()=>({}));
  const draft=r[DRAFT_KEY];
  if(!draft)return;
  if(Date.now()-draft.ts>DRAFT_TTL){await chrome.storage.session.remove(DRAFT_KEY).catch(()=>{});return}
  const navEl=document.querySelector(`.navitem[data-tab="${draft.tab}"]`);
  if(navEl){
    document.querySelectorAll('.navitem').forEach(x=>x.classList.remove('active'));
    document.querySelectorAll('.tab').forEach(x=>x.classList.remove('active'));
    navEl.classList.add('active');
    $(draft.tab)?.classList.add('active');
  }
  Object.entries(draft.values||{}).forEach(([id,val])=>{
    const el=$(id);
    if(el&&document.activeElement!==el&&el.value!==val){el.value=val;restoredIds.add(id)}
  });
  if(restoredIds.size)flash('Restored what you were typing before the popup closed — remember to save.','success');
}

document.querySelectorAll('.navitem').forEach(el=>el.onclick=()=>{
  document.querySelectorAll('.navitem').forEach(x=>x.classList.remove('active'));
  document.querySelectorAll('.tab').forEach(x=>x.classList.remove('active'));
  el.classList.add('active');
  $(el.dataset.tab).classList.add('active');
  persistUi();
});
document.addEventListener('input',e=>{if(['INPUT','TEXTAREA','SELECT'].includes(e.target.tagName))schedulePersist()});

async function refresh(){const r=await send({type:'STATE'});if(r?.ok){state=r;render()}}

function renderChecklist(s){
  const sender=s.campaign.region==='UK'?s.campaign.uk:s.campaign.us;
  const items=[
    {ok:!!(s.settings.geminiApiKey||'').trim(),label:'Add a free Gemini API key',hint:'Settings tab'},
    {ok:!!s.gmailConnected,label:'Connect Gmail',hint:'Settings tab'},
    {ok:!!(sender.senderName||'').trim()&&!!(sender.senderCompany||'').trim(),label:`Tell it who you are (${s.campaign.region} name + company)`,hint:'Campaign tab'},
    {ok:!!(s.campaign.contract&&(s.campaign.contract.title||s.campaign.contract.scope)),label:'Save the opportunity/contract you\'re pitching',hint:'Opportunity tab'},
  ];
  const allDone=items.every(i=>i.ok);
  const rows=items.map(i=>`<div class="checkitem">${i.ok?'✅':'⬜'} <span>${esc(i.label)}</span>${i.ok?'':`<span class="small tag">${esc(i.hint)}</span>`}</div>`).join('');
  const next=allDone?'<div class="checkitem checkdone">✅ All set. Open a Google Maps search, then click <b>Start Automatic Outreach</b> on this Dashboard.</div>':'';
  $('setupChecklist').innerHTML=rows+next;
  $('checklistCard').style.display=allDone?'none':'block';
}

function statusLabel(st){return {discovered:'finding email',queued:'queued',active:'sent',failed:'failed',skipped:'skipped'}[st]||st}

// Drives the dashboard's journey stepper (Finding companies -> Finding
// email -> Drafting -> Sending -> Done), lighting up the step matching the
// current phase and marking earlier ones as complete.
const JOURNEY_ORDER=['scrolling,ready','finding_email','preparing','sending','complete,paused,limit,error'];
function renderJourney(phase,running){
  const steps=[...document.querySelectorAll('#journeySteps .jstep')];
  let activeIdx=JOURNEY_ORDER.findIndex(group=>group.split(',').includes(phase));
  if(!running&&!['complete','paused','limit','error'].includes(phase))activeIdx=-1;
  steps.forEach((el,i)=>{
    el.classList.remove('done','active');
    if(activeIdx<0)return;
    if(i<activeIdx)el.classList.add('done');
    else if(i===activeIdx)el.classList.add('active');
  });
}

function render(){
  if(!state)return;
  const s=state,o=s.outreach||{};
  const queued=s.prospects.filter(p=>p.status==='queued').length;
  const skipped=s.prospects.filter(p=>p.status==='skipped').length;
  $('mFound').textContent=s.prospects.length;
  $('mQueued').textContent=queued;
  $('mSent').textContent=s.stats.sent;
  $('mSkipped').textContent=skipped;
  $('gmailBadge').textContent=s.gmailConnected?'● Gmail connected':'Gmail not connected';
  $('gmailBadge').style.background=s.gmailConnected?'#e7f8ef':'#fff0ee';
  $('gmailBadge').style.color=s.gmailConnected?'#087443':'#b42318';
  renderChecklist(s);

  const c=s.campaign.contract;
  $('selectedContract').innerHTML=c&&(c.title||c.scope)?`<b>${esc(c.title||'Untitled opportunity')}</b><div class="small">${esc(c.agency||'')}${c.agency&&c.solicitationNumber?' · ':''}${esc(c.solicitationNumber||'')}</div>`:'No opportunity selected.';

  $('regionLabel').textContent=`(${s.campaign.region})`;
  renderJourney(o.phase,o.running);
  $('progressSent').textContent=o.sent||0;
  $('progressFailed').textContent=o.failed||0;
  $('progressBatches').textContent=o.batches||0;
  $('progressRows').textContent=o.rowsCollected||0;
  $('progressAction').textContent=o.currentAction||'Idle';
  $('progressCompany').textContent=o.currentCompany||'—';
  $('progressEmail').textContent=o.currentEmail||'—';
  $('lastUpdate').textContent=o.updatedAt?`Last update: ${new Date(o.updatedAt).toLocaleString()}`:'—';
  const resumable=!!s.prospects?.some(p=>(p.status==='discovered'||p.status==='queued')&&!p.suppressed);
  $('startAuto').disabled=!!o.running;
  $('startAuto').textContent=o.running?'⚡ Running…':(resumable||o.phase==='error'?'⚡ Resume Automatic Outreach':'⚡ Start Automatic Outreach');

  // Opportunity tab
  setVal('contractTitle',c?.title||'');setVal('contractAgency',c?.agency||'');setVal('contractSolicitation',c?.solicitationNumber||'');setVal('contractUrl',c?.url||'');setVal('contractScope',c?.scope||'');
  let deadline='';if(c?.deadline){const d=new Date(c.deadline);if(!isNaN(d))deadline=new Date(d.getTime()-d.getTimezoneOffset()*60000).toISOString().slice(0,16)}
  setVal('contractDeadline',deadline);

  // Campaign tab
  $('regionUS').classList.toggle('active',s.campaign.region!=='UK');
  $('regionUK').classList.toggle('active',s.campaign.region==='UK');
  setVal('usSenderName',s.campaign.us.senderName||'');setVal('usSenderTitle',s.campaign.us.senderTitle||'');setVal('usSenderCompany',s.campaign.us.senderCompany||'');setVal('usSenderEmail',s.campaign.us.senderEmail||'');setVal('usSenderPhone',s.campaign.us.senderPhone||'');setVal('usSenderWebsite',s.campaign.us.senderWebsite||'');
  setVal('ukSenderName',s.campaign.uk.senderName||'');setVal('ukSenderTitle',s.campaign.uk.senderTitle||'');setVal('ukSenderCompany',s.campaign.uk.senderCompany||'');setVal('ukSenderEmail',s.campaign.uk.senderEmail||'');setVal('ukSenderPhone',s.campaign.uk.senderPhone||'');setVal('ukSenderWebsite',s.campaign.uk.senderWebsite||'');
  setVal('campaignName',s.campaign.name||'');setVal('serviceContext',s.campaign.serviceContext||'');setVal('objective',s.campaign.objective||'');setVal('tone',s.campaign.tone||'Professional');setVal('dailyLimit',s.campaign.dailyLimit||25);

  // Settings tab
  setVal('geminiApiKey',s.settings.geminiApiKey||'');setVal('geminiModel',s.settings.geminiModel||'gemini-3.5-flash-lite');setVal('minDelay',s.settings.minDelay??30);setVal('maxDelay',s.settings.maxDelay??60);setVal('maxReviews',s.settings.maxReviews??'');

  // Prospects list
  $('prospectList').innerHTML=s.prospects.length?s.prospects.slice().reverse().map(p=>`<div class="prospect"><b>${esc(p.name)}</b><div class="small">${esc(p.email||p.website||'no website')}${p.phone?' · '+esc(p.phone):''}${p.reviewCount!=null?' · '+esc(p.reviewCount)+' review'+(p.reviewCount===1?'':'s'):''}</div>${p.status==='skipped'&&p.skipReason?`<div class="small">${esc(p.skipReason)}</div>`:''}<span class="tag">${esc(statusLabel(p.status))}</span></div>`).join(''):'<div class="small">No companies collected yet — run a Google Maps search and start automatic outreach.</div>';

  // AI Writer dropdown
  const sel=$('aiProspect');
  const withEmail=s.prospects.filter(p=>p.email);
  const prevVal=sel.value;
  sel.innerHTML=withEmail.map(p=>`<option value="${esc(p.id)}">${esc(p.name)} — ${esc(p.email)}</option>`).join('')||'<option value="">No companies with an email yet</option>';
  if(withEmail.some(p=>p.id===prevVal))sel.value=prevVal;
}

async function checkConnections(){
  const gs=$('gmailStatus'),ga=$('gmailAccount'),ai=$('aiStatus'),model=$('aiModel');
  const gr=await send({type:'CHECK_GMAIL'});
  if(gr?.ok){gs.textContent='● Connected';gs.className='statusok';ga.textContent=gr.email||'';}
  else{gs.textContent='● Not connected';gs.className='statusbad';ga.textContent=gr?.error||'';}
  const ar=await send({type:'CHECK_AI'});
  if(ar?.ok&&ar.configured){ai.textContent='● Connected';ai.className='statusok';model.textContent=`Model: ${ar.model||'gemini-3.5-flash-lite'}`;}
  else{ai.textContent='● Not configured';ai.className='statusbad';model.textContent=ar?.error||'Add your free Gemini API key in Settings.';}
  await refresh();
}

async function showUpdateInfo(info){
  const box=$('updateNotice'),txt=$('updateNoticeText');
  if(!box)return;
  if(info?.ok&&info.newer){
    txt.textContent=`Version ${info.latestVersion} is available. You are using v${info.currentVersion}.`;
    box.style.display='block';
  }else box.style.display='none';
}
async function checkExtensionUpdate(){
  const info=await send({type:'CHECK_UPDATE'}).catch(()=>null);
  await showUpdateInfo(info);
}
$('updateNow')?.addEventListener('click',async()=>{
  const r=await send({type:'OPEN_UPDATE'});
  if(r?.error)flash(r.error,'error');
});
$('updateLater')?.addEventListener('click',()=>{if($('updateNotice'))$('updateNotice').style.display='none'});

$('connectGmail').onclick=async()=>{const r=await send({type:'CONNECT_GMAIL'});flash(r.message||r.error,r.error?'error':'success');await checkConnections()};
$('checkConnections').onclick=checkConnections;
$('startAuto').onclick=async()=>{const r=await send({type:'START_AUTOMATIC'});if(r?.error)flash(r.error,'error');refresh()};
$('pause').onclick=async()=>{const r=await send({type:'PAUSE'});flash(r.message||r.error,r.error?'error':'success');refresh()};

$('saveContract').onclick=async()=>{
  let deadline=null;const dv=$('contractDeadline').value;if(dv){const d=new Date(dv);if(!isNaN(d))deadline=d.toISOString()}
  const contract={title:$('contractTitle').value.trim(),agency:$('contractAgency').value.trim(),solicitationNumber:$('contractSolicitation').value.trim(),url:$('contractUrl').value.trim(),scope:$('contractScope').value.trim(),deadline};
  const c={...state.campaign,contract};
  const r=await send({type:'SAVE_CAMPAIGN',campaign:c});
  flash(r.message||r.error,r.error?'error':'success');if(!r.error)await clearDraft();refresh();
};
$('clearContract').onclick=async()=>{const c={...state.campaign,contract:null};const r=await send({type:'SAVE_CAMPAIGN',campaign:c});flash(r.message||r.error,r.error?'error':'success');refresh()};

$('regionUS').onclick=async()=>{const c={...state.campaign,region:'US'};await send({type:'SAVE_CAMPAIGN',campaign:c});refresh()};
$('regionUK').onclick=async()=>{const c={...state.campaign,region:'UK'};await send({type:'SAVE_CAMPAIGN',campaign:c});refresh()};

async function saveCampaign(){
  const c={
    ...state.campaign,
    us:{senderName:$('usSenderName').value.trim(),senderTitle:$('usSenderTitle').value.trim(),senderCompany:$('usSenderCompany').value.trim(),senderEmail:$('usSenderEmail').value.trim(),senderPhone:$('usSenderPhone').value.trim(),senderWebsite:$('usSenderWebsite').value.trim()},
    uk:{senderName:$('ukSenderName').value.trim(),senderTitle:$('ukSenderTitle').value.trim(),senderCompany:$('ukSenderCompany').value.trim(),senderEmail:$('ukSenderEmail').value.trim(),senderPhone:$('ukSenderPhone').value.trim(),senderWebsite:$('ukSenderWebsite').value.trim()},
    name:$('campaignName').value.trim(),serviceContext:$('serviceContext').value.trim(),objective:$('objective').value.trim(),tone:$('tone').value,dailyLimit:Math.max(1,Number($('dailyLimit').value)||25)
  };
  const r=await send({type:'SAVE_CAMPAIGN',campaign:c});
  flash(r.message||r.error,r.error?'error':'success');if(!r.error)await clearDraft();refresh();
}
$('saveCampaign').onclick=saveCampaign;

async function saveSettings(){
  const min=Math.max(0,Number($('minDelay').value)||30),max=Math.max(min,Number($('maxDelay').value)||60);
  const settings={...state.settings,geminiApiKey:$('geminiApiKey').value.trim(),geminiModel:$('geminiModel').value.trim()||'gemini-3.5-flash-lite',minDelay:min,maxDelay:max,maxReviews:$('maxReviews').value.trim()===''?null:Math.max(1,Number($('maxReviews').value)||25)};
  const r=await send({type:'SAVE_SETTINGS',settings});
  if(r?.error){flash(r.error,'error');return}
  flash('✓ Settings saved.','success');
  await clearDraft();
  await refresh();await checkConnections();
}
$('saveSettings').onclick=saveSettings;

$('clearUnsent').onclick=async()=>{if(!confirm('Remove all companies that haven\'t been emailed yet? Already-emailed companies are kept and will not be re-emailed.'))return;const r=await send({type:'CLEAR_UNSENT'});flash(r.error||r.message,r.error?'error':'success');refresh()};
$('resetAll').onclick=async()=>{if(!confirm('Reset EVERYTHING? This also clears duplicate-email protection. This cannot be undone.'))return;const r=await send({type:'RESET_ALL'});flash(r.error||r.message,r.error?'error':'success');refresh()};

$('draftInitial').onclick=async()=>{
  const id=$('aiProspect').value;
  const p=state.prospects.find(x=>x.id===id);
  if(!p){flash('Pick a company first.','error');return}
  const r=await send({type:'DRAFT_INITIAL',prospect:p});
  if(r?.error){flash(r.error,'error');return}
  $('draftSubject').value=r.subject||'';
  $('draftBody').value=r.body||'';
};
$('sendDraft').onclick=async()=>{
  const id=$('aiProspect').value;
  const p=state.prospects.find(x=>x.id===id);
  if(!p){flash('Pick a company first.','error');return}
  const r=await send({type:'SEND_MANUAL',prospect:p,subject:$('draftSubject').value,body:$('draftBody').value});
  flash(r?.message||r?.error,r?.error?'error':'success');refresh();
};

// --- Account / plan / upgrade / admin ---
let account=null;
async function loadAccount(){
  if(typingActive)return; // don't let a background session refresh interrupt active typing
  const r=await send({type:'GET_ACCOUNT'});
  if(!r?.ok){
    account=null;
    if(r?.signedOutElsewhere){
      alert(r.error||'This account was signed in on another device.');
      location.reload();
      return;
    }
    const errText=r?.error||'Could not load your plan.';
    if($('planEmail'))$('planEmail').textContent=errText;
    if($('upgradePlanEmail'))$('upgradePlanEmail').textContent=errText;
    if($('settingsAccountEmail'))$('settingsAccountEmail').textContent=errText;
    return;
  }
  account=r.account;
  const capText=account.cap===-1?'Unlimited':`${account.used} / ${account.cap}`;
  const pct=account.cap===-1?100:Math.min(100,(account.used/Math.max(1,account.cap))*100);
  for(const [badgeId,emailId,usageId] of [['planBadge','planEmail','planUsageText'],['upgradePlanBadge','upgradePlanEmail','upgradePlanUsageText']]){
    const b=$(badgeId);
    if(b){b.textContent=account.plan;b.className='planbadge plan-'+account.plan}
    if($(emailId))$(emailId).textContent=account.email;
    if($(usageId))$(usageId).textContent=capText;
  }
  if($('planBarFill'))$('planBarFill').style.width=pct+'%';
  if($('planUpgradeRow'))$('planUpgradeRow').style.display=account.plan==='FREE'?'flex':'none';
  if($('settingsAccountEmail'))$('settingsAccountEmail').textContent=`Signed in as ${account.email} · ${account.plan} plan`;
  if($('adminNavItem'))$('adminNavItem').style.display=account.role==='admin'?'':'none';
}

$('planUpgradeBtn')?.addEventListener('click',()=>{
  document.querySelectorAll('.navitem').forEach(x=>x.classList.remove('active'));
  document.querySelectorAll('.tab').forEach(x=>x.classList.remove('active'));
  document.querySelector('.navitem[data-tab="upgrade"]').classList.add('active');
  $('upgrade').classList.add('active');
});

function showUpgradePay(plan,amount){
  $('upgradePayCard').style.display='block';
  $('upgradeAmount').textContent=amount;
  $('upgradeWhatsapp').href=`https://wa.me/2347031457157?text=${encodeURIComponent(`Hi, I've paid for the ${plan} plan on SBA Outreach Assistant. My account email is ${account?.email||''}.`)}`;
  $('upgradeIvePaid').onclick=async()=>{
    $('upgradeMsg').textContent='Submitting…';
    const r=await send({type:'SUBMIT_PAYMENT',plan,amount});
    $('upgradeMsg').textContent=r?.ok?'Recorded — we\'ll activate your plan once payment is confirmed on WhatsApp.':(r?.error||'Could not submit.');
  };
}
$('upgradeVipBtn').onclick=()=>showUpgradePay('VIP','₦5,000/month');
$('upgradeLifetimeBtn').onclick=()=>showUpgradePay('LIFETIME','₦20,000 one-time');

$('sbaLogoutBtn').onclick=async()=>{
  if(!confirm('Sign out of SBA Outreach Assistant?'))return;
  await send({type:'SBA_SIGN_OUT'});
  location.reload();
};

async function loadAdmin(){
  const list=$('adminList');
  list.textContent='Loading…';
  const r=await send({type:'ADMIN_LIST_USERS'});
  if(!r?.ok){list.textContent=r?.error||'Could not load users.';return}
  if(!r.users.length){list.textContent='No users yet.';return}
  const myId=account?.id;
  list.innerHTML=r.users.map(u=>{
    const isMe=u.id===myId;
    const actions=isMe
      ? `<span class="tag">Your account</span>`
      : `<div class="actions">
          <button class="secondary" data-uid="${u.id}" data-plan="VIP">Activate VIP</button>
          <button class="secondary" data-uid="${u.id}" data-plan="LIFETIME">Activate Lifetime</button>
          <button class="danger" data-uid="${u.id}" data-plan="FREE">Set Free</button>
        </div>`;
    return `
    <div class="adminrow">
      <div><b>${u.email}</b><div class="small">Plan: <b>${u.plan}</b> · Status: <b>${u.status}</b></div></div>
      ${actions}
    </div>`;
  }).join('');
  list.querySelectorAll('button[data-uid]').forEach(btn=>{
    btn.onclick=async()=>{
      const r2=await send({type:'ADMIN_SET_PLAN',userId:btn.dataset.uid,plan:btn.dataset.plan});
      flash(r2?.ok?'Updated.':(r2?.error||'Could not update.'),r2?.ok?'success':'error');
      loadAdmin();
    };
  });
}
$('adminRefresh').onclick=loadAdmin;
document.querySelector('.navitem[data-tab="admin"]').addEventListener('click',loadAdmin);

refresh().then(checkConnections).then(restoreDraftIfFresh).then(loadAccount).then(checkExtensionUpdate);

// The login screen (auth-gate.js) can hide itself the moment sign-in
// succeeds, but that doesn't tell the rest of this popup -- which may
// have already run its "am I signed in?" check once, before login --
// to check again. Listen for the session actually changing in storage
// and refresh immediately when it does, rather than only on next open.
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local' || !changes.sba_session) return;
  if (changes.sba_session.newValue && !typingActive) {
    loadAccount();
    refresh();
    checkConnections();
  }
});
let typingActive=false;
document.addEventListener('focusin',e=>{if(['INPUT','TEXTAREA','SELECT'].includes(e.target.tagName))typingActive=true});
document.addEventListener('focusout',e=>{if(['INPUT','TEXTAREA','SELECT'].includes(e.target.tagName))typingActive=false});
poll=setInterval(()=>{if(!typingActive)refresh()},1000);
