# Maps Outreach Assistant v1.0.0

Finds companies on Google Maps, discovers their email from their own website, and sends personalized outreach about an opportunity/contract you provide — via your Gmail, no local server required. Supports separate US and UK sender identities/signatures.

## How it works
1. You search Google Maps normally (e.g. "family support services los angeles") and leave that tab open.
2. You save the opportunity/contract you're reaching out about (Opportunity tab) and your US or UK sender identity (Campaign tab).
3. Click Start Automatic Outreach. For each visible company it: opens that company's website in a hidden background tab to look for a contact email, drafts a personalized email referencing your opportunity via Gemini, sends it through your Gmail, then moves to the next company.
4. When it runs out of visible companies, it scrolls the Maps results list for more (the same way you would) and keeps going until it reaches the real end of the list.

## Setup
1. Load this folder as an unpacked extension in `chrome://extensions` (Developer mode → Load unpacked). Its ID should be **gihlgnhbccmpbemgkgnllnjonhnbcopd** — fixed permanently via the `key` in manifest.json, so it never changes across reinstalls.
2. In Google Cloud Console, create a **new** OAuth 2.0 Client ID (Chrome Extension type) with Item ID `gihlgnhbccmpbemgkgnllnjonhnbcopd`. You can reuse the same Google Cloud project as your SBA Outreach Assistant extension (or the Google Auth Platform "Branding" screen must have an app name + support email set for the project first, if you haven't already). Copy the resulting Client ID.
3. Open `manifest.json` and replace `REPLACE_WITH_YOUR_OAUTH_CLIENT_ID.apps.googleusercontent.com` with that Client ID. Reload the extension.
4. Get a free Gemini API key (no card) at https://aistudio.google.com/apikey, and paste it into Settings.
5. In Settings, Connect Gmail.
6. In Campaign, fill in your US and/or UK sender identity, then pick which region is active for the search you're about to run.
7. In Opportunity, paste in the real details and scope of what you're reaching out about.

## Important permission note
This extension requests access to all websites (`<all_urls>`). That's required for the email-discovery step — it needs to open and read arbitrary company websites to find a contact email. It only ever visits sites related to companies found in your Maps search, in hidden background tabs it closes immediately after checking, and does not run on every page you browse.

## Known limitations (v1, expect to iterate)
- **Email discovery is heuristic.** It checks the homepage plus a few common contact-page paths (`/contact`, `/contact-us`, etc.) for a `mailto:` link or an email-shaped string. Sites that only offer a contact *form*, or bury the email elsewhere, will be skipped with no email found — this is a real limitation, not a bug to report as broken.
- **Google Maps' DOM changes periodically.** Extraction in `maps-content.js` uses relatively stable `role="feed"` / `aria-label` selectors, but Google does restructure this UI from time to time. If listings stop being found, that selector logic is the first place to fix.
- **No follow-up sequence yet** (unlike the SBA extension) — this sends one initial email per company. Ask if you want follow-ups added.
- A 40-scroll safety cap and repeat-batch detection are both in place to prevent the kind of runaway loop the SBA extension hit early on.

### v1.5.0
- **Fixed every company getting skipped as "no website."** Google Maps' search-results list cards don't include an external website link at all -- that only appears on a place's own detail page. The extension was checking the list card, finding nothing, and skipping everyone before ever getting a real look. It now opens a company's own Maps listing first when the list view didn't show a website, reads the real Website link from there (Google's own `data-item-id="authority"` attribute), and only then checks that site for an email. Only genuinely skips as "no website" if the detail page doesn't have one either.


## Manual update system
The extension checks `https://dgtandassociatesuk.tech/extension/version.json` for a newer release and shows an in-app update notice when one is available. Because this is manually installed as an unpacked Chrome extension rather than distributed through the Chrome Web Store, the final replacement/reload of the extension files remains a user action.
