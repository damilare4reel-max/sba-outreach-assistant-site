# Email open tracking

Run `email_tracking.sql` in the Supabase SQL Editor. Deploy the function code in `supabase/functions/email-open/index.ts` as the Supabase function named `email-tracking`.

Because the tracking pixel is a public endpoint loaded by recipients, disable the Edge Function built-in JWT verification for `email-tracking`. The function only records the tracking ID against a row created by the authenticated extension.

The extension calls: `https://uauvktlbxywlzdmxxzrj.supabase.co/functions/v1/email-tracking?t=<tracking-id>`
