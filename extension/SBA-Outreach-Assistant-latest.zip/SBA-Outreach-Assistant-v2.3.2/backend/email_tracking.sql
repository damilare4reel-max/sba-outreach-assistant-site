create table if not exists public.email_tracking (
  tracking_id uuid primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  prospect_id text,
  recipient_email text,
  subject text,
  gmail_message_id text,
  sent_at timestamptz,
  first_opened_at timestamptz,
  last_opened_at timestamptz,
  open_count integer not null default 0,
  created_at timestamptz not null default now()
);

alter table public.email_tracking enable row level security;

drop policy if exists "users can read own email tracking" on public.email_tracking;
create policy "users can read own email tracking" on public.email_tracking
for select using (auth.uid() = user_id);

drop policy if exists "users can insert own email tracking" on public.email_tracking;
create policy "users can insert own email tracking" on public.email_tracking
for insert with check (auth.uid() = user_id);

drop policy if exists "users can update own email tracking" on public.email_tracking;
create policy "users can update own email tracking" on public.email_tracking
for update using (auth.uid() = user_id) with check (auth.uid() = user_id);

create index if not exists email_tracking_user_id_idx on public.email_tracking(user_id);
create index if not exists email_tracking_recipient_idx on public.email_tracking(recipient_email);
