import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const pixel = Uint8Array.from(atob("R0lGODlhAQABAIAAAAAAAP///ywAAAAAAQABAAACAUwAOw=="), c => c.charCodeAt(0));
const cors = { "Access-Control-Allow-Origin": "*", "Cache-Control": "no-store, no-cache, must-revalidate, proxy-revalidate, max-age=0", "Content-Type": "image/gif" };

Deno.serve(async (req) => {
  try {
    const url = new URL(req.url);
    const trackingId = url.searchParams.get("t") || url.searchParams.get("id");
    if (trackingId) {
      const key = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || Deno.env.get("SUPABASE_SECRET_KEY");
      if (key) {
        const supabase = createClient(Deno.env.get("SUPABASE_URL")!, key);
        const { data } = await supabase.from("email_tracking").select("open_count,first_opened_at").eq("tracking_id", trackingId).maybeSingle();
        if (data) {
          const now = new Date().toISOString();
          await supabase.from("email_tracking").update({ open_count: Number(data.open_count || 0) + 1, first_opened_at: data.first_opened_at || now, last_opened_at: now }).eq("tracking_id", trackingId);
        }
      }
    }
  } catch (_) {}
  return new Response(pixel, { status: 200, headers: cors });
});
