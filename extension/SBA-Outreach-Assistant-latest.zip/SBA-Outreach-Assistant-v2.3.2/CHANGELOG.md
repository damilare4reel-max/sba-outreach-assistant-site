# v2.3.2

- Improved Gmail Sent-folder tracking detection.
- Added exact-subject fallback lookup when Gmail does not expose message IDs or recipient addresses.
- Improved Gmail row and subject detection and tick rendering.

# v2.3.0 — Gmail Sent-folder tracking ticks

- Adds a Gmail desktop content script for `mail.google.com`.
- Shows Mailsuite-style two-check status beside tracked messages in Gmail lists.
- Sent but not opened: first check green, second check gray.
- Opened: both checks green.
- Uses the existing Supabase `email_tracking` records and the Gmail API message ID stored by the extension.
- Keeps the existing Gmail Workspace add-on sidebar tracking and all v2.2.9 functionality unchanged.

## 2.2.9
- Fixed the tracking pixel to call the deployed Supabase `email-tracking` function with the correct `id` query parameter.

# Changelog

## 2.2.7
- Added automatic customer activation emails when an admin activates VIP or Lifetime.
- Activation emails are sent through the admin's connected Gmail account.
- Prevents duplicate activation emails when the same plan is already active.
- Admin UI reports whether the activation email was sent.

# Changelog

## 2.2.6
- Added first-open desktop notifications.
- Added optional first-open notification email to the connected Gmail inbox.
- Added a one-minute background tracking check so notifications can arrive without opening the extension.
- Added Settings controls for open notifications.
- Notification wording accurately describes an image-tracking open and does not claim guaranteed human reading.

## 2.2.5
- Restored Automatic Follow-ups with configurable 3/7/14-day sequence.
- Follow-ups are gated on recorded opens and can stop when a Gmail reply is detected.
- Added a manual recipient/draft workflow in AI Writer so users can enter any recipient themselves.
- Fixed open-tracking endpoint to use the deployed `email-tracking` function.
- Preserved saved-prospect workflow, deliverability checks, timestamps, search/filtering, and recovery.

## 2.2.2
- Added prospect search and status filtering.
- Added sent/skipped/failed activity timestamps and failure reasons.
- Added a pre-send deliverability review with automatic AI rewrite for higher-risk drafts.
- Stored deliverability score with sent prospects.


### v2.2.1
- Removed the duplicate Help sidebar item; the full How to Use guide is now the single help entry.
- Added automatic outreach recovery/watchdog behavior for interrupted or stalled runs when pending prospects remain.
- Start button now becomes "Resume Automatic Outreach" when unsent work remains or a recoverable error exists.
- Added website-based version checking and an in-app update notification with a stable download link.

### v2.2.0
- New "How to Use" tab in the sidebar -- a real in-app guide for customers covering first-time setup, running a campaign, other features, and common questions. No more figuring it out from scratch.


## v2.2.3
- Added optional email-open tracking via Supabase tracking pixel.
- Prospects can show first/last open time and open count.
- Tracking gracefully falls back if the backend is not deployed.


## 2.2.8
- Fixed popup initialization error caused by `setCheck` being declared after first use.


## v2.3.1
- Improved Gmail Sent-folder tracking ticks.
- Added fallback to the connected Gmail account email when Gmail's Sent-list DOM does not expose recipient email.
- Improved row/subject detection and message-id fallbacks.
- Keeps existing Supabase tracking and Gmail add-on integration unchanged.
