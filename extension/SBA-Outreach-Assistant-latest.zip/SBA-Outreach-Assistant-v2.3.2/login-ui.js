
function togglePasswordVisibility(id){
  const input=document.getElementById(id);
  if(!input) return;
  input.type = input.type === 'password' ? 'text' : 'password';
}

function enableEmailSuggestion(){
  const email=document.querySelector('input[type="email"]');
  if(email){
    email.setAttribute('autocomplete','email');
  }
}

document.addEventListener('DOMContentLoaded', enableEmailSuggestion);
