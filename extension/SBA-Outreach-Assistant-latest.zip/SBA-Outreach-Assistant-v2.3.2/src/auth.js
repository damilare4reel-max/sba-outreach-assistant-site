
const SBA_SUPABASE_URL = "https://uauvktlbxywlzdmxxzrj.supabase.co";
const SBA_SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVhdXZrdGxieHl3bHpkbXh4enJqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODk1NTk5NjksImV4cCI6MjEwNTEzNTk2OX0.Qb6Mip2OjAV3VHA-Xd9a-fhytIQm3Ws6FNBbfXvtUvk";

async function sbaLogin(email,password){
 const r=await fetch(SBA_SUPABASE_URL+"/auth/v1/token?grant_type=password",{
  method:"POST",
  headers:{"apikey":SBA_SUPABASE_KEY,"Content-Type":"application/json"},
  body:JSON.stringify({email,password})
 });
 const data=await r.json();
 if(!r.ok) throw new Error(data.error_description||data.msg||"Login failed");
 await chrome.storage.local.set({sba_session:data});
 return data;
}

async function sbaSignup(email,password){
 const r=await fetch(SBA_SUPABASE_URL+"/auth/v1/signup",{
  method:"POST",
  headers:{"apikey":SBA_SUPABASE_KEY,"Content-Type":"application/json"},
  body:JSON.stringify({email,password})
 });
 const data=await r.json();
 if(!r.ok) throw new Error(data.msg||"Signup failed");
 return data;
}

async function sbaLogout(){await chrome.storage.local.remove("sba_session");}

async function sbaRecover(email){
 const r=await fetch(SBA_SUPABASE_URL+"/auth/v1/recover",{
  method:"POST",
  headers:{"apikey":SBA_SUPABASE_KEY,"Content-Type":"application/json"},
  body:JSON.stringify({email})
 });
 if(!r.ok){const data=await r.json().catch(()=>({}));throw new Error(data.msg||"Could not send reset email")}
}

// One account, one active device. Called right after a successful
// login/signup with a freshly generated random token -- this always
// overwrites the "owning device" on the server, which is what causes
// any other device to get signed out next time it checks in.
async function sbaClaimDevice(accessToken,deviceToken,label){
 const r=await fetch(SBA_SUPABASE_URL+"/rest/v1/rpc/claim_device",{
  method:"POST",
  headers:{"apikey":SBA_SUPABASE_KEY,"Authorization":`Bearer ${accessToken}`,"Content-Type":"application/json"},
  body:JSON.stringify({p_device_token:deviceToken,p_device_label:label||null})
 });
 if(!r.ok){const data=await r.json().catch(()=>({}));throw new Error(data.message||"Could not register this device.")}
}
function sbaNewDeviceToken(){
 return (crypto.randomUUID?crypto.randomUUID():(Date.now().toString(36)+Math.random().toString(36).slice(2)));
}

// ---- Google Sign-In ----
// This is a SEPARATE Google OAuth client from the one used for Gmail
// sending (that one is "Chrome Extension" type, driven by chrome.identity.
// getAuthToken via manifest.json). This flow needs a "Web application"
// type client because chrome.identity.launchWebAuthFlow requires a
// redirect URI we control the format of -- Chrome Extension-type clients
// don't support that. See README for the exact setup steps.
const SBA_GOOGLE_WEB_CLIENT_ID = "146486965679-mf1c2buo1el91bepftkc4m9t6t89m0gr.apps.googleusercontent.com";

function sbaRandomNonce(){
 return btoa(String.fromCharCode(...crypto.getRandomValues(new Uint8Array(32))));
}
async function sbaHashNonce(nonce){
 const digest=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(nonce));
 return Array.from(new Uint8Array(digest)).map(b=>b.toString(16).padStart(2,'0')).join('');
}

async function sbaGoogleSignIn(){
 if(!SBA_GOOGLE_WEB_CLIENT_ID||SBA_GOOGLE_WEB_CLIENT_ID.startsWith('REPLACE_')){
   throw new Error('Google sign-in is not set up yet -- see README for the setup steps.');
 }
 const redirectUri=chrome.identity.getRedirectURL();
 const nonce=sbaRandomNonce();
 const hashedNonce=await sbaHashNonce(nonce);
 const authUrl='https://accounts.google.com/o/oauth2/v2/auth'
   +'?client_id='+encodeURIComponent(SBA_GOOGLE_WEB_CLIENT_ID)
   +'&response_type=id_token'
   +'&redirect_uri='+encodeURIComponent(redirectUri)
   +'&scope='+encodeURIComponent('openid email profile')
   +'&nonce='+encodeURIComponent(hashedNonce)
   +'&prompt=select_account';

 const redirectedTo=await new Promise((resolve,reject)=>{
   chrome.identity.launchWebAuthFlow({url:authUrl,interactive:true},(result)=>{
     if(chrome.runtime.lastError||!result)return reject(new Error(chrome.runtime.lastError?.message||'Google sign-in was cancelled.'));
     resolve(result);
   });
 });

 const hashParams=new URLSearchParams(new URL(redirectedTo).hash.slice(1));
 const idToken=hashParams.get('id_token');
 if(!idToken)throw new Error('Google did not return an ID token. Try again.');

 const r=await fetch(SBA_SUPABASE_URL+"/auth/v1/token?grant_type=id_token",{
  method:"POST",
  headers:{"apikey":SBA_SUPABASE_KEY,"Content-Type":"application/json"},
  body:JSON.stringify({provider:"google",id_token:idToken,nonce})
 });
 const data=await r.json().catch(()=>({}));
 if(!r.ok)throw new Error(data.error_description||data.msg||data.message||"Google sign-in failed.");
 await chrome.storage.local.set({sba_session:data});
 return data;
}
