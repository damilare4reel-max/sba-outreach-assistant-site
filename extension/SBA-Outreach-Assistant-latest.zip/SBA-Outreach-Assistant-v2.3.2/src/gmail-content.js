(() => {
  const TICK_ATTR = 'data-sba-tracking-ticks';
  const CACHE_TTL = 30000;
  const cache = new Map();
  let scanTimer = null;
  let scanInFlight = false;

  const clean = (v) => String(v || '').replace(/\s+/g, ' ').trim();

  function getMessageIds(row) {
    const out = [];
    const attrs = [
      'data-legacy-message-id',
      'data-message-id',
      'data-legacy-thread-id',
      'data-thread-id'
    ];
    for (const attr of attrs) {
      const nodes = [];
      if (row.hasAttribute(attr)) nodes.push(row);
      nodes.push(...row.querySelectorAll(`[${attr}]`));
      for (const node of nodes) {
        const value = node.getAttribute(attr);
        if (value && !out.includes(value)) out.push(value);
      }
    }
    return out;
  }

  function getSubjectCandidates(row) {
    const candidates = [];
    const selectors = [
      '.bog',
      '.y6',
      'td.xY .y6',
      'td.xY .bog'
    ];

    for (const selector of selectors) {
      for (const el of row.querySelectorAll(selector)) {
        const text = clean(el.textContent);
        if (!text) continue;
        if (/^\d{1,2}:\d{2}\s*(AM|PM)?$/i.test(text)) continue;
        if (!candidates.includes(text)) candidates.push(text);
      }
    }

    // Last-resort extraction from the row's visible subject/snippet area.
    if (!candidates.length) {
      const area = row.querySelector('td.xY');
      if (area) {
        const spans = Array.from(area.querySelectorAll('span'))
          .map(el => clean(el.textContent))
          .filter(Boolean);
        for (const text of spans) {
          if (!/^\d{1,2}:\d{2}\s*(AM|PM)?$/i.test(text) && !candidates.includes(text)) {
            candidates.push(text);
          }
        }
      }
    }

    return candidates.slice(0, 5);
  }

  function getRecipient(row) {
    const candidates = Array.from(row.querySelectorAll('[email], [data-hovercard-id], [aria-label]'));
    for (const el of candidates) {
      const values = [
        el.getAttribute('email'),
        el.getAttribute('data-hovercard-id'),
        el.getAttribute('aria-label')
      ].filter(Boolean);
      for (const value of values) {
        const match = String(value).match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i);
        if (match) return match[0].toLowerCase();
      }
    }
    return '';
  }

  function looksLikeSentRow(row) {
    const text = clean(row.textContent || '');
    return /(^|\s)To:\s*/i.test(text) ||
      !!row.querySelector('[data-tooltip*="To"], [aria-label^="To "]');
  }

  function getTarget(row) {
    // Prefer the stable subject cell. Insert the ticks before its content.
    return row.querySelector('td.xY') || row.querySelector('.bog') || row.querySelector('.y6');
  }

  function removeOldTick(target) {
    target.querySelectorAll(`[${TICK_ATTR}]`).forEach(el => el.remove());
  }

  function renderTicks(target, tracking) {
    removeOldTick(target);
    if (!tracking) return;

    const opened = Number(tracking.open_count || 0) > 0;
    const wrap = document.createElement('span');
    wrap.setAttribute(TICK_ATTR, '1');
    wrap.setAttribute('aria-label', opened ? 'Opened by recipient' : 'Sent, not opened');
    wrap.setAttribute('title', opened
      ? `Opened ${tracking.open_count || 0} time${Number(tracking.open_count || 0) === 1 ? '' : 's'}`
      : 'Sent — not opened yet');
    Object.assign(wrap.style, {
      display: 'inline-flex',
      alignItems: 'center',
      gap: '0',
      marginRight: '7px',
      fontSize: '14px',
      fontWeight: '700',
      fontFamily: 'Arial, sans-serif',
      verticalAlign: 'middle',
      whiteSpace: 'nowrap',
      lineHeight: '1',
      position: 'relative',
      zIndex: '2'
    });

    const first = document.createElement('span');
    first.textContent = '✓';
    first.style.color = '#188038';

    const second = document.createElement('span');
    second.textContent = '✓';
    second.style.color = opened ? '#188038' : '#9aa0a6';

    wrap.append(first, second);
    target.insertBefore(wrap, target.firstChild);
  }

  function askBackground(messageIds, subjects, recipient) {
    const ids = Array.isArray(messageIds) ? messageIds : [];
    const subs = Array.isArray(subjects) ? subjects : [];
    const key = `${ids.join('|')}|${subs.join('|')}|${recipient}`;
    const cached = cache.get(key);
    if (cached && Date.now() - cached.at < CACHE_TTL) {
      return Promise.resolve(cached.tracking);
    }

    return new Promise((resolve) => {
      chrome.runtime.sendMessage({
        type: 'GET_GMAIL_TRACKING',
        messageIds: ids,
        subjects: subs,
        messageId: ids[0] || '',
        subject: subs[0] || '',
        recipient
      }, (response) => {
        const tracking = response?.ok ? (response.tracking || null) : null;
        cache.set(key, { at: Date.now(), tracking });
        resolve(tracking);
      });
    });
  }

  function getGmailAccount() {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: 'GET_GMAIL_ACCOUNT' }, (response) => {
        resolve(String(response?.email || '').trim().toLowerCase());
      });
    });
  }

  async function scan() {
    if (scanInFlight) return;
    if (!location.hostname.includes('mail.google.com')) return;

    const rows = Array.from(document.querySelectorAll('tr.zA'));
    if (!rows.length) return;

    scanInFlight = true;
    try {
      const accountEmail = await getGmailAccount();
      const jobs = [];

      for (const row of rows) {
        if (!looksLikeSentRow(row)) continue;

        const target = getTarget(row);
        if (!target) continue;

        const messageIds = getMessageIds(row);
        const subjects = getSubjectCandidates(row);
        const recipient = getRecipient(row);

        if (!messageIds.length && !subjects.length) continue;

        // Use the visible recipient if Gmail exposes an address. If not,
        // leave it blank so the background can perform an exact-subject lookup.
        const fallbackRecipient = recipient || '';

        jobs.push(
          askBackground(messageIds, subjects, fallbackRecipient)
            .then((tracking) => renderTicks(target, tracking))
            .catch(() => {})
        );
      }

      await Promise.all(jobs);
    } finally {
      scanInFlight = false;
    }
  }

  function scheduleScan(delay = 350) {
    clearTimeout(scanTimer);
    scanTimer = setTimeout(scan, delay);
  }

  const observer = new MutationObserver(() => scheduleScan(500));
  observer.observe(document.documentElement, { childList: true, subtree: true });

  window.addEventListener('hashchange', () => scheduleScan(200));
  document.addEventListener('click', () => scheduleScan(500), true);
  window.addEventListener('popstate', () => scheduleScan(300));

  scheduleScan(800);
})();
