const PLAN_LIMITS={
 FREE:10,
 VIP:500,
 LIFETIME:-1
};

function getPlanLimit(plan){
 return PLAN_LIMITS[plan] ?? 10;
}

function canSendEmail(plan,used){
 const limit=getPlanLimit(plan);
 if(limit===-1) return true;
 return used < limit;
}
