(async () => {
  const gate = document.getElementById("sbaAuthGate");
  const msg = document.getElementById("sbaAuthMsg");
  const title = document.getElementById("sbaAuthTitle");
  const sub = document.getElementById("sbaAuthSub");
  const submitBtn = document.getElementById("sbaLogin");
  const toggleWrap = document.getElementById("sbaToggleWrap");
  const forgotWrap = document.getElementById("sbaForgotWrap");
  const forgotLink = document.getElementById("sbaForgot");
  const emailEl = document.getElementById("sbaEmail");
  const passEl = document.getElementById("sbaPassword");
  const eyeToggle = document.getElementById("sbaEyeToggle");
  const googleBtn = document.getElementById("sbaGoogle");

  function hideGate() { if (gate) gate.style.display = "none"; }
  function showGate() { if (gate) gate.style.display = "flex"; }

  // Read the real version from manifest.json instead of a hardcoded
  // string that's easy to forget to update on every release.
  const versionEl = document.getElementById("sbaAuthVersion");
  if (versionEl) versionEl.textContent = "v" + chrome.runtime.getManifest().version;

  // Already have a session? Skip the gate entirely. Also keep listening --
  // if the session appears or disappears in storage while this popup
  // instance is open (e.g. a login completes, or another tab signs out),
  // react immediately instead of only checking once at load.
  const initial = (await chrome.storage.local.get("sba_session")).sba_session;
  if (initial) { hideGate(); return; }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local" || !changes.sba_session) return;
    if (changes.sba_session.newValue) hideGate(); else showGate();
  });

  // Generates a fresh device token, stores it locally, and tells the
  // server this device now owns the account -- see single-device.sql.
  async function claimThisDevice(session) {
    try {
      const token = sbaNewDeviceToken();
      const label = (navigator.userAgentData?.platform || navigator.platform || "device");
      await sbaClaimDevice(session.access_token, token, label);
      await chrome.storage.local.set({ sba_device_token: token });
    } catch (e) {
      console.error("Could not claim this device:", e);
    }
  }

  let mode = "login"; // "login" | "signup"

  function bindToggle() {
    const el = document.getElementById("sbaToggleMode");
    if (el) el.onclick = (e) => {
      e.preventDefault();
      setMode(mode === "login" ? "signup" : "login");
    };
  }

  function setMode(next) {
    mode = next;
    msg.textContent = "";
    if (mode === "login") {
      title.textContent = "Welcome Back";
      sub.textContent = "Sign in to your SBA Outreach Assistant account";
      submitBtn.textContent = "Sign In →";
      forgotWrap.style.display = "";
      toggleWrap.innerHTML = "Don't have an account? <a href=\"#\" id=\"sbaToggleMode\">Create Account</a>";
    } else {
      title.textContent = "Create Account";
      sub.textContent = "Start finding and winning government contracts";
      submitBtn.textContent = "Create Account →";
      forgotWrap.style.display = "none";
      toggleWrap.innerHTML = "Already have an account? <a href=\"#\" id=\"sbaToggleMode\">Sign In</a>";
    }
    bindToggle();
  }

  bindToggle();

  eyeToggle.onclick = () => {
    passEl.type = passEl.type === "password" ? "text" : "password";
    eyeToggle.style.opacity = passEl.type === "text" ? "1" : ".5";
  };

  forgotLink.onclick = async (e) => {
    e.preventDefault();
    const email = emailEl.value.trim();
    if (!email) { msg.style.color = "#a83c2e"; msg.textContent = "Enter your email above first, then click this again."; return; }
    msg.style.color = "#68766e";
    msg.textContent = "Sending reset link…";
    try {
      await sbaRecover(email);
      msg.style.color = "#3f7a4e";
      msg.textContent = "Reset link sent. Check your inbox.";
    } catch (err) {
      msg.style.color = "#a83c2e";
      msg.textContent = err.message;
    }
  };

  googleBtn.onclick = async (e) => {
    e.preventDefault();
    googleBtn.disabled = true;
    msg.style.color = "#68766e";
    msg.textContent = "Opening Google sign-in…";
    try {
      const session = await sbaGoogleSignIn();
      await claimThisDevice(session);
      msg.textContent = "";
      hideGate();
    } catch (err) {
      msg.style.color = "#a83c2e";
      msg.textContent = err.message;
    } finally {
      googleBtn.disabled = false;
    }
  };

  submitBtn.onclick = async () => {
    const email = emailEl.value.trim();
    const password = passEl.value;
    if (!email || !password) {
      msg.style.color = "#a83c2e";
      msg.textContent = "Enter both your email and password.";
      return;
    }
    submitBtn.disabled = true;
    const originalText = submitBtn.textContent;
    submitBtn.textContent = mode === "login" ? "Signing in…" : "Creating account…";
    msg.style.color = "#68766e";
    msg.textContent = "";
    try {
      if (mode === "login") {
        const session = await sbaLogin(email, password);
        await claimThisDevice(session);
        hideGate();
      } else {
        await sbaSignup(email, password);
        msg.style.color = "#3f7a4e";
        msg.textContent = "Account created. Signing you in…";
        try {
          const session = await sbaLogin(email, password);
          await claimThisDevice(session);
          hideGate();
        } catch {
          msg.textContent = "Account created. Check your email to confirm, then sign in.";
          setMode("login");
        }
      }
    } catch (err) {
      msg.style.color = "#a83c2e";
      msg.textContent = err.message;
      submitBtn.textContent = originalText;
    } finally {
      submitBtn.disabled = false;
      if (submitBtn.textContent.endsWith("…")) submitBtn.textContent = originalText;
    }
  };

  setMode("login");
})().catch(e => console.error("SBA auth-gate failed to initialize:", e));
