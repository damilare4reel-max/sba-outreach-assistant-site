function clean(s){return (s||'').replace(/\s+/g,' ').trim()}

// Google Maps' results panel is a scrollable feed (role="feed") of place
// cards. Each card is wrapped in an <a> whose href points at /maps/place/
// and whose aria-label is the business name. This structure is more stable
// than Maps' obfuscated class names, but Google does change it periodically
// -- if extraction stops finding rows, this is the first place to look.
function getFeed(){return document.querySelector('div[role="feed"]')}

function extractListings(){
  const feed=getFeed();
  if(!feed) return [];
  const anchors=[...feed.querySelectorAll('a[href*="/maps/place/"]')];
  const seen=new Set();
  const out=[];
  for(const a of anchors){
    const name=a.getAttribute('aria-label')||'';
    if(!name||seen.has(name))continue;
    seen.add(name);
    // The card is generally the anchor's closest ancestor that also
    // contains the rest of the listing's text (rating, category, phone).
    let card=a;
    for(let i=0;i<4&&card.parentElement;i++){
      card=card.parentElement;
      if(clean(card.innerText).length>name.length+10)break;
    }
    const text=clean(card.innerText||'');
    const websiteLink=[...card.querySelectorAll('a[href]')].find(x=>{
      const href=x.href||'';
      return href&&!href.includes('google.com')&&!href.startsWith('tel:')&&!href.startsWith('javascript:');
    });
    const phone=(text.match(/\(?\d{3}\)?[-.\s]\d{3}[-.\s]\d{4}/)||[])[0]||'';
    out.push({
      name,
      mapsUrl:a.href,
      website:websiteLink?websiteLink.href:'',
      phone,
      rawText:text.slice(0,400)
    });
  }
  return out;
}

// Scrolls the results feed to trigger Maps' infinite-scroll loading of
// more listings. Returns false if no feed is present at all (e.g. the tab
// isn't on a Maps search-results view).
function scrollFeedForMore(){
  const feed=getFeed();
  if(!feed) return false;
  feed.scrollTop=feed.scrollHeight;
  return true;
}

// The list view's collapsed cards usually don't include an external website
// link at all -- that only shows up on a place's own detail page. This
// reads it from there (a[data-item-id="authority"] is Google's own stable
// attribute for the Website button in that panel).
function extractWebsiteFromDetail(){
  const el=document.querySelector('a[data-item-id="authority"]');
  if(el&&el.href)return el.href;
  const alt=[...document.querySelectorAll('a[aria-label]')].find(a=>/^website/i.test(a.getAttribute('aria-label')||''));
  return alt?alt.href:'';
}

chrome.runtime.onMessage.addListener((m,sender,sendResponse)=>{
  if(m.type==='EXTRACT_MAPS_LISTINGS'){
    sendResponse({ok:true,listings:extractListings(),hasFeed:!!getFeed()});
  } else if(m.type==='SCROLL_MAPS_FEED'){
    sendResponse({ok:true,scrolled:scrollFeedForMore()});
  } else if(m.type==='EXTRACT_WEBSITE_DETAIL'){
    sendResponse({ok:true,website:extractWebsiteFromDetail()});
  }
  return true;
});
