// SBA Outreach Assistant Supabase configuration
const SUPABASE_CONFIG = {
  url: "https://uauvktlbxywlzdmxxzrj.supabase.co",
  anonKey: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVhdXZrdGxieHl3bHpkbXh4enJqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODk1NTk5NjksImV4cCI6MjEwNTEzNTk2OX0.Qb6Mip2OjAV3VHA-Xd9a-fhytIQm3Ws6FNBbfXvtUvk"
};
