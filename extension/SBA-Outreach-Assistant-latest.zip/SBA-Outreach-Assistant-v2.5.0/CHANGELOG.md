# v2.3.18 — Maps discovery and contact recovery

- Stops excluding companies because of review count; review count is informational only.
- Makes Google Maps website extraction more tolerant of Maps markup changes and waits/retries before giving up.
- Improves website email discovery by scanning mailto links, visible/HTML email text, common obfuscations, and real internal contact/about/enquiry links before falling back to common paths.
- Keeps the existing strict workflow: finish reading the Maps searches first, then send queued emails one by one.

## v2.3.17
- Added a 5-slot Google Maps search queue in Campaign.
- Automatic Outreach can run up to five saved searches sequentially.
- The extension reads each search to the end, then automatically opens the next search.
- Email sending remains hard-gated until every non-empty search has been fully scanned.
- Blank search slots are skipped and duplicate search terms are ignored.
- Businesses found across multiple searches are deduplicated by their Maps listing.
- If no search terms are saved, the previous single-manual-Maps-tab workflow remains available.
- If no Maps tab is open when a search queue is used, the extension opens Google Maps automatically.

# Changelog

## v2.3.16
- Added Contract / Tender Auto-Fill: paste a complete opportunity or optionally upload a PDF/text document.
- Added AI extraction for title, buyer/agency, procurement reference, tender URL, deadline, and a detailed scope/context summary.
- Added automatic campaign generation for campaign name, service/offer, and outreach objective from the same contract source.
- UK/US procurement language is inferred from the source when clear.
- PDF analysis uses Gemini document understanding; text/Markdown/CSV/JSON uploads are supported as text sources.
- Extracted opportunity and campaign are saved together after analysis.


- Automatic outreach now uses a strict **read/queue first, send second** workflow.
- The extension keeps scrolling through Google Maps until it detects the end of the results.
- Business details and website/email discovery are completed before any email is sent.
- Sending begins only after the full Maps result set has been read.
- Daily send limits apply when sending starts, not while discovery is still running.
- Added end-of-results detection plus retry/refresh handling for stalled Maps feeds.

# v2.3.13

- Reworked AI outreach generation into a conversion-focused government-contracting/tender consultant writer.
- Specific opportunities are now the primary reason for contact; emails explain the opportunity in plain English and connect it to the prospect before positioning the consultant.
- Added explicit US vs UK procurement language guidance.
- AI now presents the consultant as hands-on support for opportunity discovery, fit/requirements review, bid/tender preparation, supporting/technical documentation, and submission support without dumping a generic service list.
- Added stronger low-friction CTAs such as offering an opportunity breakdown, requirements summary, fit check, or bid-readiness checklist.
- Reduced generic AI/sales phrasing and improved subject-line guidance.
- Updated follow-up generation to reinforce the consulting value and give the recipient a useful reason to reply.
- Deliverability rewrites now preserve conversion intent instead of flattening the email into a generic safe-sounding message.

- v2.3.12: improved commitment scanning pagination and explicit call/meeting detection for clearly stated weekday + time messages.
# v2.3.10

- Added Gmail commitment and scheduling monitor.
- Periodically scans Gmail for calls, meetings, follow-ups, deadlines, document requests, and contract-watch commitments.
- Adds explicit meetings/calls with a date and time to the user’s primary Google Calendar with configurable reminders.
- Added Commitments section with manual scan, calendar connection, approval for ambiguous calendar items, dismissal, and monitoring settings.
- Added Google Calendar OAuth scope and connection status.

# v2.3.8

- Fixed UTF-8 email encoding for subjects and message bodies so en dashes, em dashes, curly quotes, accented characters, and other non-ASCII characters render correctly in Gmail.
- Uses RFC 2047 encoding for non-ASCII Subject headers and UTF-8 base64 transfer encoding for MIME text parts.

# Changelog

## v2.3.6
- Moved Gmail Sent-folder tracking ticks into the recipient column, between the recipient name and subject.
- Removed any extra post-tick checkbox/placeholder behavior; only the two tracking ticks are rendered.

# v2.3.5

- Fixed harmless `Extension context invalidated` errors in Gmail when Chrome reloads or updates the unpacked extension while Gmail tabs remain open.
- Gmail content scripts now safely stop background messaging when their extension context has been invalidated.

# v2.3.4 — Today Send Counter

- Added **Emails sent (Today)** to the Dashboard.
- The counter resets automatically when the local calendar day changes.
- Counts successful outreach emails, manual sends, and automatic follow-up emails.
- The existing total **Emails sent** counter remains unchanged.

## v2.3.3
- Google Maps discovery no longer stops after one unchanged batch.
- Automatically retries scrolling when Maps temporarily stops loading new companies.
- Automatically refreshes the same Google Maps search tab after repeated stalls, then continues discovery.
- Keeps the run active until the user pauses it or another existing stop condition (such as the daily send limit) is reached.

# v2.3.2

- Improved Gmail Sent-folder tracking detection.
- Added exact-subject fallback lookup when Gmail does not expose message IDs or recipient addresses.
- Improved Gmail row and subject detection and tick rendering.

# v2.3.0 — Gmail Sent-folder tracking ticks

- Adds a Gmail desktop content script for `mail.google.com`.
- Shows Mailsuite-style two-check status beside tracked messages in Gmail lists.
- Sent but not opened: first check green, second check gray.
- Opened: both checks green.
- Uses the existing Supabase `email_tracking` records and the Gmail API message ID stored by the extension.
- Keeps the existing Gmail Workspace add-on sidebar tracking and all v2.2.9 functionality unchanged.

## 2.2.9
- Fixed the tracking pixel to call the deployed Supabase `email-tracking` function with the correct `id` query parameter.

# Changelog

## 2.2.7
- Added automatic customer activation emails when an admin activates VIP or Lifetime.
- Activation emails are sent through the admin's connected Gmail account.
- Prevents duplicate activation emails when the same plan is already active.
- Admin UI reports whether the activation email was sent.

# Changelog

## 2.2.6
- Added first-open desktop notifications.
- Added optional first-open notification email to the connected Gmail inbox.
- Added a one-minute background tracking check so notifications can arrive without opening the extension.
- Added Settings controls for open notifications.
- Notification wording accurately describes an image-tracking open and does not claim guaranteed human reading.

## 2.2.5
- Restored Automatic Follow-ups with configurable 3/7/14-day sequence.
- Follow-ups are gated on recorded opens and can stop when a Gmail reply is detected.
- Added a manual recipient/draft workflow in AI Writer so users can enter any recipient themselves.
- Fixed open-tracking endpoint to use the deployed `email-tracking` function.
- Preserved saved-prospect workflow, deliverability checks, timestamps, search/filtering, and recovery.

## 2.2.2
- Added prospect search and status filtering.
- Added sent/skipped/failed activity timestamps and failure reasons.
- Added a pre-send deliverability review with automatic AI rewrite for higher-risk drafts.
- Stored deliverability score with sent prospects.


### v2.2.1
- Removed the duplicate Help sidebar item; the full How to Use guide is now the single help entry.
- Added automatic outreach recovery/watchdog behavior for interrupted or stalled runs when pending prospects remain.
- Start button now becomes "Resume Automatic Outreach" when unsent work remains or a recoverable error exists.
- Added website-based version checking and an in-app update notification with a stable download link.

### v2.2.0
- New "How to Use" tab in the sidebar -- a real in-app guide for customers covering first-time setup, running a campaign, other features, and common questions. No more figuring it out from scratch.


## v2.2.3
- Added optional email-open tracking via Supabase tracking pixel.
- Prospects can show first/last open time and open count.
- Tracking gracefully falls back if the backend is not deployed.


## 2.2.8
- Fixed popup initialization error caused by `setCheck` being declared after first use.


## v2.3.1
- Improved Gmail Sent-folder tracking ticks.
- Added fallback to the connected Gmail account email when Gmail's Sent-list DOM does not expose recipient email.
- Improved row/subject detection and message-id fallbacks.
- Keeps existing Supabase tracking and Gmail add-on integration unchanged.

### v2.3.14
- Fixed malformed recipient addresses such as `privacy\\@example.com` by normalizing escaped `@` before sending.
- Added recipient validation before Gmail API calls so invalid addresses fail with a clear local error instead of `Invalid To header`.


## 2.3.19
- Fixed sender self-open tracking: the extension now blocks its own browser from requesting SBA tracking pixels and removes tracking pixels from the sender's Gmail UI as early as possible.
- Opening a sent email in the sender's own Gmail should no longer register as a recipient open.
- Recipient-side tracking remains unchanged because the blocking rule only applies inside the browser running the extension.
- Note: email open tracking still depends on remote images being loaded by the recipient; it is not guaranteed.

### v2.3.20
- Hardened exhaustive Google Maps discovery: added a structural backstop ("the feed genuinely can't scroll further and the same listings keep appearing") alongside the existing text-based "reached the end of the list" detection, so discovery can't get stuck relying on one exact phrase from Google. There is still no arbitrary page/batch cap -- discovery only stops on a real end-of-list signal.
- The Maps tab is now re-activated before every scroll attempt during discovery, so Chrome can't throttle scrolling if you switch to another tab mid-run.
- Fixed rules/self-open-block.json: the domain had a typo (missing the trailing "j" in the Supabase project ref), which meant the safeguard against your own Gmail preview counting as an "open" was never actually matching anything. It's wired correctly now.

### v2.4.0 -- "Modern Clean" redesign
- Full visual re-theme: white surfaces, single blue accent, Inter font, rounded cards -- replaces the previous teal/serif look everywhere at once (one consistent design, not per-tab).
- Dashboard rebuilt: greeting header, 4 real stat cards (Businesses Found, Queued, Emails Sent, Opened % -- the open rate is computed live from real tracking data already synced to each prospect, never a placeholder), a Quick Actions row (Paste Contract / Upload File / Auto-Fill / Find Prospects -- all four actually do the thing, not decorative), and a live Recent Activity feed built from real prospect status changes with relative timestamps.
- Opportunity tab is now a 2-step wizard: Step 1 (paste/upload + AI Analyze & Auto-Fill), Step 2 (review extracted fields + Save). Successfully analyzing auto-advances to Step 2. Returning to the tab with an opportunity already saved goes straight to Step 2 instead of the paste screen. A "Skip" link is available if you'd rather just fill fields by hand.
- No existing functionality was removed or altered -- every field, button, and ID from before still does exactly what it did; this was a structural/visual pass only.

### v2.4.1
- Moved the Recent Activity card to the bottom of the Dashboard, after the Google Maps search queue and Live Automatic Outreach cards, instead of above them.

### v2.4.2
- Emails no longer default to "would you be open to a quick call/conversation" as the closing CTA. The AI now defaults to low-friction content offers instead (opportunity breakdown, requirements summary, fit check, checklist, etc.), varying which one it uses, and only suggests a call as a rare exception rather than the default. The deliverability-rewrite pass also won't swap a content-offer CTA into a call request or vice versa.

### v2.4.3
- Fixed the unhelpful "Failed to fetch" error: this was the browser's own generic network-error message leaking straight through from three different places (the AI drafting request, the actual Gmail send request, and getting Gmail permission) with zero context. Each now identifies exactly which step failed and what to actually do about it -- e.g. Gmail auth expiring now clearly says to reconnect it in Settings, rather than a bare "Failed to fetch."
- Added a "Retry Failed" button in Prospects, next to Clear Unsent -- resets any failed prospect back to queued (clearing the old error) without needing a fresh Google Maps search, since most failures are brief network hiccups that succeed on a second attempt.

### v2.4.4
- Rewrote the email drafting instructions to fix three real problems: emails opened cold with a solicitation number/regulation instead of a self-introduction; they described the opportunity mechanically without giving the recipient a real reason to want it (recurring revenue, a reliable government customer, predictable payment terms, etc.); and the consultant's help was listed as a bare task checklist instead of being tied to an actual benefit ("so your submission isn't disqualified on a technicality" instead of just "I can review your documents"). Body length target increased slightly (110-160 words) to make room for a real intro and value case without feeling cramped. The deliverability-rewrite pass now also explicitly preserves all of this instead of potentially stripping it out to shorten the email.

### v2.5.0
- Found and fixed the real cause of both "not reaching enough companies" and "reloading unnecessarily": the page-reload safety net was firing after only ~18 seconds of no visible new listings, and since Google Maps is a single-page app, every reload wiped all scroll progress and forced a full re-scroll from the top of the same search -- on a large search (1000+ results) this meant most of every run was spent re-covering ground already covered instead of pushing deeper into the list. Thresholds are now far more patient (roughly 3-4 minutes of genuine stalling before ever reloading), since Maps' lazy-load genuinely gets slower the deeper you scroll into a large result set and that's normal, not stuck.
- New fallback for businesses with no website linked on their Maps listing: instead of skipping immediately, the extension now does a real Google search for the business name and picks the first result that isn't a directory/social site (Facebook, Yelp, LinkedIn, Yellow Pages, etc.) as their likely real website, then checks that for an email as usual. Covers both "never put a website on Maps" and "has a real site but hasn't linked it in their Maps profile yet" -- from the code's side these look identical, so one fix covers both. Prospects found this way are labeled "found via Google search" in the Prospects list.
- Analyze & Auto-Fill now also generates 3-5 suggested Google Maps search queries from the opportunity's scope and location (e.g. "Ergonomic consultants San Francisco CA"), and fills them straight into the Campaign tab's search queue slots alongside the opportunity/campaign fields it already extracted. Only uses locations genuinely present in the source text -- never invents one.
- Increased the settle time after opening each Maps search before the first read, so "strictly checking one by one" is checking a genuinely fully-loaded list rather than one still populating.
