const $=id=>document.getElementById(id);
// Fields restored from an unsaved draft (see below) stay protected from the
// 1s poll's normal overwrite until the user explicitly saves -- otherwise
// the very next poll tick would stomp the just-restored text right back out.
const restoredIds=new Set();
function setVal(id,v){const el=$(id);if(!el)return;if(document.activeElement===el)return;if(restoredIds.has(id))return;const nv=v==null?'':String(v);if(el.value!==nv)el.value=nv}
function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function relTime(ts){
  if(!ts)return '';
  const diff=Date.now()-Number(ts);
  if(diff<60000)return 'just now';
  const mins=Math.floor(diff/60000);
  if(mins<60)return mins+' min ago';
  const hrs=Math.floor(mins/60);
  if(hrs<24)return hrs+' hr'+(hrs===1?'':'s')+' ago';
  const days=Math.floor(hrs/24);
  if(days<7)return days+' day'+(days===1?'':'s')+' ago';
  return new Date(ts).toLocaleDateString([], {month:'short',day:'numeric'});
}
function send(msg){return new Promise(res=>chrome.runtime.sendMessage(msg,res))}
function flash(msg,type='success'){const el=$('status');if(!el||!msg)return;el.textContent=msg;el.style.display='block';el.style.background=type==='error'?'#fdecea':'#e7f8ef';el.style.color=type==='error'?'#b42318':'#087443';clearTimeout(flash._t);flash._t=setTimeout(()=>el.style.display='none',3500)}

let state=null,poll=null;
if($('sbaSidebarVersion'))$('sbaSidebarVersion').textContent='ASSISTANT · v'+chrome.runtime.getManifest().version;

// --- Popup-close survival: the popup's entire DOM/JS state is destroyed the
// instant it loses focus. To survive that, every keystroke and every tab
// switch is snapshotted into chrome.storage.session (cleared on browser
// close, unlike .local -- this is transient UI state, not real data). On
// reopen, a snapshot newer than 60s restores both the active tab and any
// unsaved field text; anything staler is discarded so you're never looking
// at a days-old ghost draft.
const DRAFT_KEY='uiDraft',DRAFT_TTL=60000;
let persistTimer=null;
async function persistUi(){
  const activeTab=document.querySelector('.navitem.active')?.dataset.tab||'dashboard';
  const values={};
  document.querySelectorAll('main input[id],main textarea[id],main select[id]').forEach(el=>{values[el.id]=el.value});
  await chrome.storage.session.set({[DRAFT_KEY]:{tab:activeTab,values,ts:Date.now()}});
}
function schedulePersist(){clearTimeout(persistTimer);persistTimer=setTimeout(persistUi,300)}
async function clearDraft(){restoredIds.clear();await chrome.storage.session.remove(DRAFT_KEY).catch(()=>{})}
async function restoreDraftIfFresh(){
  const r=await chrome.storage.session.get(DRAFT_KEY).catch(()=>({}));
  const draft=r[DRAFT_KEY];
  if(!draft)return;
  if(Date.now()-draft.ts>DRAFT_TTL){await chrome.storage.session.remove(DRAFT_KEY).catch(()=>{});return}
  const navEl=document.querySelector(`.navitem[data-tab="${draft.tab}"]`);
  if(navEl){
    document.querySelectorAll('.navitem').forEach(x=>x.classList.remove('active'));
    document.querySelectorAll('.tab').forEach(x=>x.classList.remove('active'));
    navEl.classList.add('active');
    $(draft.tab)?.classList.add('active');
  }
  Object.entries(draft.values||{}).forEach(([id,val])=>{
    const el=$(id);
    if(el&&document.activeElement!==el&&el.value!==val){el.value=val;restoredIds.add(id)}
  });
  if(restoredIds.size)flash('Restored what you were typing before the popup closed — remember to save.','success');
}

let oppStepInitialized=false;
function oppGoToStep(n){
  document.querySelectorAll('#opportunity .wizstep').forEach(el=>el.classList.toggle('active',Number(el.dataset.step)===n));
  document.querySelectorAll('#oppWizIndicator .wizdotwrap').forEach(el=>{
    const step=Number(el.dataset.step);
    el.classList.toggle('current',step===n);
    el.classList.toggle('done',step<n);
  });
}
$('oppSkipToStep2')?.addEventListener('click',()=>oppGoToStep(2));
$('oppBackToStep1')?.addEventListener('click',()=>oppGoToStep(1));

function goToTab(tabName){
  document.querySelectorAll('.navitem').forEach(x=>x.classList.remove('active'));
  document.querySelectorAll('.tab').forEach(x=>x.classList.remove('active'));
  document.querySelector(`.navitem[data-tab="${tabName}"]`)?.classList.add('active');
  $(tabName)?.classList.add('active');
  persistUi();
}
document.querySelectorAll('.navitem').forEach(el=>el.onclick=()=>goToTab(el.dataset.tab));

// Quick Actions on the Dashboard -- each one jumps to the real control it
// represents and performs the obvious next step, rather than being purely
// decorative.
$('qaPaste')?.addEventListener('click',()=>{
  goToTab('opportunity');
  oppGoToStep(1);
  $('contractSource')?.focus();
});
$('qaUpload')?.addEventListener('click',()=>{
  goToTab('opportunity');
  oppGoToStep(1);
  $('contractFile')?.click();
});
$('qaAutofill')?.addEventListener('click',()=>{
  goToTab('opportunity');
  oppGoToStep(1);
  if(($('contractSource')?.value||'').trim()){
    $('analyzeContract')?.click();
  } else {
    flash('Paste or upload the opportunity text first, then Auto-Fill can read it.','error');
    $('contractSource')?.focus();
  }
});
$('qaFind')?.addEventListener('click',()=>{
  goToTab('dashboard');
  $('startAuto')?.click();
});
document.addEventListener('input',e=>{if(['INPUT','TEXTAREA','SELECT'].includes(e.target.tagName))schedulePersist()});

async function refresh(){const r=await send({type:'STATE'});if(r?.ok){state=r;render()}}

function renderChecklist(s){
  const sender=s.campaign.region==='UK'?s.campaign.uk:s.campaign.us;
  const items=[
    {ok:!!(s.settings.geminiApiKey||'').trim(),label:'Add a free Gemini API key',hint:'Settings tab'},
    {ok:!!s.gmailConnected,label:'Connect Gmail',hint:'Settings tab'},
    {ok:!!(sender.senderName||'').trim()&&!!(sender.senderCompany||'').trim(),label:`Tell it who you are (${s.campaign.region} name + company)`,hint:'Campaign tab'},
    {ok:!!(s.campaign.contract&&(s.campaign.contract.title||s.campaign.contract.scope)),label:'Save the opportunity/contract you\'re pitching',hint:'Opportunity tab'},
  ];
  const allDone=items.every(i=>i.ok);
  const rows=items.map(i=>`<div class="checkitem">${i.ok?'✅':'⬜'} <span>${esc(i.label)}</span>${i.ok?'':`<span class="small tag">${esc(i.hint)}</span>`}</div>`).join('');
  const next=allDone?'<div class="checkitem checkdone">✅ All set. Open a Google Maps search, then click <b>Start Automatic Outreach</b> on this Dashboard.</div>':'';
  $('setupChecklist').innerHTML=rows+next;
  $('checklistCard').style.display=allDone?'none':'block';
}

function statusLabel(st){return {discovered:'finding email',queued:'queued',active:'sent',failed:'failed',skipped:'skipped'}[st]||st}

// Drives the dashboard's journey stepper (Finding companies -> Finding
// email -> Drafting -> Sending -> Done), lighting up the step matching the
// current phase and marking earlier ones as complete.
const JOURNEY_ORDER=['scrolling,ready','finding_email','preparing','sending','complete,paused,limit,error'];
function renderJourney(phase,running){
  const steps=[...document.querySelectorAll('#journeySteps .jstep')];
  let activeIdx=JOURNEY_ORDER.findIndex(group=>group.split(',').includes(phase));
  if(!running&&!['complete','paused','limit','error'].includes(phase))activeIdx=-1;
  steps.forEach((el,i)=>{
    el.classList.remove('done','active');
    if(activeIdx<0)return;
    if(i<activeIdx)el.classList.add('done');
    else if(i===activeIdx)el.classList.add('active');
  });
}

function render(){
  if(!state)return;
  const s=state,o=s.outreach||{};
  const queued=s.prospects.filter(p=>p.status==='queued').length;
  const skipped=s.prospects.filter(p=>p.status==='skipped').length;
  $('mFound').textContent=s.prospects.length;
  $('mQueued').textContent=queued;
  $('mSent').textContent=s.stats.sent;
  $('mSentToday').textContent=s.stats.sentToday||0;
  $('mSkipped').textContent=skipped;
  if($('mSentTodaySub'))$('mSentTodaySub').textContent=`${s.stats.sentToday||0} today`;

  // "Opened" is computed live from real tracking data already synced onto
  // each prospect (openCount) -- never a placeholder/fake percentage.
  const sentProspects=s.prospects.filter(p=>p.status==='active'||p.lastSentAt);
  const openedProspects=sentProspects.filter(p=>Number(p.openCount||0)>0);
  if($('mOpenRate')){
    if(sentProspects.length){
      $('mOpenRate').textContent=Math.round(openedProspects.length/sentProspects.length*100)+'%';
      $('mOpenSub').textContent=`${openedProspects.length} of ${sentProspects.length} sent`;
    } else {
      $('mOpenRate').textContent='—';
      $('mOpenSub').textContent='no emails sent yet';
    }
  }

  // Recent activity: a live feed built from the prospects list itself --
  // no separate log needed, this is just the most recent status changes.
  if($('recentActivityList')){
    const events=s.prospects
      .filter(p=>p.statusAt||p.lastSentAt)
      .map(p=>({p,at:Number(p.lastSentAt||p.statusAt||0)}))
      .sort((a,b)=>b.at-a.at)
      .slice(0,8);
    if(!events.length){
      $('recentActivityList').innerHTML='No activity yet.';
    } else {
      $('recentActivityList').innerHTML=events.map(({p,at})=>{
        const opened=Number(p.openCount||0)>0;
        const dotClass=p.status==='skipped'?'act-skipped':p.status==='failed'?'act-failed':opened?'act-opened':p.status==='active'?'act-sent':'act-queued';
        const verb=p.status==='skipped'?'Skipped':p.status==='failed'?'Failed':opened?'Opened your email':p.status==='active'?'Sent':'Queued';
        return `<div class="activity-item"><span class="activity-dot ${dotClass}"></span><div class="activity-body"><b>${esc(p.name||p.email||'Unknown')}</b><span>${esc(verb)} · ${esc(relTime(at))}</span></div></div>`;
      }).join('');
    }
  }
  $('gmailBadge').textContent=s.gmailConnected?'● Gmail connected':'Gmail not connected';
  $('gmailBadge').style.background=s.gmailConnected?'#e7f8ef':'#fff0ee';
  $('gmailBadge').style.color=s.gmailConnected?'#087443':'#b42318';
  renderChecklist(s);

  const c=s.campaign.contract;
  $('selectedContract').innerHTML=c&&(c.title||c.scope)?`<b>${esc(c.title||'Untitled opportunity')}</b><div class="small">${esc(c.agency||'')}${c.agency&&c.solicitationNumber?' · ':''}${esc(c.solicitationNumber||'')}</div>`:'No opportunity selected.';
  const queue=Array.isArray(s.campaign.mapsSearchTerms)?s.campaign.mapsSearchTerms.filter(x=>String(x||'').trim()):[];
  const qi=Number(o.mapsSearchIndex||0),qt=Number(o.mapsSearchTotal||queue.length||0);
  $('mapsQueueStatus').innerHTML=queue.length?`<b>${esc(String(queue.length))} search${queue.length===1?'':'es'} saved.</b> ${o.multiSearchActive?`Currently reading <b>${Math.min(qi+1,qt||queue.length)} of ${qt||queue.length}</b>${o.currentSearchTerm?` — “${esc(o.currentSearchTerm)}”`:''}. ${o.discoveryComplete?'All searches finished; email queue is now being processed.':'No emails are sent until all saved searches are read to the end.'}`:'Ready to run in order: '+queue.map((x,i)=>`${i+1}. ${esc(x)}`).join(' · ')}.`:'No multi-search queue configured. You can still open one Google Maps search manually and start Automatic Outreach.';

  $('regionLabel').textContent=`(${s.campaign.region})`;
  renderJourney(o.phase,o.running);
  $('progressSent').textContent=o.sent||0;
  $('progressFailed').textContent=o.failed||0;
  $('progressBatches').textContent=o.batches||0;
  $('progressRows').textContent=o.rowsCollected||0;
  $('progressAction').textContent=o.currentAction||'Idle';
  $('progressCompany').textContent=o.currentCompany||'—';
  $('progressEmail').textContent=o.currentEmail||'—';
  $('lastUpdate').textContent=o.updatedAt?`Last update: ${new Date(o.updatedAt).toLocaleString()}`:'—';
  const resumable=!!s.prospects?.some(p=>(p.status==='discovered'||p.status==='queued')&&!p.suppressed);
  $('startAuto').disabled=!!o.running;
  $('startAuto').textContent=o.running?'⚡ Running…':(resumable||o.phase==='error'?'⚡ Resume Automatic Outreach':'⚡ Start Automatic Outreach');

  // Opportunity tab
  setVal('contractTitle',c?.title||'');setVal('contractAgency',c?.agency||'');setVal('contractSolicitation',c?.solicitationNumber||'');setVal('contractUrl',c?.url||'');setVal('contractScope',c?.scope||'');
  let deadline='';if(c?.deadline){const d=new Date(c.deadline);if(!isNaN(d))deadline=new Date(d.getTime()-d.getTimezoneOffset()*60000).toISOString().slice(0,16)}
  setVal('contractDeadline',deadline);
  if(!oppStepInitialized){
    oppStepInitialized=true;
    oppGoToStep(c?.title?2:1);
  }

  // Campaign tab
  $('regionUS').classList.toggle('active',s.campaign.region!=='UK');
  $('regionUK').classList.toggle('active',s.campaign.region==='UK');
  setVal('usSenderName',s.campaign.us.senderName||'');setVal('usSenderTitle',s.campaign.us.senderTitle||'');setVal('usSenderCompany',s.campaign.us.senderCompany||'');setVal('usSenderEmail',s.campaign.us.senderEmail||'');setVal('usSenderPhone',s.campaign.us.senderPhone||'');setVal('usSenderWebsite',s.campaign.us.senderWebsite||'');
  setVal('ukSenderName',s.campaign.uk.senderName||'');setVal('ukSenderTitle',s.campaign.uk.senderTitle||'');setVal('ukSenderCompany',s.campaign.uk.senderCompany||'');setVal('ukSenderEmail',s.campaign.uk.senderEmail||'');setVal('ukSenderPhone',s.campaign.uk.senderPhone||'');setVal('ukSenderWebsite',s.campaign.uk.senderWebsite||'');
  setVal('campaignName',s.campaign.name||'');setVal('serviceContext',s.campaign.serviceContext||'');setVal('objective',s.campaign.objective||'');setVal('tone',s.campaign.tone||'Professional');setVal('dailyLimit',s.campaign.dailyLimit||25);
  const mapsTerms=Array.isArray(s.campaign.mapsSearchTerms)?s.campaign.mapsSearchTerms:[];
  for(let i=0;i<5;i++)setVal('mapsSearch'+(i+1),mapsTerms[i]||'');

  // Settings tab
  setVal('geminiApiKey',s.settings.geminiApiKey||'');setVal('geminiModel',s.settings.geminiModel||'gemini-3.5-flash-lite');setVal('minDelay',s.settings.minDelay??30);setVal('maxDelay',s.settings.maxDelay??60);setVal('maxReviews',s.settings.maxReviews??'');

  // Prospects list
  const prospectSearch=($('prospectSearch')?.value||'').trim().toLowerCase();
  const prospectStatus=$('prospectStatus')?.value||'all';
  const visibleProspects=s.prospects.filter(p=>{
    const hay=[p.name,p.email,p.phone,p.website].filter(Boolean).join(' ').toLowerCase();
    return (!prospectSearch||hay.includes(prospectSearch))&&(prospectStatus==='all'||p.status===prospectStatus);
  });
  const fmtTime=v=>v?new Date(v).toLocaleString([], {year:'numeric',month:'short',day:'numeric',hour:'numeric',minute:'2-digit'}):'';
  const statusText=p=>p.status==='active'?'Sent':p.status==='failed'?'Failed':p.status==='skipped'?'Skipped':p.status==='queued'?'Queued':'Finding email';
  $('prospectList').innerHTML=visibleProspects.length?visibleProspects.slice().reverse().map(p=>`<div class="prospect"><b>${esc(p.name)}</b><div class="small">${esc(p.email||p.website||'no website')}${p.phone?' · '+esc(p.phone):''}${p.reviewCount!=null?' · '+esc(p.reviewCount)+' review'+(p.reviewCount===1?'':'s'):''}${p.websiteFoundVia==='google_search'?' · found via Google search':''}</div>${p.status==='skipped'&&p.skipReason?`<div class="small">${esc(p.skipReason)}</div>`:''}${p.status==='failed'&&p.lastError?`<div class="small">${esc(p.lastError)}</div>`:''}<span class="tag">${esc(statusText(p))}</span>${p.statusAt?`<div class="small time">${esc(statusText(p))} · ${esc(fmtTime(p.statusAt))}</div>`:''}${p.deliverability?`<div class="deliverability">🛡️ Deliverability check: ${esc(String(p.deliverability.score))}/100</div>`:''}${p.openCount?`<div class="small time">👁 Opened ${esc(String(p.openCount))} time${p.openCount===1?'':'s'} · first ${esc(fmtTime(p.firstOpenedAt))}${p.lastOpenedAt&&p.lastOpenedAt!==p.firstOpenedAt?` · last ${esc(fmtTime(p.lastOpenedAt))}`:''}</div>`:''}</div>`).join(''):'<div class="small">No prospects match your search/filter.</div>';

  // Open notification settings
  const setCheck=(id,v)=>{const el=$(id);if(el&&document.activeElement!==el)el.checked=!!v};
  const on=s.openNotifications||{enabled:true,desktop:true,email:true};
  setCheck('openNotifyEnabled',on.enabled!==false);setCheck('openNotifyDesktop',on.desktop!==false);setCheck('openNotifyEmail',on.email!==false);

  // Commitment monitor settings/status
  const cm=s.commitmentMonitor||{enabled:true,lastScanAt:null,lastScanCount:0,lastNewCount:0,lastError:''};
  setCheck('commitmentScanEnabled',cm.enabled!==false);
  setCheck('autoCalendarMeetings',s.settings.autoCalendarMeetings!==false);
  setVal('commitmentLookbackDays',s.settings.commitmentLookbackDays??30);
  const cr=Array.isArray(s.settings.calendarReminders)&&s.settings.calendarReminders.length?s.settings.calendarReminders:[180,60,30,10];
  setVal('calReminder1',cr[0]??180);setVal('calReminder2',cr[1]??60);setVal('calReminder3',cr[2]??30);setVal('calReminder4',cr[3]??10);
  const cmList=(s.commitments||[]).filter(x=>x.status!=='dismissed').slice().sort((a,b)=>(new Date(a.startAt||a.dueAt||a.createdAt))-(new Date(b.startAt||b.dueAt||b.createdAt))).slice(0,40);
  const cFmt=v=>v?new Date(v).toLocaleString([], {month:'short',day:'numeric',year:'numeric',hour:'numeric',minute:'2-digit'}):'';
  const cType={meeting:'📅 Meeting',call:'📞 Call',followup:'↩ Follow-up',contract_watch:'🔎 Contract Watch',deadline:'⏳ Deadline',document_request:'📄 Document Request'};
  $('commitmentList').innerHTML=cmList.length?cmList.map(c=>`<div class="prospect"><b>${esc(cType[c.type]||c.type)} — ${esc(c.title)}</b><div class="small">${esc(c.contactName||c.company||c.contactEmail||'')}</div><div class="small">${esc(c.action||c.summary||'')}${c.startAt?` · ${esc(cFmt(c.startAt))}`:''}${c.dueAt&&!c.startAt?` · due ${esc(cFmt(c.dueAt))}`:''}</div><span class="tag">${esc(c.status||'pending')}${c.confidence?` · ${Math.round(c.confidence*100)}% confidence`:''}</span>${c.calendarEventId?'<div class="small time">📅 Added to Google Calendar</div>':(c.startAt?`<div class="actions" style="margin-top:8px"><button class="secondary" data-add-calendar="${esc(c.id)}">Add to Calendar</button><button class="danger" data-dismiss-commitment="${esc(c.id)}">Dismiss</button></div>`:`<div class="actions" style="margin-top:8px"><button class="danger" data-dismiss-commitment="${esc(c.id)}">Dismiss</button></div>`)}</div>`).join(''):'No commitments detected yet.';
  $('commitmentStatus').textContent=`${cm.enabled===false?'Monitoring is off.':'Monitoring is on — scans every 15 minutes while Chrome is running.'}${cm.lastScanAt?` Last scan: ${cFmt(cm.lastScanAt)}.`:''}${cm.lastNewCount?` ${cm.lastNewCount} new item${cm.lastNewCount===1?'':'s'} found.`:''}${cm.lastError?` Last error: ${cm.lastError}`:''}`;
  document.querySelectorAll('[data-add-calendar]').forEach(btn=>btn.onclick=async()=>{btn.disabled=true;const r=await send({type:'ADD_COMMITMENT_TO_CALENDAR',id:btn.dataset.addCalendar});flash(r?.error||'Added to Google Calendar.',r?.error?'error':'success');refresh()});
  document.querySelectorAll('[data-dismiss-commitment]').forEach(btn=>btn.onclick=async()=>{const r=await send({type:'DISMISS_COMMITMENT',id:btn.dataset.dismissCommitment});flash(r?.error||'Dismissed.',r?.error?'error':'success');refresh()});

  // Follow-up settings/status
  const f=s.followups||{enabled:false,onlyOpened:true,stopOnReply:true,intervals:[3,7,14]};
  setCheck('followupEnabled',f.enabled);setCheck('followupOnlyOpened',f.onlyOpened!==false);setCheck('followupStopOnReply',f.stopOnReply!==false);
  const ints=f.intervals||[3,7,14]; setVal('followupDay1',ints[0]||3);setVal('followupDay2',ints[1]||7);setVal('followupDay3',ints[2]||14);
  const frows=s.prospects.filter(p=>p.email&&(p.followupStatus||p.followupNextDueAt||p.followupCompleted||p.followupPaused)).slice().reverse().slice(0,30);
  $('followupList').innerHTML=frows.length?frows.map(p=>`<div class="prospect"><b>${esc(p.name||p.email)}</b><div class="small">${esc(p.email)}</div><div class="small">${esc(p.followupStatus||'Waiting')}${p.followupNextDueAt?` · next ${esc(new Date(p.followupNextDueAt).toLocaleString([], {month:'short',day:'numeric',year:'numeric',hour:'numeric',minute:'2-digit'}))}`:''}</div></div>`).join(''):'No follow-up activity yet.';

  // AI Writer dropdown
  const sel=$('aiProspect');
  const withEmail=s.prospects.filter(p=>p.email);
  const prevVal=sel.value;
  sel.innerHTML=withEmail.map(p=>`<option value="${esc(p.id)}">${esc(p.name)} — ${esc(p.email)}</option>`).join('')||'<option value="">No companies with an email yet</option>';
  if(withEmail.some(p=>p.id===prevVal))sel.value=prevVal;
}

async function checkConnections(){
  const gs=$('gmailStatus'),ga=$('gmailAccount'),ai=$('aiStatus'),model=$('aiModel'),cs=$('calendarStatus');
  const gr=await send({type:'CHECK_GMAIL'});
  if(gr?.ok){gs.textContent='● Connected';gs.className='statusok';ga.textContent=gr.email||'';}
  else{gs.textContent='● Not connected';gs.className='statusbad';ga.textContent=gr?.error||'';}
  const ar=await send({type:'CHECK_AI'});
  if(ar?.ok&&ar.configured){ai.textContent='● Connected';ai.className='statusok';model.textContent=`Model: ${ar.model||'gemini-3.5-flash-lite'}`;}
  else{ai.textContent='● Not configured';ai.className='statusbad';model.textContent=ar?.error||'Add your free Gemini API key in Settings.';}
  const cal=await send({type:'CHECK_CALENDAR'});
  if(cs){cs.textContent=cal?.ok?'● Connected':'● Not connected';cs.className=cal?.ok?'statusok':'statusbad';}
  await refresh();
}

async function showUpdateInfo(info){
  const box=$('updateNotice'),txt=$('updateNoticeText');
  if(!box)return;
  if(info?.ok&&info.newer){
    txt.textContent=`Version ${info.latestVersion} is available. You are using v${info.currentVersion}.`;
    box.style.display='block';
  }else box.style.display='none';
}
async function checkExtensionUpdate(){
  const info=await send({type:'CHECK_UPDATE'}).catch(()=>null);
  await showUpdateInfo(info);
}
$('updateNow')?.addEventListener('click',async()=>{
  const r=await send({type:'OPEN_UPDATE'});
  if(r?.error)flash(r.error,'error');
});
$('updateLater')?.addEventListener('click',()=>{if($('updateNotice'))$('updateNotice').style.display='none'});

$('connectGmail').onclick=async()=>{const r=await send({type:'CONNECT_GMAIL'});flash(r.message||r.error,r.error?'error':'success');await checkConnections()};
$('checkConnections').onclick=checkConnections;
$('startAuto').onclick=async()=>{const r=await send({type:'START_AUTOMATIC'});if(r?.error)flash(r.error,'error');refresh()};
$('pause').onclick=async()=>{const r=await send({type:'PAUSE'});flash(r.message||r.error,r.error?'error':'success');refresh()};

let contractUpload=null;
$('chooseContractFile')?.addEventListener('click',()=>$('contractFile')?.click());
$('contractFile')?.addEventListener('change',async e=>{
  const file=e.target.files?.[0];
  contractUpload=null;
  $('contractFileName').textContent=file?`${file.name} (${Math.round(file.size/1024)} KB)`:'No file selected';
  if(!file)return;
  if(file.size>15*1024*1024){flash('That file is larger than 15 MB. Please paste the contract text or use a smaller PDF.','error');e.target.value='';$('contractFileName').textContent='No file selected';return}
  const lower=file.name.toLowerCase();
  if(file.type==='application/pdf'||lower.endsWith('.pdf')){
    const dataUrl=await new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=()=>reject(new Error('Could not read the PDF.'));r.readAsDataURL(file)});
    contractUpload={name:file.name,mimeType:'application/pdf',base64:String(dataUrl).split(',')[1]||''};
  }else{
    const text=await file.text();
    contractUpload={name:file.name,mimeType:'text/plain',text};
  }
});
$('clearContractSource')?.addEventListener('click',()=>{
  $('contractSource').value='';$('contractFile').value='';$('contractFileName').textContent='No file selected';contractUpload=null;
  if($('contractAnalyzeStatus'))$('contractAnalyzeStatus').textContent='';
  schedulePersist();
});
$('analyzeContract')?.addEventListener('click',async()=>{
  const source=($('contractSource').value||'').trim();
  if(!source&&!contractUpload){flash('Paste the contract/tender details or upload an RFP/tender document first.','error');return}
  const btn=$('analyzeContract'),status=$('contractAnalyzeStatus');
  btn.disabled=true;btn.textContent='⏳ Reading contract…';if(status)status.textContent='Reading the opportunity and extracting the fields. This may take a moment…';
  try{
    let file=contractUpload;
    if(file?.mimeType==='text/plain'&&file.text&&file.text.length>120000)file={...file,text:file.text.slice(0,120000)};
    const r=await send({type:'ANALYZE_CONTRACT',source,file,region:state?.campaign?.region||'US'});
    if(!r?.ok)throw new Error(r?.error||'Could not analyze the opportunity.');
    const a=r.analysis||{},c=a.contract||{},camp=a.campaign||{};
    if(c.title) $('contractTitle').value=c.title;
    if(c.agency) $('contractAgency').value=c.agency;
    if(c.solicitationNumber) $('contractSolicitation').value=c.solicitationNumber;
    if(c.url) $('contractUrl').value=c.url;
    if(c.scope) $('contractScope').value=c.scope;
    if(c.deadline){const d=new Date(c.deadline);if(!isNaN(d))$('contractDeadline').value=new Date(d.getTime()-d.getTimezoneOffset()*60000).toISOString().slice(0,16)}
    if(camp.name) $('campaignName').value=camp.name;
    if(camp.serviceContext) $('serviceContext').value=camp.serviceContext;
    if(camp.objective) $('objective').value=camp.objective;
    const aiTerms=Array.isArray(camp.mapsSearchTerms)?camp.mapsSearchTerms.filter(x=>String(x||'').trim()).slice(0,5):[];
    if(aiTerms.length){
      for(let i=0;i<5;i++){const el=$('mapsSearch'+(i+1));if(el)el.value=aiTerms[i]||el.value||'';}
    }
    if(a.region==='US'||a.region==='UK'){
      const rc={...state.campaign,region:a.region};await send({type:'SAVE_CAMPAIGN',campaign:rc});
    }
    // Save the extracted opportunity + campaign in one operation so the AI context is immediately usable.
    let deadline=null;const dv=$('contractDeadline').value;if(dv){const d=new Date(dv);if(!isNaN(d))deadline=d.toISOString()}
    const cSaved={title:$('contractTitle').value.trim(),agency:$('contractAgency').value.trim(),solicitationNumber:$('contractSolicitation').value.trim(),url:$('contractUrl').value.trim(),scope:$('contractScope').value.trim(),deadline};
    const base={...state.campaign,contract:cSaved,name:$('campaignName').value.trim(),serviceContext:$('serviceContext').value.trim(),objective:$('objective').value.trim(),mapsSearchTerms:Array.from({length:5},(_,i)=>$('mapsSearch'+(i+1)).value.trim())};
    if(a.region==='US'||a.region==='UK')base.region=a.region;
    const saved=await send({type:'SAVE_CAMPAIGN',campaign:base});
    if(saved?.error)throw new Error(saved.error);
    await clearDraft();
    if(status)status.textContent=`✓ Extracted and saved ${c.title||'the opportunity'}${camp.name?' and created the campaign.':''}`;
    flash(aiTerms.length?`✓ Opportunity and campaign auto-filled and saved, including ${aiTerms.length} suggested Google Maps search${aiTerms.length===1?'':'es'}.`:'✓ Opportunity and campaign auto-filled and saved.','success');
    await refresh();
    oppGoToStep(2);
  }catch(err){if(status)status.textContent='';flash(err.message||'Could not analyze the opportunity.','error')}
  finally{btn.disabled=false;btn.textContent='✨ Analyze & Auto-Fill Opportunity + Campaign'}
});

$('saveContract').onclick=async()=>{
  let deadline=null;const dv=$('contractDeadline').value;if(dv){const d=new Date(dv);if(!isNaN(d))deadline=d.toISOString()}
  const contract={title:$('contractTitle').value.trim(),agency:$('contractAgency').value.trim(),solicitationNumber:$('contractSolicitation').value.trim(),url:$('contractUrl').value.trim(),scope:$('contractScope').value.trim(),deadline};
  const c={...state.campaign,contract};
  const r=await send({type:'SAVE_CAMPAIGN',campaign:c});
  flash(r.message||r.error,r.error?'error':'success');if(!r.error)await clearDraft();refresh();
};
$('clearContract').onclick=async()=>{const c={...state.campaign,contract:null};const r=await send({type:'SAVE_CAMPAIGN',campaign:c});flash(r.message||r.error,r.error?'error':'success');refresh()};

$('regionUS').onclick=async()=>{const c={...state.campaign,region:'US'};await send({type:'SAVE_CAMPAIGN',campaign:c});refresh()};
$('regionUK').onclick=async()=>{const c={...state.campaign,region:'UK'};await send({type:'SAVE_CAMPAIGN',campaign:c});refresh()};

async function saveCampaign(){
  const c={
    ...state.campaign,
    us:{senderName:$('usSenderName').value.trim(),senderTitle:$('usSenderTitle').value.trim(),senderCompany:$('usSenderCompany').value.trim(),senderEmail:$('usSenderEmail').value.trim(),senderPhone:$('usSenderPhone').value.trim(),senderWebsite:$('usSenderWebsite').value.trim()},
    uk:{senderName:$('ukSenderName').value.trim(),senderTitle:$('ukSenderTitle').value.trim(),senderCompany:$('ukSenderCompany').value.trim(),senderEmail:$('ukSenderEmail').value.trim(),senderPhone:$('ukSenderPhone').value.trim(),senderWebsite:$('ukSenderWebsite').value.trim()},
    name:$('campaignName').value.trim(),serviceContext:$('serviceContext').value.trim(),objective:$('objective').value.trim(),tone:$('tone').value,dailyLimit:Math.max(1,Number($('dailyLimit').value)||25),
    mapsSearchTerms:Array.from({length:5},(_,i)=>$('mapsSearch'+(i+1)).value.trim())
  };
  const r=await send({type:'SAVE_CAMPAIGN',campaign:c});
  flash(r.message||r.error,r.error?'error':'success');if(!r.error)await clearDraft();refresh();
}
$('saveCampaign').onclick=saveCampaign;

async function saveSettings(){
  const min=Math.max(0,Number($('minDelay').value)||30),max=Math.max(min,Number($('maxDelay').value)||60);
  const settings={...state.settings,geminiApiKey:$('geminiApiKey').value.trim(),geminiModel:$('geminiModel').value.trim()||'gemini-3.5-flash-lite',minDelay:min,maxDelay:max,maxReviews:$('maxReviews').value.trim()===''?null:Math.max(1,Number($('maxReviews').value)||25)};
  const r=await send({type:'SAVE_SETTINGS',settings});
  if(r?.error){flash(r.error,'error');return}
  flash('✓ Settings saved.','success');
  await clearDraft();
  await refresh();await checkConnections();
}
$('saveSettings').onclick=saveSettings;

$('clearUnsent').onclick=async()=>{if(!confirm('Remove all companies that haven\'t been emailed yet? Already-emailed companies are kept and will not be re-emailed.'))return;const r=await send({type:'CLEAR_UNSENT'});flash(r.error||r.message,r.error?'error':'success');refresh()};
$('retryFailed').onclick=async()=>{const r=await send({type:'RETRY_FAILED'});flash(r.error||r.message,r.error?'error':'success');refresh()};
$('prospectSearch')?.addEventListener('input',refresh); $('prospectStatus')?.addEventListener('change',refresh);
$('resetAll').onclick=async()=>{if(!confirm('Reset EVERYTHING? This also clears duplicate-email protection. This cannot be undone.'))return;const r=await send({type:'RESET_ALL'});flash(r.error||r.message,r.error?'error':'success');refresh()};

function currentManualProspect(){
  const selected=$('aiProspect').value;
  const email=$('manualRecipientEmail').value.trim();
  if(email)return {id:'manual-'+btoa(email.toLowerCase()).replace(/[^a-z0-9]/gi,''),email,name:$('manualRecipientCompany').value.trim()||$('manualRecipientName').value.trim()||email,contactName:$('manualRecipientName').value.trim(),website:$('manualRecipientWebsite').value.trim(),phone:''};
  if(selected)return state.prospects.find(x=>x.id===selected)||null;
  return null;
}
$('aiProspect').addEventListener('change',()=>{const p=state.prospects.find(x=>x.id===$('aiProspect').value);if(!p)return;$('manualRecipientEmail').value=p.email||'';$('manualRecipientName').value=p.contactName||'';$('manualRecipientCompany').value=p.name||'';$('manualRecipientWebsite').value=p.website||'';});
$('draftInitial').onclick=async()=>{
  const p=currentManualProspect();
  if(!p){flash('Enter a recipient email or choose a saved prospect.','error');return}
  const r=await send({type:'DRAFT_INITIAL',prospect:p});
  if(r?.error){flash(r.error,'error');return}
  $('draftSubject').value=r.subject||'';$('draftBody').value=r.body||'';
  showManualDeliverability(r.deliverability);
};
function showManualDeliverability(d){const el=$('manualDeliverability');if(!el)return;if(!d){el.style.display='none';return}el.style.display='block';el.textContent=`🛡️ Deliverability check: ${d.score}/100${d.reasons?.length?' · '+d.reasons.join('; '):' · No obvious risk patterns detected.'}`;el.style.background=d.score>=80?'#e7f8ef':'#fff0ee';el.style.padding='8px';el.style.borderRadius='6px';}
$('checkManualDeliverability').onclick=async()=>{const p=currentManualProspect();if(!p){flash('Enter a recipient email or choose a saved prospect.','error');return}const r=await send({type:'CHECK_DELIVERABILITY',prospect:p,subject:$('draftSubject').value,body:$('draftBody').value});if(r?.error){flash(r.error,'error');return}showManualDeliverability(r.review);};
$('clearManualDraft').onclick=()=>{$('manualRecipientEmail').value='';$('manualRecipientName').value='';$('manualRecipientCompany').value='';$('manualRecipientWebsite').value='';$('draftSubject').value='';$('draftBody').value='';showManualDeliverability(null)};
$('sendDraft').onclick=async()=>{
  const p=currentManualProspect();
  if(!p){flash('Enter a recipient email or choose a saved prospect.','error');return}
  const r=await send({type:'SEND_MANUAL',prospect:p,subject:$('draftSubject').value,body:$('draftBody').value});
  flash(r?.error||(r?.message+(r?.deliverability?` · Deliverability ${r.deliverability.score}/100`:'')),r?.error?'error':'success');refresh();
};
$('scanCommitments').onclick=async()=>{const r=await send({type:'SCAN_COMMITMENTS'});flash(r?.error||r?.message||`Scan complete — ${r?.newCount||0} new item(s).`,r?.error?'error':'success');refresh()};
$('connectCalendar').onclick=async()=>{const r=await send({type:'CONNECT_CALENDAR'});flash(r?.error||r?.message,r?.error?'error':'success');refresh()};
$('connectCalendarSettings').onclick=async()=>{const r=await send({type:'CONNECT_CALENDAR'});flash(r?.error||r?.message,r?.error?'error':'success');checkConnections()};
$('saveCommitmentSettings').onclick=async()=>{const reminders=[$('calReminder1').value,$('calReminder2').value,$('calReminder3').value,$('calReminder4').value].map(Number).filter(x=>x>=0);const r=await send({type:'SAVE_COMMITMENT_SETTINGS',settings:{enabled:$('commitmentScanEnabled').checked,autoCalendarMeetings:$('autoCalendarMeetings').checked,lookbackDays:Number($('commitmentLookbackDays').value)||30,calendarReminders:reminders}});flash(r?.error||r?.message,r?.error?'error':'success');refresh()};
$('saveFollowups').onclick=async()=>{const ints=[$('followupDay1').value,$('followupDay2').value,$('followupDay3').value].map(Number).filter(x=>x>0);if(!ints.length){flash('Enter at least one follow-up day.','error');return}const r=await send({type:'SAVE_FOLLOWUPS',followups:{enabled:$('followupEnabled').checked,onlyOpened:$('followupOnlyOpened').checked,stopOnReply:$('followupStopOnReply').checked,intervals:ints}});flash(r?.error||r?.message,r?.error?'error':'success');refresh();};
$('saveOpenNotifications').onclick=async()=>{const r=await send({type:'SAVE_OPEN_NOTIFICATIONS',openNotifications:{enabled:$('openNotifyEnabled').checked,desktop:$('openNotifyDesktop').checked,email:$('openNotifyEmail').checked}});flash(r?.error||r?.message,r?.error?'error':'success');refresh();};

// --- Account / plan / upgrade / admin ---
let account=null;
async function loadAccount(){
  if(typingActive)return; // don't let a background session refresh interrupt active typing
  const r=await send({type:'GET_ACCOUNT'});
  if(!r?.ok){
    account=null;
    if(r?.signedOutElsewhere){
      alert(r.error||'This account was signed in on another device.');
      location.reload();
      return;
    }
    const errText=r?.error||'Could not load your plan.';
    if($('planEmail'))$('planEmail').textContent=errText;
    if($('upgradePlanEmail'))$('upgradePlanEmail').textContent=errText;
    if($('settingsAccountEmail'))$('settingsAccountEmail').textContent=errText;
    return;
  }
  account=r.account;
  if($('dashGreeting')&&account?.email){
    const namePart=account.email.split('@')[0].split(/[._]/)[0];
    const first=namePart?namePart[0].toUpperCase()+namePart.slice(1):'';
    $('dashGreeting').textContent=first?`Welcome back, ${first} 👋`:'Welcome back 👋';
  }
  const capText=account.cap===-1?'Unlimited':`${account.used} / ${account.cap}`;
  const pct=account.cap===-1?100:Math.min(100,(account.used/Math.max(1,account.cap))*100);
  for(const [badgeId,emailId,usageId] of [['planBadge','planEmail','planUsageText'],['upgradePlanBadge','upgradePlanEmail','upgradePlanUsageText']]){
    const b=$(badgeId);
    if(b){b.textContent=account.plan;b.className='planbadge plan-'+account.plan}
    if($(emailId))$(emailId).textContent=account.email;
    if($(usageId))$(usageId).textContent=capText;
  }
  if($('planBarFill'))$('planBarFill').style.width=pct+'%';
  if($('planUpgradeRow'))$('planUpgradeRow').style.display=account.plan==='FREE'?'flex':'none';
  if($('settingsAccountEmail'))$('settingsAccountEmail').textContent=`Signed in as ${account.email} · ${account.plan} plan`;
  if($('adminNavItem'))$('adminNavItem').style.display=account.role==='admin'?'':'none';
}

$('planUpgradeBtn')?.addEventListener('click',()=>{
  document.querySelectorAll('.navitem').forEach(x=>x.classList.remove('active'));
  document.querySelectorAll('.tab').forEach(x=>x.classList.remove('active'));
  document.querySelector('.navitem[data-tab="upgrade"]').classList.add('active');
  $('upgrade').classList.add('active');
});

function showUpgradePay(plan,amount){
  $('upgradePayCard').style.display='block';
  $('upgradeAmount').textContent=amount;
  $('upgradeWhatsapp').href=`https://wa.me/2347031457157?text=${encodeURIComponent(`Hi, I've paid for the ${plan} plan on SBA Outreach Assistant. My account email is ${account?.email||''}.`)}`;
  $('upgradeIvePaid').onclick=async()=>{
    $('upgradeMsg').textContent='Submitting…';
    const r=await send({type:'SUBMIT_PAYMENT',plan,amount});
    $('upgradeMsg').textContent=r?.ok?'Recorded — we\'ll activate your plan once payment is confirmed on WhatsApp.':(r?.error||'Could not submit.');
  };
}
$('upgradeVipBtn').onclick=()=>showUpgradePay('VIP','₦5,000/month');
$('upgradeLifetimeBtn').onclick=()=>showUpgradePay('LIFETIME','₦20,000 one-time');

$('sbaLogoutBtn').onclick=async()=>{
  if(!confirm('Sign out of SBA Outreach Assistant?'))return;
  await send({type:'SBA_SIGN_OUT'});
  location.reload();
};

async function loadAdmin(){
  const list=$('adminList');
  list.textContent='Loading…';
  const r=await send({type:'ADMIN_LIST_USERS'});
  if(!r?.ok){list.textContent=r?.error||'Could not load users.';return}
  if(!r.users.length){list.textContent='No users yet.';return}
  const myId=account?.id;
  list.innerHTML=r.users.map(u=>{
    const isMe=u.id===myId;
    const actions=isMe
      ? `<span class="tag">Your account</span>`
      : `<div class="actions">
          <button class="secondary" data-uid="${u.id}" data-plan="VIP">Activate VIP</button>
          <button class="secondary" data-uid="${u.id}" data-plan="LIFETIME">Activate Lifetime</button>
          <button class="danger" data-uid="${u.id}" data-plan="FREE">Set Free</button>
        </div>`;
    return `
    <div class="adminrow">
      <div><b>${u.email}</b><div class="small">Plan: <b>${u.plan}</b> · Status: <b>${u.status}</b></div></div>
      ${actions}
    </div>`;
  }).join('');
  list.querySelectorAll('button[data-uid]').forEach(btn=>{
    btn.onclick=async()=>{
      btn.disabled=true;
      const r2=await send({type:'ADMIN_SET_PLAN',userId:btn.dataset.uid,plan:btn.dataset.plan});
      let msg=r2?.ok?'Updated.':(r2?.error||'Could not update.');
      if(r2?.ok && ['VIP','LIFETIME'].includes(btn.dataset.plan)){
        if(r2.activationEmail?.sent) msg+=' Activation email sent.';
        else if(r2.activationEmail?.error) msg+=' Plan activated, but the activation email could not be sent: '+r2.activationEmail.error;
        else if(r2.activationEmail?.skipped) msg+=' Activation email was already sent previously for this active plan.';
      }
      flash(msg,r2?.ok?'success':'error');
      loadAdmin();
    };
  });
}
$('adminRefresh').onclick=loadAdmin;
document.querySelector('.navitem[data-tab="admin"]').addEventListener('click',loadAdmin);

refresh().then(checkConnections).then(restoreDraftIfFresh).then(loadAccount).then(checkExtensionUpdate);

// The login screen (auth-gate.js) can hide itself the moment sign-in
// succeeds, but that doesn't tell the rest of this popup -- which may
// have already run its "am I signed in?" check once, before login --
// to check again. Listen for the session actually changing in storage
// and refresh immediately when it does, rather than only on next open.
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local' || !changes.sba_session) return;
  if (changes.sba_session.newValue && !typingActive) {
    loadAccount();
    refresh();
    checkConnections();
  }
});
let typingActive=false;
document.addEventListener('focusin',e=>{if(['INPUT','TEXTAREA','SELECT'].includes(e.target.tagName))typingActive=true});
document.addEventListener('focusout',e=>{if(['INPUT','TEXTAREA','SELECT'].includes(e.target.tagName))typingActive=false});
poll=setInterval(()=>{if(!typingActive)refresh()},1000);
