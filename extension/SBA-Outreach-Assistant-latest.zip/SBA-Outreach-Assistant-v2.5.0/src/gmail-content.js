(() => {
  const TICK_ATTR = 'data-sba-tracking-ticks';
  const SBA_TRACKING_HOST = 'uauvktlbxywlzdmxxzr.supabase.co';
  const SBA_TRACKING_PATH = '/functions/v1/email-tracking';
  const CACHE_TTL = 30000;
  const cache = new Map();
  let scanTimer = null;
  let scanInFlight = false;

  const clean = (v) => String(v || '').replace(/\s+/g, ' ').trim();
  const isEmail = (v) => /[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i.test(String(v || ''));
  const extractEmail = (v) => {
    const m = String(v || '').match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i);
    return m ? m[0].toLowerCase() : '';
  };

  function getMessageIds(row) {
    const out = [];
    const attrs = ['data-legacy-message-id','data-message-id','data-legacy-thread-id','data-thread-id'];
    for (const attr of attrs) {
      const nodes = [];
      if (row.hasAttribute(attr)) nodes.push(row);
      nodes.push(...row.querySelectorAll(`[${attr}]`));
      for (const node of nodes) {
        const value = node.getAttribute(attr);
        if (value && !out.includes(value)) out.push(value);
      }
    }
    return out;
  }

  function getSubjectCandidates(row) {
    const candidates = [];
    const selectors = ['.bog','.y6','td.xY .y6','td.xY .bog'];
    for (const selector of selectors) {
      for (const el of row.querySelectorAll(selector)) {
        const text = clean(el.textContent);
        if (!text || /^\d{1,2}:\d{2}\s*(AM|PM)?$/i.test(text)) continue;
        if (!candidates.includes(text)) candidates.push(text);
      }
    }
    if (!candidates.length) {
      const area = row.querySelector('td.xY');
      if (area) {
        for (const text of Array.from(area.querySelectorAll('span')).map(el => clean(el.textContent)).filter(Boolean)) {
          if (!/^\d{1,2}:\d{2}\s*(AM|PM)?$/i.test(text) && !candidates.includes(text)) candidates.push(text);
        }
      }
    }
    return candidates.slice(0, 5);
  }

  function getRecipient(row) {
    const candidates = Array.from(row.querySelectorAll('[email], [data-hovercard-id], [aria-label]'));
    for (const el of candidates) {
      for (const value of [el.getAttribute('email'), el.getAttribute('data-hovercard-id'), el.getAttribute('aria-label')].filter(Boolean)) {
        const match = extractEmail(value);
        if (match) return match;
      }
    }
    return '';
  }

  function looksLikeSentRow(row) {
    const text = clean(row.textContent || '');
    return /(^|\s)To:\s*/i.test(text) || !!row.querySelector('[data-tooltip*="To"], [aria-label^="To "]');
  }

  function getTarget(row) {
    return row.querySelector('td.xW') || row.querySelector('.yW') || row.querySelector('[email]')?.closest('td') || row.querySelector('td.xY') || row.querySelector('.bog') || row.querySelector('.y6');
  }

  function removeOldTick(target) {
    if (!target) return;
    target.querySelectorAll(`[${TICK_ATTR}]`).forEach(el => el.remove());
  }

  function renderTicks(target, tracking, mode = 'list') {
    if (!target) return;
    removeOldTick(target);
    if (!tracking) return;

    const opened = Number(tracking.open_count || 0) > 0;
    const wrap = document.createElement('span');
    wrap.setAttribute(TICK_ATTR, '1');
    wrap.setAttribute('aria-label', opened ? 'Opened by recipient' : 'Sent, not opened');
    wrap.setAttribute('title', opened ? `Opened ${tracking.open_count || 0} time${Number(tracking.open_count || 0) === 1 ? '' : 's'}` : 'Sent — not opened yet');
    Object.assign(wrap.style, {
      display: 'inline-flex', alignItems: 'center', gap: '0', marginLeft: mode === 'thread' ? '7px' : '8px',
      marginRight: mode === 'thread' ? '0' : '8px', fontSize: mode === 'thread' ? '15px' : '14px',
      fontWeight: '700', fontFamily: 'Arial, sans-serif', verticalAlign: 'middle', whiteSpace: 'nowrap',
      lineHeight: '1', position: 'relative', zIndex: '2'
    });

    const first = document.createElement('span');
    first.textContent = '✓'; first.style.color = '#188038';
    const second = document.createElement('span');
    second.textContent = '✓'; second.style.color = opened ? '#188038' : '#9aa0a6';
    wrap.append(first, second);
    target.appendChild(wrap);
  }

  function extensionContextValid() {
    try { return !!(chrome && chrome.runtime && chrome.runtime.id); } catch (_) { return false; }
  }

  function askBackground(messageIds, subjects, recipient) {
    const ids = Array.isArray(messageIds) ? messageIds : [];
    const subs = Array.isArray(subjects) ? subjects : [];
    const key = `${ids.join('|')}|${subs.join('|')}|${recipient}`;
    const cached = cache.get(key);
    if (cached && Date.now() - cached.at < CACHE_TTL) return Promise.resolve(cached.tracking);
    if (!extensionContextValid()) return Promise.resolve(null);

    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage({ type:'GET_GMAIL_TRACKING', messageIds:ids, subjects:subs, messageId:ids[0] || '', subject:subs[0] || '', recipient }, (response) => {
          if (chrome.runtime.lastError) { resolve(null); return; }
          const tracking = response?.ok ? (response.tracking || null) : null;
          cache.set(key, { at: Date.now(), tracking });
          resolve(tracking);
        });
      } catch (_) { resolve(null); }
    });
  }

  function getGmailAccount() {
    if (!extensionContextValid()) return Promise.resolve('');
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage({ type:'GET_GMAIL_ACCOUNT' }, (response) => {
          if (chrome.runtime.lastError) { resolve(''); return; }
          resolve(String(response?.email || '').trim().toLowerCase());
        });
      } catch (_) { resolve(''); }
    });
  }

  async function scanSentList() {
    const rows = Array.from(document.querySelectorAll('tr.zA'));
    if (!rows.length) return;
    const jobs = [];
    for (const row of rows) {
      if (!looksLikeSentRow(row)) continue;
      const target = getTarget(row);
      if (!target) continue;
      const messageIds = getMessageIds(row);
      const subjects = getSubjectCandidates(row);
      const recipient = getRecipient(row);
      if (!messageIds.length && !subjects.length) continue;
      jobs.push(askBackground(messageIds, subjects, recipient).then(t => renderTicks(target, t, 'list')).catch(() => {}));
    }
    await Promise.all(jobs);
  }

  function getThreadSubject() {
    return clean(document.querySelector('h2.hP, h2[data-thread-perm-id], .hP')?.textContent || '');
  }

  function getThreadContainers() {
    const found = new Set();
    document.querySelectorAll('[data-message-id]').forEach(el => {
      const c = el.closest('.gs, .h7, .adn, .if, [role="main"] > div') || el;
      if (c && c !== document.body) found.add(c);
    });
    document.querySelectorAll('.gs, .h7').forEach(el => found.add(el));
    return Array.from(found);
  }

  function getMessageSender(container) {
    for (const el of container.querySelectorAll('[email], [data-hovercard-id], [aria-label]')) {
      const email = extractEmail(el.getAttribute('email') || el.getAttribute('data-hovercard-id') || el.getAttribute('aria-label'));
      if (email) return email;
    }
    return '';
  }

  function getMessageRecipient(container, accountEmail) {
    const emails = [];
    for (const el of container.querySelectorAll('[email], [data-hovercard-id], [aria-label]')) {
      const email = extractEmail(el.getAttribute('email') || el.getAttribute('data-hovercard-id') || el.getAttribute('aria-label'));
      if (email && !emails.includes(email)) emails.push(email);
    }
    return emails.find(e => e !== accountEmail) || '';
  }

  function getThreadMessageIds(container) {
    return getMessageIds(container);
  }

  function getThreadTickTarget(container) {
    // Gmail's message timestamp/header is normally in .gH/.g3. Prefer that so
    // the ticks appear immediately after the timestamp, like Mailsuite.
    return container.querySelector('.gH .g3, .gH, .g3, .gE .gH') ||
      container.querySelector('[data-tooltip*="Click to change time"], [title*="time"]')?.parentElement || null;
  }

  function stripSelfTrackingPixels() {
    if (!extensionContextValid()) return;
    const endpoint='uauvktlbxywlzdmxxzrj.supabase.co/functions/v1/email-tracking';
    document.querySelectorAll(`img[src*="${endpoint}"]`).forEach(img=>{
      try {
        const container=img.closest('.gs, .h7, .adn, .if, [role="main"] > div');
        const sender=container?getMessageSender(container):'';
        if(sender && sender===String(window.__sbaGmailAccount||'').toLowerCase()){
          img.remove();
        }
      } catch (_) {}
    });
  }

  async function scanOpenThread(accountEmail) {
    const subject = getThreadSubject();
    if (!subject) return;
    const containers = getThreadContainers();
    const jobs = [];
    for (const container of containers) {
      const sender = getMessageSender(container);
      if (!sender || sender !== accountEmail) continue;
      const target = getThreadTickTarget(container);
      if (!target) continue;
      const ids = getThreadMessageIds(container);
      const recipient = getMessageRecipient(container, accountEmail);
      jobs.push(askBackground(ids, [subject], recipient).then(t => renderTicks(target, t, 'thread')).catch(() => {}));
    }
    await Promise.all(jobs);
  }

  async function scan() {
    if (scanInFlight || !location.hostname.includes('mail.google.com')) return;
    scanInFlight = true;
    try {
      const accountEmail = await getGmailAccount();
      if (!accountEmail) return;
      window.__sbaGmailAccount=accountEmail;
      stripSelfTrackingPixels();
      await scanSentList();
      await scanOpenThread(accountEmail);
    } finally { scanInFlight = false; }
  }

  function scheduleScan(delay = 350) {
    clearTimeout(scanTimer);
    scanTimer = setTimeout(scan, delay);
  }

  // Remove our own tracking pixels as early as possible. A declarativeNetRequest
  // rule also blocks direct browser image requests to the tracking endpoint,
  // preventing a sender viewing their own sent copy from registering an open.
  try { stripSelfTrackingPixels(); } catch (_) {}

  const observer = new MutationObserver(() => { stripSelfTrackingPixels(); scheduleScan(500); });
  observer.observe(document.documentElement, { childList:true, subtree:true });
  window.addEventListener('hashchange', () => scheduleScan(200));
  document.addEventListener('click', () => scheduleScan(500), true);
  window.addEventListener('popstate', () => scheduleScan(300));
  scheduleScan(800);
})();
