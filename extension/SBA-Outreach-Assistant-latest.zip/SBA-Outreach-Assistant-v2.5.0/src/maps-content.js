function clean(s){return (s||'').replace(/\s+/g,' ').trim()}

// Google Maps' results panel is a scrollable feed (role="feed") of place
// cards. Each card is wrapped in an <a> whose href points at /maps/place/
// and whose aria-label is the business name. This structure is more stable
// than Maps' obfuscated class names, but Google does change it periodically
// -- if extraction stops finding rows, this is the first place to look.
function getFeed(){return document.querySelector('div[role="feed"]')}

function mapsEndReachedByText(){
  const feed=getFeed();
  if(!feed) return false;
  const text=clean(feed.innerText||'').toLowerCase();
  return /you(?:'|’)?ve reached the end(?: of the list)?|you have reached the end(?: of the list)?|end of (?:the )?list|end of results|no more results/i.test(text);
}

// Backstop for mapsEndReachedByText(): that check depends on matching
// Google's exact end-of-list wording, which can change or vary by locale.
// If it never matches, discovery would either stop too early (never true)
// or retry forever without ever finishing. This tracks whether the feed's
// scrollable height AND the set of visible listings have both stopped
// changing across several consecutive checks -- if the page genuinely
// can't produce anything new, that's the real end regardless of wording.
let _stallHeight=null, _stallSignature=null, _stallStreak=0;
const STALL_STREAK_FOR_END=4;
function mapsEndReachedStructurally(listings){
  const feed=getFeed();
  if(!feed) return false;
  const height=feed.scrollHeight;
  const sig=listings.map(l=>l.mapsUrl||l.name||'').sort().join('|');
  const atBottom=(feed.scrollTop+feed.clientHeight)>=(feed.scrollHeight-16);
  if(atBottom && height===_stallHeight && sig===_stallSignature){
    _stallStreak++;
  } else {
    _stallStreak=0;
  }
  _stallHeight=height; _stallSignature=sig;
  return _stallStreak>=STALL_STREAK_FOR_END;
}
function mapsEndReached(listings){
  return mapsEndReachedByText() || mapsEndReachedStructurally(listings||extractListings());
}

function extractListings(){
  const feed=getFeed();
  if(!feed) return [];
  const anchors=[...feed.querySelectorAll('a[href*="/maps/place/"]')];
  const seen=new Set();
  const out=[];
  for(const a of anchors){
    const name=a.getAttribute('aria-label')||'';
    if(!name||seen.has(name))continue;
    seen.add(name);
    // The card is generally the anchor's closest ancestor that also
    // contains the rest of the listing's text (rating, category, phone).
    let card=a;
    for(let i=0;i<4&&card.parentElement;i++){
      card=card.parentElement;
      if(clean(card.innerText).length>name.length+10)break;
    }
    const text=clean(card.innerText||'');
    const websiteLink=[...card.querySelectorAll('a[href]')].find(x=>{
      const href=x.href||'';
      return href&&!href.includes('google.com')&&!href.startsWith('tel:')&&!href.startsWith('javascript:');
    });
    const phone=(text.match(/\(?\d{3}\)?[-.\s]\d{3}[-.\s]\d{4}/)||[])[0]||'';
    out.push({
      name,
      mapsUrl:a.href,
      website:websiteLink?websiteLink.href:'',
      phone,
      rawText:text.slice(0,400)
    });
  }
  return out;
}

// Scrolls the results feed to trigger Maps' infinite-scroll loading of
// more listings. Returns false if no feed is present at all (e.g. the tab
// isn't on a Maps search-results view).
function scrollFeedForMore(){
  const feed=getFeed();
  if(!feed) return false;
  const before=feed.scrollTop;
  const target=Math.max(0,feed.scrollHeight-feed.clientHeight-24);
  feed.scrollTo({top:target,behavior:'auto'});
  feed.dispatchEvent(new Event('scroll',{bubbles:true}));
  // A few Maps layouts use an inner scrolling element or react better to a
  // second nudge after reaching the bottom. Keep the nudge small so we don't
  // skip cards, while giving Maps a clear scroll event to trigger lazy-load.
  setTimeout(()=>{
    const current=getFeed();
    if(current){
      current.scrollTop=Math.max(0,current.scrollHeight-current.clientHeight-8);
      current.dispatchEvent(new Event('scroll',{bubbles:true}));
    }
  },250);
  return {ok:true,before,after:feed.scrollTop,height:feed.scrollHeight,clientHeight:feed.clientHeight};
}

// The list view's collapsed cards usually don't include an external website
// link at all -- that only shows up on a place's own detail page. This
// reads it from there (a[data-item-id="authority"] is Google's own stable
// attribute for the Website button in that panel).
function extractWebsiteFromDetail(){
  // Google changes Maps detail-page markup periodically. Try several signals
  // instead of relying on one attribute.
  const isExternal=(href)=>{
    if(!href||href.startsWith('tel:')||href.startsWith('mailto:')||href.startsWith('javascript:'))return false;
    try{const u=new URL(href,location.href);return /^https?:$/i.test(u.protocol)&&!/(^|\.)google\.(com|co\.uk|[a-z]{2,})$/i.test(u.hostname)&&!u.hostname.endsWith('.google.com')}catch{return false}
  };
  const preferred=[...document.querySelectorAll('a[data-item-id="authority"],a[aria-label],a[href]')];
  for(const a of preferred){
    const href=a.href||a.getAttribute('href')||'';
    const label=(a.getAttribute('aria-label')||a.innerText||'').trim();
    if(isExternal(href)&&(/website|web site|site|official/i.test(label)||a.hasAttribute('data-item-id')))return href;
  }
  const external=preferred.find(a=>isExternal(a.href||a.getAttribute('href')||''));
  return external?(external.href||external.getAttribute('href')):'';
}

chrome.runtime.onMessage.addListener((m,sender,sendResponse)=>{
  if(m.type==='EXTRACT_MAPS_LISTINGS'){
    const listings=extractListings();
    sendResponse({ok:true,listings,hasFeed:!!getFeed(),endReached:mapsEndReached(listings)});
  } else if(m.type==='SCROLL_MAPS_FEED'){
    sendResponse({ok:true,scrolled:scrollFeedForMore()});
  } else if(m.type==='EXTRACT_WEBSITE_DETAIL'){
    sendResponse({ok:true,website:extractWebsiteFromDetail()});
  }
  return true;
});
