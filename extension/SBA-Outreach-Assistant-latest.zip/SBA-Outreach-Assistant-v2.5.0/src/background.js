const DEFAULTS={
 campaign:{
   region:'US',
   us:{senderName:'',senderTitle:'',senderCompany:'',senderEmail:'',senderPhone:'',senderWebsite:''},
   uk:{senderName:'',senderTitle:'',senderCompany:'',senderEmail:'',senderPhone:'',senderWebsite:''},
   name:'Maps Outreach',serviceContext:'',objective:'Start a relevant business conversation around the selected opportunity.',tone:'Professional',dailyLimit:25,
   mapsSearchTerms:['','','','',''],
   contract:null
 },
 settings:{geminiApiKey:'',geminiModel:'gemini-3.5-flash-lite',minDelay:30,maxDelay:60,maxReviews:null,commitmentScanEnabled:true,commitmentLookbackDays:30,autoCalendarMeetings:true,calendarReminders:[180,60,30,10]},
 prospects:[],stats:{found:0,sent:0,sentToday:0,sentTodayDate:'',failed:0,skipped:0},gmailConnected:false,paused:false,followups:{enabled:false,intervals:[3,7,14],onlyOpened:true,stopOnReply:true},openNotifications:{enabled:true,desktop:true,email:true},
 outreach:{running:false,phase:'idle',sent:0,failed:0,processed:0,currentCompany:'',currentEmail:'',currentAction:'',startedAt:null,updatedAt:null,lastResult:'',batches:0,rowsCollected:0,error:'',mapsTabId:null,lastBatchSignature:'',mapsStallCount:0,recoveryAttempts:0,discoveryComplete:false,multiSearchActive:false,mapsSearchIndex:0,mapsSearchTotal:0,currentSearchTerm:'',completedSearches:0},commitments:[],commitmentMonitor:{enabled:true,lastScanAt:null,lastScanCount:0,lastNewCount:0,lastError:'',scannedMessageIds:[],updatedAt:null},calendarConnected:false,calendarEmail:''
};
const JOB_ALARM='maps-outreach-job';
const RECOVERY_ALARM='maps-outreach-recovery';
const UPDATE_CHECK_ALARM='sba-update-check';
const FOLLOWUP_ALARM='sba-followup-check';
const TRACKING_ALARM='sba-tracking-check';
const COMMITMENT_ALARM='sba-commitment-scan';
const UPDATE_URL='https://dgtandassociatesuk.tech/extension/version.json';
const RECOVERY_STALE_MS=4*60*1000;
const MAX_RECOVERY_ATTEMPTS=3;


function localDateKey(ts=Date.now()){const d=new Date(ts);return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`}
async function getState(){const s=await chrome.storage.local.get(DEFAULTS);const stats={...DEFAULTS.stats,...(s.stats||{})};const today=localDateKey();if(stats.sentTodayDate!==today){stats.sentToday=0;stats.sentTodayDate=today;await chrome.storage.local.set({stats})}return {...DEFAULTS,...s,stats,campaign:{...DEFAULTS.campaign,...(s.campaign||{}),us:{...DEFAULTS.campaign.us,...((s.campaign||{}).us||{})},uk:{...DEFAULTS.campaign.uk,...((s.campaign||{}).uk||{})}},settings:{...DEFAULTS.settings,...(s.settings||{})},followups:{...DEFAULTS.followups,...(s.followups||{}),intervals:Array.isArray(s.followups?.intervals)&&s.followups.intervals.length?s.followups.intervals:[3,7,14]},outreach:{...DEFAULTS.outreach,...(s.outreach||{})}}}
async function save(o){await chrome.storage.local.set(o)}
function idForMaps(l){let key=l.mapsUrl||l.name||'';try{if(l.mapsUrl){const u=new URL(l.mapsUrl);key=u.origin+u.pathname}}catch{}return btoa(unescape(encodeURIComponent(key.toLowerCase()))).replace(/[^a-z0-9]/gi,'').slice(0,48)}
function activeSender(campaign){return campaign.region==='UK'?campaign.uk:campaign.us}

// ---- Account / plan (Supabase) ----
// background.js is a separate execution context from the popup, so it has
// no access to auth.js's globals -- it reads the session chrome.storage
// left behind by login and talks to Supabase directly.
const SBA_SUPABASE_URL="https://uauvktlbxywlzdmxxzrj.supabase.co";
const SBA_SUPABASE_KEY="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVhdXZrdGxieHl3bHpkbXh4enJqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODk1NTk5NjksImV4cCI6MjEwNTEzNTk2OX0.Qb6Mip2OjAV3VHA-Xd9a-fhytIQm3Ws6FNBbfXvtUvk";
async function sbaSession(){return (await chrome.storage.local.get('sba_session')).sba_session||null}
async function sbaDeviceToken(){return (await chrome.storage.local.get('sba_device_token')).sba_device_token||null}
function sbaAuthHeaders(session){return {apikey:SBA_SUPABASE_KEY,Authorization:`Bearer ${session.access_token}`,'Content-Type':'application/json'}}
// Access tokens expire after about an hour. Rather than fail with a
// cryptic 401 once that happens mid-session (or mid automatic-outreach
// run), use the stored refresh_token to get a new one transparently.
async function sbaRefreshSession(session){
  if(!session?.refresh_token)return null;
  const r=await fetch(`${SBA_SUPABASE_URL}/auth/v1/token?grant_type=refresh_token`,{method:'POST',headers:{apikey:SBA_SUPABASE_KEY,'Content-Type':'application/json'},body:JSON.stringify({refresh_token:session.refresh_token})});
  const data=await r.json().catch(()=>({}));
  if(!r.ok)return null;
  await chrome.storage.local.set({sba_session:data});
  return data;
}
// Every authenticated call to Supabase goes through this: it attaches the
// current access token, and if that's expired (401), refreshes it once
// and retries automatically before giving up.
async function sbaFetch(url,opts={}){
  let session=await sbaSession();
  if(!session?.access_token)throw new Error('You are signed out. Reopen the extension and sign in.');
  let r=await fetch(url,{...opts,headers:{...sbaAuthHeaders(session),...(opts.headers||{})}});
  if(r.status===401){
    const refreshed=await sbaRefreshSession(session);
    if(refreshed){
      session=refreshed;
      r=await fetch(url,{...opts,headers:{...sbaAuthHeaders(session),...(opts.headers||{})}});
    }
  }
  return r;
}
// The ONLY function allowed to increase usage -- it's a Postgres RPC
// (increment_email_usage, see supabase-migration.sql) that checks the
// caller's plan and usage server-side and rejects the call if they're
// over their limit. A user cannot fake this result by editing the
// extension, because the check happens on Supabase, not here.
async function sbaCheckAndIncrementUsage(){
  const deviceToken=await sbaDeviceToken();
  const r=await sbaFetch(`${SBA_SUPABASE_URL}/rest/v1/rpc/increment_email_usage`,{method:'POST',body:JSON.stringify({p_device_token:deviceToken})});
  const data=await r.json().catch(()=>({}));
  if(!r.ok){
    const msg=data.message||data.error_description||data.hint||`Could not verify your plan/usage (HTTP ${r.status}).`;
    const limitHit=/LIMIT_REACHED/i.test(msg);
    const signedOutElsewhere=/SIGNED_OUT_ELSEWHERE/i.test(msg);
    if(signedOutElsewhere)await sbaSignOut();
    const err=new Error(msg.replace(/^(LIMIT_REACHED|SIGNED_OUT_ELSEWHERE):\s*/i,''));
    err.limitReached=limitHit;
    err.signedOutElsewhere=signedOutElsewhere;
    throw err;
  }
  return data;
}
async function sbaGetAccount(){
  const session=await sbaSession();
  if(!session?.user?.id)throw new Error('Not signed in.');
  const deviceToken=await sbaDeviceToken();
  if(deviceToken){
    const checkRes=await sbaFetch(`${SBA_SUPABASE_URL}/rest/v1/rpc/check_device`,{method:'POST',body:JSON.stringify({p_device_token:deviceToken})});
    if(!checkRes.ok){
      const d=await checkRes.json().catch(()=>({}));
      const msg=d.message||'';
      if(/SIGNED_OUT_ELSEWHERE/i.test(msg)){
        await sbaSignOut();
        const err=new Error(msg.replace(/^SIGNED_OUT_ELSEWHERE:\s*/i,''));
        err.signedOutElsewhere=true;
        throw err;
      }
    }
  }
  const uid=session.user.id;
  const month=new Date().toISOString().slice(0,7);
  const [profileRes,usageRes]=await Promise.all([
    sbaFetch(`${SBA_SUPABASE_URL}/rest/v1/profiles?id=eq.${uid}&select=full_name,email,plan,status,role`),
    sbaFetch(`${SBA_SUPABASE_URL}/rest/v1/email_usage?user_id=eq.${uid}&month=eq.${month}&select=emails_sent`)
  ]);
  if(!profileRes.ok){const d=await profileRes.json().catch(()=>({}));throw new Error(d.message||`Could not load your profile (HTTP ${profileRes.status}). Did you run supabase-migration.sql?`)}
  const profiles=await profileRes.json().catch(()=>[]);
  const usage=usageRes.ok?await usageRes.json().catch(()=>[]):[];
  const profile=profiles?.[0];
  if(!profile)throw new Error('No profile row found for your account yet.');
  const cap={FREE:10,VIP:500,LIFETIME:-1}[profile.plan]??10;
  return {id:uid,email:profile.email||session.user.email,plan:profile.plan||'FREE',status:profile.status||'active',role:profile.role||'user',used:usage?.[0]?.emails_sent||0,cap};
}
async function sbaSubmitPayment({plan,amount}){
  const session=await sbaSession();
  if(!session?.user?.id)throw new Error('Not signed in.');
  const r=await sbaFetch(`${SBA_SUPABASE_URL}/rest/v1/payments`,{method:'POST',headers:{Prefer:'return=minimal'},body:JSON.stringify({user_id:session.user.id,plan_requested:plan,amount:amount||null,status:'pending'})});
  if(!r.ok){const data=await r.json().catch(()=>({}));throw new Error(data.message||`Could not submit payment claim (HTTP ${r.status}).`)}
  return {ok:true};
}
async function sbaAdminListUsers(){
  const r=await sbaFetch(`${SBA_SUPABASE_URL}/rest/v1/profiles?select=id,email,full_name,plan,status,role&order=email.asc`);
  const profiles=await r.json().catch(()=>[]);
  if(!r.ok)throw new Error(profiles?.message||`Could not load users (HTTP ${r.status}) -- are you an admin?`);
  return profiles;
}
async function sbaAdminSetPlan({userId,plan,status}){
  // Read the current plan first so an accidental refresh/re-click does not
  // send duplicate activation emails when the account is already active.
  const beforeRes=await sbaFetch(`${SBA_SUPABASE_URL}/rest/v1/profiles?id=eq.${encodeURIComponent(userId)}&select=id,email,full_name,plan,status`);
  const beforeRows=await beforeRes.json().catch(()=>[]);
  if(!beforeRes.ok || !beforeRows?.[0]){
    throw new Error(beforeRows?.message||`Could not load that user (HTTP ${beforeRes.status}).`);
  }
  const before=beforeRows[0];
  const nextStatus=status||'active';
  const r=await sbaFetch(`${SBA_SUPABASE_URL}/rest/v1/profiles?id=eq.${encodeURIComponent(userId)}`,{method:'PATCH',headers:{Prefer:'return=minimal'},body:JSON.stringify({plan,status:nextStatus})});
  if(!r.ok){const data=await r.json().catch(()=>({}));throw new Error(data.message||`Could not update that user (HTTP ${r.status}) -- are you an admin?`)}

  let activationEmail={sent:false,skipped:false};
  const shouldNotify=['VIP','LIFETIME'].includes(String(plan||'').toUpperCase()) && !(String(before.plan||'').toUpperCase()===String(plan||'').toUpperCase() && String(before.status||'').toLowerCase()==='active');
  if(shouldNotify && before.email){
    try{
      const planName=String(plan).toUpperCase()==='LIFETIME'?'Lifetime':'VIP';
      const name=(before.full_name||'there').trim()||'there';
      const subject=`Congratulations — your ${planName} access is now active`;
      const body=`Hi ${name},\n\nCongratulations! Your SBA Outreach Assistant ${planName} plan has now been activated.\n\nYou can sign in to your account and start using your ${planName} access immediately.\n\nThank you for choosing SBA Outreach Assistant. We appreciate your business.\n\nSincerely,\nSBA Outreach Assistant`;
      await gmailSend({to:before.email,subject,body});
      activationEmail={sent:true,skipped:false};
    }catch(e){
      console.warn('Plan activation email failed:',e);
      activationEmail={sent:false,skipped:false,error:e?.message||'Could not send the activation email.'};
    }
  }else if(['VIP','LIFETIME'].includes(String(plan||'').toUpperCase())){
    activationEmail={sent:false,skipped:true};
  }
  return {ok:true,activationEmail};
}
async function sbaSignOut(){await chrome.storage.local.remove(['sba_session','sba_device_token']);return {ok:true}}

// ---- Gmail ----
async function gmailToken(interactive=true){
  let result;
  try{
    result=await chrome.identity.getAuthToken({interactive});
  }catch(e){
    throw new Error(`Could not get permission to use Gmail (${e.message||'Chrome denied the request'}). Go to Settings and click Connect/Reconnect Gmail.`);
  }
  const token=typeof result==='string'?result:result?.token;
  if(!token)throw new Error('Chrome did not return a Gmail OAuth token. Go to Settings and click Connect/Reconnect Gmail.');
  return token;
}
function b64(s){return btoa(unescape(encodeURIComponent(String(s??'')))).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'')}
function mimeB64(s){return btoa(unescape(encodeURIComponent(String(s??''))))}
function mimeHeader(s){
  const value=String(s??'');
  if(/^[\x20-\x7E]*$/.test(value) && !/[\r\n]/.test(value)) return value;
  return `=?UTF-8?B?${mimeB64(value)}?=`;
}
function escHtml(s){return String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/\'/g,'&#39;')}
function mime(to,subject,body,trackingId=''){
  const boundary=`sba_${Date.now()}_${Math.random().toString(36).slice(2)}`;
  const html=escHtml(body).replace(/\r?\n/g,'<br>')+(trackingId?`<img src="${TRACKING_ENDPOINT}?id=${encodeURIComponent(trackingId)}" width="1" height="1" alt="" style="display:block;width:1px;height:1px;border:0;opacity:0;" />`:'');
  const plainEncoded=mimeB64(body);
  const htmlEncoded=mimeB64(`<html><body style="font-family:Arial,sans-serif;font-size:14px;line-height:1.5;">${html}</body></html>`);
  return `To: ${to}\r\nSubject: ${mimeHeader(subject)}\r\nMIME-Version: 1.0\r\nContent-Type: multipart/alternative; boundary="${boundary}"\r\n\r\n--${boundary}\r\nContent-Type: text/plain; charset="UTF-8"\r\nContent-Transfer-Encoding: base64\r\n\r\n${plainEncoded}\r\n\r\n--${boundary}\r\nContent-Type: text/html; charset="UTF-8"\r\nContent-Transfer-Encoding: base64\r\n\r\n${htmlEncoded}\r\n\r\n--${boundary}--`;
}
const TRACKING_ENDPOINT='https://uauvktlbxywlzdmxxzrj.supabase.co/functions/v1/email-tracking';
function newTrackingId(){return crypto.randomUUID()}
async function createTracking(prospect,subject){
  const session=await sbaSession(); if(!session?.user?.id)return null;
  const trackingId=newTrackingId();
  const r=await sbaFetch(`${SBA_SUPABASE_URL}/rest/v1/email_tracking`,{method:'POST',headers:{Prefer:'return=minimal'},body:JSON.stringify({tracking_id:trackingId,user_id:session.user.id,prospect_id:prospect.id,recipient_email:prospect.email,subject:subject||null})}).catch(()=>null);
  return r?.ok===true?trackingId:null;
}
async function markTrackingSent(trackingId,sentAt,messageId){if(!trackingId)return;await sbaFetch(`${SBA_SUPABASE_URL}/rest/v1/email_tracking?tracking_id=eq.${encodeURIComponent(trackingId)}`,{method:'PATCH',headers:{Prefer:'return=minimal'},body:JSON.stringify({sent_at:new Date(sentAt).toISOString(),gmail_message_id:messageId||null})}).catch(()=>{});}
async function gmailSend({to,subject,body,trackingId=''}){
  const token=await gmailToken();
  const raw=b64(mime(to,subject,body,trackingId));
  let r;
  try{
    r=await fetch('https://gmail.googleapis.com/gmail/v1/users/me/messages/send',{method:'POST',headers:{Authorization:`Bearer ${token}`,'Content-Type':'application/json'},body:JSON.stringify({raw})});
  }catch(networkErr){
    throw new Error(`Could not reach Gmail to actually send this email (network error while sending -- the AI draft itself was created fine, it just never went out). This is usually a brief internet hiccup and resolves itself on the next prospect. If it keeps happening, check your internet connection and that Gmail is still connected in Settings.`);
  }
  if(!r.ok){
    const errText=await r.text().catch(()=>'');
    if(r.status===401||r.status===403){
      throw new Error(`Gmail rejected this send (${r.status}) -- your Gmail connection likely expired. Go to Settings and click Connect/Reconnect Gmail, then it will pick back up automatically on the next prospect.`);
    }
    throw new Error(`Gmail API error ${r.status}: ${errText}`);
  }
  return r.json();
}
async function checkGmail(){try{const token=await gmailToken(false);const r=await fetch('https://gmail.googleapis.com/gmail/v1/users/me/profile',{headers:{Authorization:`Bearer ${token}`}});if(!r.ok)throw new Error(`Gmail check failed (${r.status}).`);const d=await r.json();await save({gmailConnected:true,gmailEmail:d.emailAddress||''});return {ok:true,email:d.emailAddress||''}}catch(e){await save({gmailConnected:false});return {ok:false,error:e.message}}}
async function connect(){
  await chrome.identity.clearAllCachedAuthTokens().catch(()=>{});
  let result=await chrome.identity.getAuthToken({interactive:true});
  let token=typeof result==='string'?result:result?.token;
  let granted=typeof result==='string'?[]:(result?.grantedScopes||[]);
  if(!token)throw new Error('Chrome did not return a Gmail OAuth token. Close the popup and try Connect / Reconnect Gmail again.');
  let r=await fetch('https://gmail.googleapis.com/gmail/v1/users/me/profile',{headers:{Authorization:`Bearer ${token}`}});
  if(!r.ok&&(r.status===401||r.status===403)){
    await chrome.identity.removeCachedAuthToken({token}).catch(()=>{});
    await chrome.identity.clearAllCachedAuthTokens().catch(()=>{});
    result=await chrome.identity.getAuthToken({interactive:true});
    token=typeof result==='string'?result:result?.token;
    granted=typeof result==='string'?[]:(result?.grantedScopes||[]);
    if(token)r=await fetch('https://gmail.googleapis.com/gmail/v1/users/me/profile',{headers:{Authorization:`Bearer ${token}`}});
  }
  if(!r.ok){let detail='';try{detail=await r.text()}catch{};await save({gmailConnected:false});throw new Error(`Gmail authorization failed (${r.status}). ${detail||'Google rejected the current authorization.'}`)}
  let profile={};try{profile=await r.json()}catch{}
  await save({gmailConnected:true,grantedScopes:granted,gmailEmail:profile.emailAddress||''});
  return {ok:true,message:'Gmail connected successfully.'}
}

// ---- Calendar + Email Commitment Monitor ----
async function calendarToken(interactive=false){
  const result=await chrome.identity.getAuthToken({interactive});
  const token=typeof result==='string'?result:result?.token;
  if(!token)throw new Error('Chrome did not return a Google Calendar OAuth token. Reconnect Google services in Settings.');
  return token;
}
async function checkCalendar(){
  try{
    const token=await calendarToken(false);
    const r=await fetch('https://www.googleapis.com/calendar/v3/calendars/primary/events?maxResults=1&singleEvents=true&orderBy=startTime',{headers:{Authorization:`Bearer ${token}`}});
    if(!r.ok)throw new Error(`Calendar check failed (${r.status}).`);
    const st=await getState(); await save({calendarConnected:true,calendarEmail:st.gmailEmail||''});
    return {ok:true,email:st.gmailEmail||''};
  }catch(e){await save({calendarConnected:false});return {ok:false,error:e.message}}
}
async function connectCalendar(){
  await chrome.identity.clearAllCachedAuthTokens().catch(()=>{});
  const result=await chrome.identity.getAuthToken({interactive:true});
  const token=typeof result==='string'?result:result?.token;
  if(!token)throw new Error('Google did not return a Calendar token.');
  const r=await fetch('https://www.googleapis.com/calendar/v3/calendars/primary/events?maxResults=1&singleEvents=true&orderBy=startTime',{headers:{Authorization:`Bearer ${token}`}});
  if(!r.ok)throw new Error(`Calendar authorization failed (${r.status}). ${await r.text()}`);
  await save({calendarConnected:true,calendarEmail:(await getState()).gmailEmail||''});
  return {ok:true,message:'Google Calendar connected successfully.'};
}
function decodeB64Url(data){
  if(!data)return '';
  try{const b=atob(String(data).replace(/-/g,'+').replace(/_/g,'/').padEnd(Math.ceil(String(data).length/4)*4,'='));const bytes=Uint8Array.from(b,c=>c.charCodeAt(0));return new TextDecoder('utf-8').decode(bytes)}catch{return ''}
}
function stripHtml(html){return String(html||'').replace(/<style[\s\S]*?<\/style>/gi,' ').replace(/<script[\s\S]*?<\/script>/gi,' ').replace(/<br\s*\/?>/gi,'\n').replace(/<\/p>|<\/div>|<\/li>/gi,'\n').replace(/<[^>]+>/g,' ').replace(/&nbsp;/gi,' ').replace(/&amp;/gi,'&').replace(/&lt;/gi,'<').replace(/&gt;/gi,'>').replace(/&#39;|&#x27;/gi,"'").replace(/&quot;/gi,'"').replace(/\s+\n/g,'\n').replace(/\n\s+/g,'\n').replace(/[ \t]{2,}/g,' ').trim()}
function findPartText(payload){
  if(!payload)return {plain:'',html:''};
  const mimeType=String(payload.mimeType||'').toLowerCase();
  if(payload.body?.data){const text=decodeB64Url(payload.body.data);if(mimeType==='text/plain')return {plain:text,html:''};if(mimeType==='text/html')return {plain:'',html:text}}
  let out={plain:'',html:''}; for(const part of (payload.parts||[])){const r=findPartText(part);if(!out.plain&&r.plain)out.plain=r.plain;if(!out.html&&r.html)out.html=r.html;if(out.plain&&out.html)break} return out;
}
function headerValue(headers,name){return (headers||[]).find(h=>String(h.name||'').toLowerCase()===name.toLowerCase())?.value||''}
function parseEmailHeader(value){const raw=String(value||'').trim();const m=raw.match(/^\s*(.*?)\s*<([^>]+)>\s*$/);if(m)return {name:m[1].replace(/^\"|\"$/g,'').trim(),email:m[2].trim().toLowerCase()};const em=raw.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i);return {name:'',email:em?em[0].toLowerCase():raw.toLowerCase()};}
async function gmailListRecentMessages(days=30,maxResults=500){
  const token=await gmailToken(false); const q=`newer_than:${Math.max(1,Math.min(365,Number(days)||30))}d -in:spam -in:trash`;
  const out=[]; let pageToken=''; const limit=Math.min(500,Math.max(1,Number(maxResults)||500));
  while(out.length<limit){
    const params=new URLSearchParams({q,maxResults:String(Math.min(100,limit-out.length))}); if(pageToken)params.set('pageToken',pageToken);
    const r=await fetch(`https://gmail.googleapis.com/gmail/v1/users/me/messages?${params.toString()}`,{headers:{Authorization:`Bearer ${token}`}});
    if(!r.ok)throw new Error(`Gmail scan failed (${r.status}).`);
    const data=await r.json(); out.push(...(data.messages||[])); pageToken=data.nextPageToken||''; if(!pageToken)break;
  }
  return out.slice(0,limit);
}
function explicitScheduleCandidate(msg){
  const text=String(`${msg.subject||''}\n${msg.body||''}`);
  if(!/(\bcall\b|\bphone\b|\bmeeting\b|\bmeet\b|\bspeak\b|\bzoom\b|\bteams\b)/i.test(text))return null;
  const tm=text.match(/\b(?:at\s*)?(1[0-2]|0?[1-9])(?::([0-5]\d))?\s*(a\.?m\.?|p\.?m\.?)\b/i); if(!tm)return null;
  const days=['sunday','monday','tuesday','wednesday','thursday','friday','saturday']; const dm=text.match(/\b(this|next)?\s*(sunday|monday|tuesday|wednesday|thursday|friday|saturday)\b/i); if(!dm)return null;
  const now=new Date(), target=days.indexOf(dm[2].toLowerCase()), d=new Date(now); let delta=(target-d.getDay()+7)%7; if(delta===0)delta=7; if(/^next\s/i.test(dm[0]))delta+=7;
  d.setDate(d.getDate()+delta); let hour=Number(tm[1])%12; if(/p/i.test(tm[3]))hour+=12; d.setHours(hour,Number(tm[2]||0),0,0);
  return {type:/\b(call|phone|speak)\b/i.test(text)?'call':'meeting',title:String(msg.subject||'Scheduled call/meeting').slice(0,180),action:text.replace(/\s+/g,' ').trim().slice(0,500),summary:text.replace(/\s+/g,' ').trim().slice(0,700),contactEmail:(String(msg.from||'').match(/<([^>]+)>/)||[])[1]||String(msg.from||'').trim(),startAt:d.toISOString(),endAt:new Date(d.getTime()+30*60000).toISOString(),dueAt:null,confidence:0.99};
}
async function gmailGetMessageForCommitment(id){
  const token=await gmailToken(false); const r=await fetch(`https://gmail.googleapis.com/gmail/v1/users/me/messages/${encodeURIComponent(id)}?format=full`,{headers:{Authorization:`Bearer ${token}`}}); if(!r.ok)return null;
  const m=await r.json(), h=m.payload?.headers||[], parts=findPartText(m.payload); const body=(parts.plain||stripHtml(parts.html)||m.snippet||'').slice(0,12000);
  const from=headerValue(h,'From'), to=headerValue(h,'To'), st=await getState(), myEmail=String(st.gmailEmail||'').trim().toLowerCase();
  const fromParsed=parseEmailHeader(from), toParsed=parseEmailHeader(to), contact=(fromParsed.email&&fromParsed.email!==myEmail)?fromParsed:toParsed;
  return {id:m.id,threadId:m.threadId,internalDate:m.internalDate,from,to,cc:headerValue(h,'Cc'),subject:headerValue(h,'Subject'),body,snippet:m.snippet||'',contactHeader:contact.email?((contact.name?contact.name+' ':'')+'<'+contact.email+'>'):from,contactName:contact.name,contactEmail:contact.email,connectedEmail:myEmail};
}
function normalizeCommitment(c,msg){
  const type=String(c?.type||'').toLowerCase(), allowed=['meeting','call','followup','contract_watch','deadline','document_request']; if(!allowed.includes(type))return null;
  const id='commit-'+btoa(unescape(encodeURIComponent(`${msg.id}|${type}|${c.title||c.action||''}`))).replace(/[^a-z0-9]/gi,'').slice(0,70);
  const fallback=parseEmailHeader(msg.contactHeader||msg.from);
  return {id,type,title:String(c.title||c.action||type).slice(0,180),action:String(c.action||c.summary||c.title||'').slice(0,500),summary:String(c.summary||c.action||'').slice(0,700),contactName:String(c.contactName||msg.contactName||fallback.name||'').slice(0,120),contactEmail:String(c.contactEmail||msg.contactEmail||fallback.email||'').trim().toLowerCase(),company:String(c.company||'').slice(0,160),startAt:c.startAt||null,endAt:c.endAt||null,dueAt:c.dueAt||null,timezone:c.timezone||Intl.DateTimeFormat().resolvedOptions().timeZone,confidence:Math.max(0,Math.min(1,Number(c.confidence)||0)),sourceMessageId:msg.id,sourceThreadId:msg.threadId,sourceSubject:msg.subject,sourceFrom:msg.from,sourceTo:msg.to,sourceSnippet:msg.body.slice(0,900),status:'pending',calendarEventId:null,createdAt:Date.now(),updatedAt:Date.now()};
}
async function analyzeCommitmentMessage(msg){
  const now=new Date(), tz=Intl.DateTimeFormat().resolvedOptions().timeZone||'UTC';
  const prompt=`Read this Gmail message and identify concrete future commitments or scheduling statements involving the user. Current date/time: ${now.toISOString()}. User timezone: ${tz}. Return JSON exactly {"items":[...]}. Allowed type values: meeting, call, followup, contract_watch, deadline, document_request. Only include an item if the email contains a real future action/commitment, not a generic possibility. Examples: “let's schedule a call Monday at 10” => call with startAt; “I'll get back to you next week” => followup; “I'll keep an eye out for contracts in Denver and let you know” => contract_watch. Do not treat ordinary past events as future commitments. For meetings/calls, infer the next occurrence of an explicitly stated day/date and time, but if date/time is missing leave startAt null. If duration is not stated, use a 30-minute endAt. For relative phrases like “next week” you may set dueAt only when a reasonable date can be inferred; otherwise null. contactEmail should use the sender/recipient email when available. confidence must be 0 to 1. Keep action/summary factual and concise.
MESSAGE:
From: ${JSON.stringify(msg.from)}
To: ${JSON.stringify(msg.to)}
Subject: ${JSON.stringify(msg.subject)}
Body:
${msg.body}`;
  let items=[]; try { const r=await geminiJson(prompt); items=Array.isArray(r?.items)?r.items:[]; } catch(e){ console.warn('Gemini commitment parse failed',msg.id,e); }
  const explicit=explicitScheduleCandidate(msg); if(explicit){ const aiMatch=items.some(x=>String(x?.type||'').toLowerCase()===explicit.type && x?.startAt); if(!aiMatch)items.push(explicit); }
  return items.map(x=>normalizeCommitment(x,msg)).filter(Boolean);
}
async function createCalendarEventForCommitment(c){
  if(!c?.startAt)return null; const s=await getState(); if(c.calendarEventId)return c.calendarEventId; const token=await calendarToken(false);
  const start=new Date(c.startAt); if(isNaN(start))return null; let end=c.endAt?new Date(c.endAt):new Date(start.getTime()+30*60000); if(isNaN(end))end=new Date(start.getTime()+30*60000);
  const rem=(Array.isArray(s.settings.calendarReminders)&&s.settings.calendarReminders.length?s.settings.calendarReminders:[180,60,30,10]).map(Number).filter(n=>n>=0).slice(0,5);
  const contactLabel=[c.contactName,c.contactEmail].filter(Boolean).join(' — ')||'Contact not identified';
  const event={summary:`${c.type==='call'?'Call':'Meeting'} — ${contactLabel}`.slice(0,250),description:`Detected by SBA Outreach Assistant from Gmail.\n\nContact: ${c.contactName||'Unknown'}\nEmail: ${c.contactEmail||'Unknown'}\nCompany: ${c.company||'Not specified'}\n\n${c.summary||c.action||''}\n\nSource email: ${c.sourceSubject||''}`.slice(0,8000),start:{dateTime:start.toISOString()},end:{dateTime:end.toISOString()},reminders:{useDefault:false,overrides:rem.map(minutes=>({method:'popup',minutes}))},extendedProperties:{private:{sbaCommitmentId:c.id}}};
  const r=await fetch('https://www.googleapis.com/calendar/v3/calendars/primary/events?sendUpdates=none',{method:'POST',headers:{Authorization:`Bearer ${token}`,'Content-Type':'application/json'},body:JSON.stringify(event)}); if(!r.ok)throw new Error(`Calendar event creation failed (${r.status}).`); const data=await r.json(); return data.id||null;
}
async function processCommitmentScan({force=false}={}){
  const s=await getState(); if(!s.gmailConnected||!(s.settings.geminiApiKey||'').trim())return {ok:false,skipped:true,message:'Connect Gmail and configure Gemini first.'}; if(!force&&s.commitmentMonitor?.enabled===false)return {ok:false,skipped:true,message:'Commitment monitoring is disabled.'};
  const monitor={...s.commitmentMonitor,enabled:s.commitmentMonitor?.enabled!==false,lastError:'',updatedAt:Date.now()}, scanned=new Set(Array.isArray(monitor.scannedMessageIds)?monitor.scannedMessageIds:[]), msgs=await gmailListRecentMessages(s.settings.commitmentLookbackDays||30,100), newMsgs=msgs.filter(x=>x?.id&&!scanned.has(x.id));
  let newCount=0, analyzed=0, commitments=[...(s.commitments||[])];
  for(const item of newMsgs.slice(0,100)){const msg=await gmailGetMessageForCommitment(item.id);if(!msg)continue;analyzed++;try{const found=await analyzeCommitmentMessage(msg);for(const c of found){if(commitments.some(x=>x.id===c.id))continue;if((c.type==='meeting'||c.type==='call')&&s.settings.autoCalendarMeetings!==false&&c.startAt&&c.confidence>=0.85){try{c.calendarEventId=await createCalendarEventForCommitment(c);c.status=c.calendarEventId?'scheduled':'pending'}catch(e){c.status='needs_calendar';c.calendarError=e.message}}commitments.push(c);newCount++}}catch(e){console.warn('Commitment analysis failed',item.id,e)}scanned.add(item.id)}
  monitor.scannedMessageIds=[...scanned].slice(-500);monitor.lastScanAt=Date.now();monitor.lastScanCount=analyzed;monitor.lastNewCount=newCount;monitor.updatedAt=Date.now(); await save({commitments,commitmentMonitor:monitor}); return {ok:true,analyzed,newCount,commitments};
}
async function addCommitmentToCalendar(id){const s=await getState(),c=s.commitments.find(x=>x.id===id);if(!c)throw new Error('Commitment not found.');if(c.calendarEventId)return {ok:true,eventId:c.calendarEventId};const eventId=await createCalendarEventForCommitment(c);if(!eventId)throw new Error('This commitment does not have a specific date/time yet.');await save({commitments:s.commitments.map(x=>x.id===id?{...x,calendarEventId:eventId,status:'scheduled',updatedAt:Date.now()}:x)});return {ok:true,eventId};}
async function dismissCommitment(id){const s=await getState();await save({commitments:s.commitments.map(x=>x.id===id?{...x,status:'dismissed',updatedAt:Date.now()}:x)});return {ok:true};}

// ---- Gemini (direct, no local server -- see the SBA Outreach Assistant build for background) ----
const GEMINI_SYSTEM_PROMPT=`You are the conversion-focused outreach writer for a real government-contracting and public-sector tender consultant. Your job is to turn a relevant prospect + opportunity into a genuine business conversation, not a generic marketing email or mail-merge template. The recipient should understand quickly that the sender is a consultant who can help them identify suitable public-sector opportunities, understand the solicitation/tender, assess fit, prepare the bid/tender response and required supporting or technical documentation, and organize the submission. Never promise that a contract will be won and never imply a guaranteed result.

REGIONAL LANGUAGE: If region is US, use natural US terms such as government contract, solicitation, RFP/RFQ, bid, proposal, SAM.gov or capability statement only when actually supplied. If region is UK, use natural UK terms such as public-sector contract, tender, procurement, bid, tender response, method statement, PQQ/selection questionnaire or supporting documents only when actually supplied. Do not mix US and UK procurement terminology unnecessarily.

CONVERSION RULES: (1) Open with a brief, warm, human self-introduction woven into the first 1-2 sentences -- who the sender is and what they do in plain terms -- before diving into procurement details. Never open cold with a solicitation number or regulatory detail as the very first thing the recipient reads; a stranger's name and reason for writing comes first, THEN the specific opportunity. (2) If a specific opportunity is supplied, make it the reason for contacting the prospect and reference the most relevant concrete detail: buyer/client, service, location, scope, or deadline when supplied. Explain what the opportunity means for this business in plain English rather than repeating procurement language. (3) Give the recipient a genuine, specific reason to WANT this opportunity, not just a description of it -- e.g. what a contract like this is actually worth to a business (a reliable paying customer, recurring/repeat revenue if it's an IDIQ or framework, a foot in the door with a larger buyer, predictable government payment terms) using only what is true in general about this kind of opportunity, never invented specifics about this exact deal's odds or value. The recipient should finish that sentence thinking "that would be good for us," not just "okay, a contract exists." (4) Position the sender as a hands-on consultant in a way that makes the BENEFIT of working with them obvious, not a bare task list. For each thing mentioned, connect it to an outcome the recipient actually cares about -- e.g. not "I can review your technical documentation" but "so your submission is compliant and doesn't get disqualified on a technicality"; not "I can format the proposal" but "so you're not spending days on formatting instead of running your business." Mention only the 1-2 most relevant parts of the process for this opportunity, always tied to their payoff, never a checklist. (5) Make the email feel personally researched by connecting the opportunity to the recipient's supplied business/service/location information. Never invent facts. (6) Give the recipient a very easy next step. Default to a low-friction CONTENT offer the recipient can simply say yes to over email -- vary which one you use across different emails rather than repeating the same phrasing every time: sending a short opportunity breakdown, a requirements summary, a fit check, a bid-readiness checklist, a shortlist of relevant upcoming opportunities, or simply asking if it's worth sending more detail. Do NOT default to asking for a call, phone conversation, or "quick chat" -- treat that as an occasional exception (roughly one email in five at most), only when it genuinely fits, never as the go-to closing line. Most emails should close with a content offer, not a call request. (7) If no specific opportunity is supplied, do not pretend one exists; instead explain that the sender helps businesses find relevant contracts/tenders and offers to identify suitable opportunities, still grounded in a genuine reason government work is worth pursuing. (8) Keep the body concise, usually 110-160 words (a little longer than a bare announcement, since a real introduction plus a real value case both need room, but still tight and readable with short paragraphs). (9) Subject lines should be natural, specific and curiosity-driven without clickbait, urgency, guarantees or excessive sales language; usually 5-9 words. (10) Sound like an experienced consultant personally contacting a business owner, not an automated sales representative or a procurement notice. Avoid phrases such as “I hope this email finds you well,” “leverage your capabilities,” “unlock opportunities,” “take your business to the next level,” “synergy,” and similar generic AI/business language. (11) Do not claim the recipient has been selected, is eligible, has won, has a relationship with the buyer, or has any certification unless supplied. (12) Do not claim you reviewed a document, spoke to the buyer, or performed research that is not explicitly represented in the supplied input. (13) Avoid spammy language, ALL CAPS, excessive punctuation, false urgency, guarantees, manipulation, or fake personalization. (14) Do NOT write a closing signature block; the extension appends the signature automatically. Return valid JSON when requested.`;
async function geminiChat(userContent){
  const s=await getState();const key=(s.settings.geminiApiKey||'').trim();if(!key)throw new Error('Add your free Gemini API key in Settings before using AI features.');
  const model=s.settings.geminiModel||'gemini-3.5-flash-lite';
  let r;
  try{
    r=await fetch('https://generativelanguage.googleapis.com/v1beta/openai/chat/completions',{method:'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${key}`},body:JSON.stringify({model,messages:[{role:'system',content:GEMINI_SYSTEM_PROMPT},{role:'user',content:userContent}]})});
  }catch(networkErr){
    // The browser's fetch() throws this exact generic message for many
    // different real causes -- offline, DNS failure, a CORS/network block,
    // or Google's servers being briefly unreachable -- and refuses to say
    // which. Identify at least WHICH step failed, since that alone narrows
    // it down a lot, and suggest the most common real fix.
    throw new Error(`Could not reach Gemini to draft this email (network error while generating the draft). This is usually a brief internet hiccup and resolves itself -- it will be retried automatically for the next prospect. If this keeps happening for every prospect, check your internet connection and that your Gemini API key is still valid.`);
  }
  if(!r.ok)throw new Error(`Gemini API error ${r.status}: ${await r.text()}`);
  const data=await r.json();return data.choices?.[0]?.message?.content||''}
function stripJsonFence(t){return (t||'').replace(/^```json\s*/,'').replace(/^```\s*/,'').replace(/\s*```$/,'')}
async function geminiJson(userContent){const text=await geminiChat(userContent);return JSON.parse(stripJsonFence(text))}
const CONTRACT_ANALYSIS_PROMPT=`You extract structured information from a complete government/public-sector contract, RFP, RFQ, ITT, tender notice, buyer message, or procurement document for a bid/outreach consultant. Read the supplied source carefully and use ONLY information supported by it. Do not invent missing facts.

Your job is to produce BOTH (A) a clean opportunity record and (B) an outreach campaign setup.

IMPORTANT SCOPE RULE: The opportunity.scope field must be useful to a consultant who will use it as context for outreach. Do not reduce the scope to one sentence. Summarize the substantive work and preserve important procurement context when present, including core deliverables, service classifications/CPV codes, contract term, estimated value, evaluation criteria/weighting, submission method/portal, location, key requirements, and material dates. Use a readable labeled format such as:
Scope of work
[plain-English description]

Core Deliverables: ...
Classifications: ...
Contract Term & Value: ...
Evaluation Criteria: ...
Submission: ...
Key Requirements: ...
Only include sections for which the source provides information.

The campaign should be built around the actual opportunity, not generic marketing. campaign.name should be a concise outreach campaign name. campaign.serviceContext should describe the relevant service/offer the sender can provide to a prospect in relation to this opportunity (for this product, the sender is a bid/tender/government-contracting consultant). campaign.objective should be a conversion-focused internal objective explaining who is being contacted, why the opportunity may be relevant, what the consultant can help with, and the low-friction next step. Do not promise a win or invent prospect facts.

MAPS SEARCH TERMS: Also produce campaign.mapsSearchTerms -- an array of 3 to 5 Google Maps search queries for finding businesses that would realistically be able to deliver the scope of THIS opportunity (i.e. the prime/sub contractors or suppliers a consultant would pitch bid-writing help to, not the buyer/agency itself). Each query should combine a specific business type/trade drawn from the scope of work with a real place name drawn from the opportunity's stated location -- e.g. "Ergonomic consultants San Francisco CA", "Workplace safety consultants Oakland CA". Vary the business-type phrasing across the list rather than repeating the same words, and vary the place names across nearby/relevant locations when the source supports more than one (city, county, wider region) rather than repeating the exact same place every time. Only use place names that are genuinely supported by the source (the delivery location, buyer location, or a region explicitly named in scope) -- never invent a location. If the source does not name any usable location at all, return an empty array rather than guessing one.

If the source is clearly UK procurement, return UK. If clearly US government procurement, return US. Otherwise return the supplied region.

URL RULE: Return a URL only when the source explicitly contains one. Prefer the tender/notice URL and do not invent a URL. Reference number should be the official notice/procurement reference, not a random document number unless that is the only clear procurement identifier.

DEADLINE RULE: Return the bid/tender submission deadline if one is clearly stated. Prefer ISO 8601 such as 2026-10-08T17:00:00 when the date and time are known. If no deadline is stated, return an empty string.

Return valid JSON only, exactly in this shape:
{
  "region": "US|UK",
  "contract": {
    "title": "",
    "agency": "",
    "solicitationNumber": "",
    "url": "",
    "deadline": "",
    "scope": ""
  },
  "campaign": {
    "name": "",
    "serviceContext": "",
    "objective": "",
    "mapsSearchTerms": [""]
  }
}`;

async function analyzeContractSource(source,file,region){
  const s=await getState();
  const key=(s.settings.geminiApiKey||'').trim();
  if(!key)throw new Error('Add your free Gemini API key in Settings before analyzing a contract.');
  const suppliedText=String(source||'').trim();
  const fileText=String(file?.text||'').trim();
  const combined=[suppliedText,fileText].filter(Boolean).join('\n\n--- UPLOADED DOCUMENT TEXT ---\n\n');
  if(combined.length>120000)throw new Error('The pasted/uploaded text is too large. Please paste the most relevant tender/RFP text or use the PDF upload.');
  const sender=activeSender(s.campaign);
  const context=`Source region hint: ${region==='UK'?'UK':'US'}\nSender identity: ${JSON.stringify({name:sender.senderName,title:sender.senderTitle,company:sender.senderCompany,website:sender.senderWebsite})}\n\n${combined}`;
  if(file?.mimeType==='application/pdf'&&file?.base64){
    const model=(s.settings.geminiModel||'gemini-3.5-flash-lite').replace(/^models\//,'');
    const r=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(key)}`,{
      method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({
        systemInstruction:{parts:[{text:CONTRACT_ANALYSIS_PROMPT}]},
        contents:[{role:'user',parts:[{text:`${context}\n\nRead the attached PDF as the primary contract/tender source. If pasted text is also supplied, use it as additional source context.`},{inlineData:{mimeType:'application/pdf',data:file.base64}}]}],
        generationConfig:{responseMimeType:'application/json',temperature:0.15}
      })
    });
    if(!r.ok)throw new Error(`Gemini PDF analysis failed (${r.status}): ${await r.text()}`);
    const data=await r.json();
    const text=(data.candidates?.[0]?.content?.parts||[]).map(x=>x.text||'').join('');
    return JSON.parse(stripJsonFence(text));
  }
  if(!combined)throw new Error('Paste the contract/tender details or upload an RFP/tender document first.');
  return await geminiJson(`${CONTRACT_ANALYSIS_PROMPT}\n\nSOURCE DOCUMENT:\n${context}`);
}

function deliverabilityReview(subject,body){
  const text=`${subject||''}\n${body||''}`.trim();
  let score=100, reasons=[];
  const penalize=(n,reason)=>{score-=n;reasons.push(reason)};
  if((subject||'').length>78)penalize(8,'Subject is too long');
  if(/[!?]{2,}/.test(text))penalize(10,'Repeated punctuation');
  if(/\b[A-Z]{5,}\b/.test(text))penalize(8,'Excessive all-caps wording');
  if(/\b(free|guarantee|guaranteed|act now|limited time|urgent|winner|cash bonus|risk[- ]free|100%|make money fast|click here)\b/i.test(text))penalize(14,'Promotional or urgency-heavy wording');
  const links=(text.match(/https?:\/\/|www\./gi)||[]).length;
  if(links>2)penalize(12,'Too many links'); else if(links===2)penalize(5,'Multiple links');
  const words=text.split(/\s+/).filter(Boolean).length;
  if(words>190)penalize(8,'Message is longer than recommended');
  if(words<25)penalize(5,'Message is unusually short');
  if((text.match(/\$/g)||[]).length>2)penalize(5,'Multiple currency references');
  if(/<[^>]+>/.test(text))penalize(10,'HTML-like markup in message text');
  return {score:Math.max(0,Math.min(100,score)),reasons};
}
async function spamSafeDraft(r,prospect,campaign,contract,sender){
  let subject=(r.subject||'').trim(), body=(r.body||'').trim();
  let review=deliverabilityReview(subject,body);
  if(review.score<80){
    const rewrite=await geminiJson(`Rewrite this outreach email for ordinary Gmail deliverability WITHOUT making it less persuasive. Preserve the core conversion strategy: the self-introduction, specific opportunity relevance, the reason this opportunity is worth pursuing, consultant help framed as a benefit (not a task list), and an easy yes/no next step -- do not strip these out to shorten it. Keep the same TYPE of closing CTA as the original (do not change a content-offer CTA into a call/meeting request, or vice versa) unless the original CTA itself is a deliverability problem. Keep it truthful, human, concise and low-pressure. Remove promotional/urgency-heavy wording, repeated punctuation, excessive caps, unnecessary links, generic AI language, and spam-like patterns. Do not add facts, claims, links, guarantees, or a signature. Keep it 110-160 words. Return JSON exactly {"subject":"...","body":"..."}.
Current subject: ${JSON.stringify(subject)}
Current body: ${JSON.stringify(body)}
Region: ${JSON.stringify(campaign.region)}
Company: ${JSON.stringify({name:prospect.name,website:prospect.website,phone:prospect.phone,context:prospect.rawText})}
Opportunity: ${JSON.stringify(contract)}
Sender: ${JSON.stringify({name:sender.senderName,title:sender.senderTitle,company:sender.senderCompany})}`);
    subject=(rewrite.subject||subject).trim(); body=(rewrite.body||body).trim();
    review=deliverabilityReview(subject,body);
  }
  return {subject,body,review};
}
async function checkAI(){const s=await getState();const key=(s.settings.geminiApiKey||'').trim();if(!key)return {ok:false,configured:false,error:'Add your free Gemini API key in Settings.'};try{const r=await fetch('https://generativelanguage.googleapis.com/v1beta/openai/models',{headers:{Authorization:`Bearer ${key}`}});if(!r.ok)throw new Error(`Gemini rejected the key (${r.status}).`);return {ok:true,configured:true,model:s.settings.geminiModel||'gemini-3.5-flash-lite'}}catch(e){return {ok:false,configured:false,error:e.message}}}

function buildSignature(sender){const lines=[];if(sender.senderName)lines.push(sender.senderName);if(sender.senderTitle)lines.push(sender.senderTitle);const bits=[sender.senderEmail,sender.senderPhone,sender.senderWebsite].filter(Boolean);if(bits.length)lines.push(bits.join('  ·  '));return lines.join('\n')}
function draftPrompt(prospect,campaign,contract,sender){const region=campaign.region==='UK'?'UK':'US';const hasOpportunity=!!contract&&Object.keys(contract||{}).length>0;const regionalGuide=region==='UK'?'Use UK public-sector/tender terminology naturally. Position the sender as a tender/procurement consultant. If relevant and actually supported by the supplied data, mention tender response, method statements, PQQ/selection documentation, supporting documents, pricing schedules, or submission support.':'Use US government-contracting terminology naturally. Position the sender as a government-contracting consultant. If relevant and actually supported by the supplied data, mention solicitations/RFPs/RFQs, bid/proposal preparation, capability statements, SAM.gov/UEI-related preparation, supporting technical documentation, pricing, or submission support.';return `Create a high-conversion first-contact email for the following ${region} prospect. The objective is to earn a reply and start a real consulting conversation, not to sell aggressively. ${regionalGuide}

${hasOpportunity?'A SPECIFIC OPPORTUNITY IS PROVIDED. Lead with the opportunity and explain in plain English why it may be relevant to this company. Mention the buyer/client, service, location, scope, deadline, or other concrete detail only when supplied. Then briefly explain how the sender can help turn the opportunity into a bid/tender-ready submission.':'NO SPECIFIC OPPORTUNITY IS PROVIDED. Do not invent one. Introduce the sender as a consultant who helps businesses identify relevant contracts/tenders and handle the bid/tender process, then offer to identify suitable opportunities for this company.'}

Conversion structure: 1) a brief warm self-introduction -- who the sender is and what they do -- BEFORE any procurement/solicitation detail, never a cold open with a reference number or regulation; 2) concrete reason for contacting them, tied to the specific opportunity; 3) a genuine reason this specific kind of opportunity is worth pursuing for a business like theirs (steady/recurring revenue, a reliable government customer, predictable payment terms, a foot in the door with a bigger buyer -- whichever is true and relevant, never invented specifics about this exact deal's odds); 4) one or two ways the sender can help, each explicitly tied to the outcome/benefit it gives the recipient, not a bare task list; 5) a low-friction CTA offering something useful the recipient can simply say yes to over email -- pick ONE, and vary your choice across different prospects rather than reusing the same one: a short opportunity breakdown, a requirements summary, a fit check, a bid-readiness checklist, a shortlist of other relevant opportunities, or simply asking if more detail would be useful. Do NOT default to "would you be open to a quick call/conversation" -- only use a call/meeting as the CTA in a small minority of emails, and only when the supplied objective specifically calls for it. Most emails should close with a content offer, not a call request.

Sender (use only supplied details): ${JSON.stringify({name:sender.senderName,title:sender.senderTitle,company:sender.senderCompany})}
Prospect: ${JSON.stringify({name:prospect.name,website:prospect.website,phone:prospect.phone,context:prospect.rawText})}
Service/offer and tone: ${JSON.stringify({serviceContext:campaign.serviceContext,objective:campaign.objective,tone:campaign.tone})}
Opportunity/contract: ${JSON.stringify(contract)}

Write 110-160 words for the body, with a real self-introduction first, a genuine reason this opportunity is worth pursuing, and consultant help framed as a benefit rather than a task list. Use short paragraphs. Subject should normally be 5-9 words and specific to the opportunity/company without clickbait. Do not use generic openings, hype, false urgency, guarantees, fake personalization, or a long service list. Do not claim the recipient is eligible, selected, awarded, or connected to the buyer. Do not claim work was done beyond the supplied information. Do not add a signature. Return JSON exactly {"subject":"...","body":"..."}.`}
async function draft(p){const s=await getState();const sender=activeSender(s.campaign);if(!(sender.senderName||'').trim()||!(sender.senderCompany||'').trim())throw new Error(`Add your ${s.campaign.region} sender name and company in the Campaign tab first.`);const r=await geminiJson(draftPrompt(p,s.campaign,s.campaign.contract,sender));const safe=await spamSafeDraft(r,p,s.campaign,s.campaign.contract,sender);const sig=buildSignature(sender);return {subject:safe.subject,body:sig?`${safe.body}\n\n${sig}`:safe.body,deliverability:safe.review}}

// ---- Google Maps tab helpers ----
async function activeTab(){const ts=await chrome.tabs.query({active:true,currentWindow:true});return ts[0]}
function waitForTabLoad(tabId,timeout=15000){return new Promise((resolve,reject)=>{const start=Date.now();const check=async()=>{let tab;try{tab=await chrome.tabs.get(tabId)}catch(e){return reject(e)}if(tab.status==='complete')return resolve(tab);if(Date.now()-start>timeout)return reject(new Error('Timed out waiting for the page to load.'));setTimeout(check,300)};check()})}
async function collectVisibleBatch(tabId){const r=await chrome.tabs.sendMessage(tabId,{type:'EXTRACT_MAPS_LISTINGS'}).catch(()=>null);return {listings:r?.listings||[],endReached:!!r?.endReached}}
async function scrollForMore(tabId){
  // Keep the Maps tab active/focused before each scroll -- Chrome can
  // throttle lazy-load/scroll behaviour in tabs that sit inactive in the
  // background for a while, which would make exhaustive discovery quietly
  // slow to a crawl if the user switches to another tab mid-run.
  await chrome.tabs.update(tabId,{active:true}).catch(()=>{});
  const r=await chrome.tabs.sendMessage(tabId,{type:'SCROLL_MAPS_FEED'}).catch(()=>null);
  await new Promise(res=>setTimeout(res,2200));
  return r||null;
}
async function reloadMapsResults(tabId){
  const tab=await chrome.tabs.get(tabId);
  if(!tab?.url?.includes('google.com/maps')&&!tab?.url?.includes('maps.google.com')){
    throw new Error('The Google Maps search tab is no longer open.');
  }
  await chrome.tabs.reload(tabId,{bypassCache:false});
  await waitForTabLoad(tabId,20000);
  await new Promise(res=>setTimeout(res,2500));
}
function batchSignature(listings){return listings.map(l=>(l.mapsUrl||l.name||'').toLowerCase()).sort().join('|')}
// Google Maps shows review counts as "4.7(2,341)" or "4.7 (89)" right next
// to the star rating -- requiring a rating digit immediately before the
// parenthesized number is what keeps this from misreading a phone number's
// area code, e.g. "(555) 123-4567", as a review count.
function extractReviewCount(text){const m=(text||'').match(/\d(?:\.\d)?\s*\((\d{1,3}(?:,\d{3})*)\)/);if(!m)return null;return parseInt(m[1].replace(/,/g,''),10)}

// Finds an email on a company's website by opening it in a background tab
// (never focused/visible to the user) and scanning for a mailto: link or an
// email-shaped string in the page text. Tries the homepage first, then a
// couple of common contact-page paths as a fallback. Heuristic, not
// guaranteed -- many sites hide contact info behind a form instead of a
// plain email address.
async function scanTabForContactData(tabId){
  try{
    const results=await chrome.scripting.executeScript({target:{tabId},func:()=>{
      const normalize=(value)=>String(value||'').replace(/\s+/g,' ').trim();
      const candidates=[];
      const addEmail=(value)=>{
        let v=normalize(value).replace(/^mailto:/i,'').split('?')[0].trim();
        v=v.replace(/\s*\[at\]\s*/ig,'@').replace(/\s*\(at\)\s*/ig,'@').replace(/\s+at\s+/ig,'@').replace(/\s*\[dot\]\s*/ig,'.').replace(/\s*\(dot\)\s*/ig,'.').replace(/\s+dot\s+/ig,'.');
        const m=v.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i);
        if(m)candidates.push(m[0].toLowerCase());
      };
      document.querySelectorAll('a[href^="mailto:"]').forEach(a=>addEmail(a.getAttribute('href')||''));
      const text=normalize((document.body?.innerText||'')+'\n'+(document.documentElement?.innerHTML||''));
      (text.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi)||[]).forEach(addEmail);
      const obfuscated=text.match(/[A-Z0-9._%+-]+\s*(?:\[at\]|\(at\)|\bat\b)\s*[A-Z0-9.-]+\s*(?:\[dot\]|\(dot\)|\bdot\b)\s*[A-Z]{2,}/gi)||[];
      obfuscated.forEach(addEmail);
      const bad=/\.(png|jpg|jpeg|gif|svg|webp|css|js)$/i;
      const noise=/example\.(com|org)|sentry\.io|wixpress\.com|godaddy\.com|schema\.org/i;
      const email=[...new Set(candidates)].find(m=>!bad.test(m)&&!noise.test(m))||'';
      const links=[];
      const keywords=/contact|enquir|inquir|email|about|team|staff|get[ -]?in[ -]?touch|talk[ -]?to[ -]?us/i;
      document.querySelectorAll('a[href]').forEach(a=>{
        const href=a.href||''; const label=normalize(a.innerText||a.getAttribute('aria-label')||'');
        if(!href||href.startsWith('mailto:')||href.startsWith('tel:')||href.startsWith('javascript:'))return;
        try{
          const u=new URL(href,location.href);
          if(u.origin!==location.origin)return;
          if(keywords.test(label)||keywords.test(u.pathname))links.push(u.href);
        }catch{}
      });
      return {email,links:[...new Set(links)].slice(0,12)};
    }});
    return results?.[0]?.result||{email:'',links:[]};
  }catch{return {email:'',links:[]}}
}
// Backwards-compatible helper used elsewhere in the extension.
async function scanTabForEmail(tabId){const r=await scanTabForContactData(tabId);return r.email||''}
async function resolveWebsiteFromMaps(mapsUrl){
  if(!mapsUrl)return '';
  let tabId;
  try{
    const tab=await chrome.tabs.create({url:mapsUrl,active:false});
    tabId=tab.id;
    await waitForTabLoad(tabId,20000).catch(()=>{});
    // Maps sometimes renders the Website button a little after the detail page
    // itself has finished loading. Give it a few seconds, then try again.
    await new Promise(res=>setTimeout(res,3000));
    for(let attempt=0;attempt<3;attempt++){
      const r=await chrome.tabs.sendMessage(tabId,{type:'EXTRACT_WEBSITE_DETAIL'}).catch(()=>null);
      if(r?.website)return r.website;
      await new Promise(res=>setTimeout(res,1200));
    }
    return '';
  } finally {
    if(tabId)chrome.tabs.remove(tabId).catch(()=>{});
  }
}
// Fallback for businesses that either haven't linked a website on their
// Maps listing at all, or that DO have a real website but just haven't
// added it to their Maps profile yet. A plain Google search for the
// business name usually still finds their real site even when Maps
// doesn't have it.
const GOOGLE_RESULT_DOMAIN_BLOCKLIST=[
  'google.','maps.google','facebook.com','instagram.com','linkedin.com',
  'twitter.com','x.com','yelp.com','yellowpages.com','tripadvisor.',
  'indeed.com','glassdoor.','bbb.org','angi.com','angieslist.com',
  'thomsonlocal.com','yell.com','checkatrade.com','trustpilot.com',
  'foursquare.com','pinterest.','youtube.com','wikipedia.org',
  'crunchbase.com','bloomberg.com','opencorporates.com','companieshouse.gov.uk',
  'zoominfo.com','manta.com','bark.com','houzz.com','nextdoor.com',
  'apple.com/maps','bing.com/maps'
];
async function findWebsiteViaGoogleSearch(name,addressHint){
  if(!name)return '';
  const query=[name,addressHint||''].filter(Boolean).join(' ').trim();
  let tabId;
  try{
    const tab=await chrome.tabs.create({url:`https://www.google.com/search?q=${encodeURIComponent(query)}`,active:false});
    tabId=tab.id;
    await waitForTabLoad(tabId,15000).catch(()=>{});
    await new Promise(res=>setTimeout(res,1500));
    const [{result}={}]=await chrome.scripting.executeScript({
      target:{tabId},
      func:()=>{
        const out=[];
        document.querySelectorAll('a[href]').forEach(a=>{
          let href=a.getAttribute('href')||'';
          const m=href.match(/^\/url\?q=([^&]+)/);
          if(m)href=decodeURIComponent(m[1]);
          if(!/^https?:\/\//i.test(href))return;
          out.push(href);
        });
        return out;
      }
    }).catch(()=>[{result:[]}]);
    const links=Array.isArray(result)?result:[];
    for(const href of links){
      let host='';
      try{host=new URL(href).hostname.toLowerCase()}catch{continue}
      if(GOOGLE_RESULT_DOMAIN_BLOCKLIST.some(bad=>host.includes(bad)))continue;
      try{return new URL(href).origin}catch{continue}
    }
    return '';
  } finally {
    if(tabId)chrome.tabs.remove(tabId).catch(()=>{});
  }
}
async function findEmailOnWebsite(url){
  if(!url)return '';
  let tabId,origin;
  try{origin=new URL(url).origin}catch{return ''}
  try{
    const tab=await chrome.tabs.create({url,active:false});
    tabId=tab.id;
    await waitForTabLoad(tabId,15000).catch(()=>{});
    await new Promise(res=>setTimeout(res,1200));
    let data=await scanTabForContactData(tabId);
    if(data.email)return data.email;

    // First follow real internal contact/about links found on the homepage.
    // This catches sites where the email is not on the homepage at all.
    const discoveredLinks=Array.isArray(data.links)?data.links:[];
    const fallbackPaths=['/contact','/contact-us','/contact-us/','/contactus','/get-in-touch','/about/contact','/enquiries','/inquiries'];
    const urls=[]; const seen=new Set();
    for(const href of [...discoveredLinks,...fallbackPaths.map(path=>origin+path)]){
      try{
        const u=new URL(href,origin);
        if(u.origin!==origin)continue;
        const key=u.href.replace(/#.*$/,'');
        if(seen.has(key))continue; seen.add(key); urls.push(key);
      }catch{}
    }
    for(const candidate of urls.slice(0,10)){
      try{
        await chrome.tabs.update(tabId,{url:candidate});
        await waitForTabLoad(tabId,10000).catch(()=>{});
        await new Promise(res=>setTimeout(res,700));
        data=await scanTabForContactData(tabId);
        if(data.email)return data.email;
      }catch{}
    }
    return '';
  } finally {
    if(tabId)chrome.tabs.remove(tabId).catch(()=>{});
  }
}

// ---- Merging / dedup ----
// New listings start as 'discovered' (has a website, email not looked up
// yet) or 'skipped' (no website at all -- nothing to look up). Discovery
// later flips 'discovered' -> 'queued' (email found) or 'skipped' (not
// found). Re-collecting the same visible batch (which scrolling can do)
// never regresses a prospect's status once assigned.
function mergeListings(existing,listings,maxReviews){
  const map=new Map(existing.map(p=>[p.id,p]));
  for(const raw of listings){
    const id=idForMaps(raw);
    if(!map.has(id)){
      const reviewCount=extractReviewCount(raw.rawText);
      // Review count is informational only. Never discard a company merely
      // because it has more reviews than a previous setting. Every discovered
      // listing should be checked for a real website and email.
      const p={...raw,id,reviewCount,status:'discovered',skipReason:'',createdAt:Date.now()};
      map.set(id,p);
    } else {
      const old=map.get(id);
      map.set(id,{...old,name:raw.name||old.name,phone:raw.phone||old.phone,mapsUrl:raw.mapsUrl||old.mapsUrl,rawText:raw.rawText||old.rawText});
    }
  }
  return [...map.values()];
}
function nextAction(prospects){
  const discover=prospects.find(p=>p.status==='discovered'&&!p.suppressed);
  if(discover)return {type:'discover',prospect:discover};
  const send=prospects.find(p=>p.status==='queued'&&p.email&&!p.suppressed);
  if(send)return {type:'send',prospect:send};
  return null;
}

async function updateProgress(patch){const s=await getState();await save({outreach:{...s.outreach,...patch,updatedAt:Date.now()}})}
function randomDelay(min,max){const lo=Math.max(30,Number(min)||30),hi=Math.max(lo,Number(max)||lo);return (lo+Math.random()*(hi-lo))*1000}
async function scheduleJob(ms=0){await chrome.alarms.clear(JOB_ALARM);chrome.alarms.create(JOB_ALARM,{when:Date.now()+Math.max(0,ms)})}
async function scheduleRecovery(ms=60000){await chrome.alarms.clear(RECOVERY_ALARM);chrome.alarms.create(RECOVERY_ALARM,{when:Date.now()+Math.max(0,ms)})}
function hasPendingWork(s){return !!s.prospects?.some(p=>(p.status==='discovered'||p.status==='queued')&&!p.suppressed)}
async function checkForStalledOutreach(){
  const s=await getState(),o=s.outreach||{};
  if(s.paused||!hasPendingWork(s))return;
  const age=o.updatedAt?Date.now()-o.updatedAt:Infinity;
  if(o.running){
    if(age>=RECOVERY_STALE_MS){
      if((o.recoveryAttempts||0)>=MAX_RECOVERY_ATTEMPTS){
        await updateProgress({running:false,phase:'error',currentAction:'Automatic recovery stopped after several unsuccessful attempts. Click Start Automatic Outreach to continue.',lastResult:'Recovery attempt limit reached.'});
        return;
      }
      await save({outreach:{...o,running:true,recoveryAttempts:(o.recoveryAttempts||0)+1,lastRecoveryAt:Date.now(),currentAction:'Automatic outreach appears stalled. Attempting to resume…',updatedAt:Date.now()}});
      await scheduleJob(0);
    }
    return;
  }
  if(o.phase==='error' && (o.recoveryAttempts||0)<MAX_RECOVERY_ATTEMPTS){
    await save({outreach:{...o,running:true,recoveryAttempts:(o.recoveryAttempts||0)+1,lastRecoveryAt:Date.now(),currentAction:'Recovering interrupted automatic outreach…',updatedAt:Date.now()}});
    await scheduleJob(0);
  }
}

// Google Maps can temporarily stop loading new cards even though the search
// is still capable of returning more results. The old build treated one
// unchanged batch as the end of the search and required a manual restart.
// Keep discovery alive instead: make several scroll attempts, then reload the
// same Maps search tab and continue automatically. The user can still stop it
// at any time with Pause Sending.
// Google Maps' lazy-load genuinely gets slower the deeper you scroll into a
// large result set (more rendered DOM nodes, more virtualization overhead) --
// a big search can easily need real time to produce new cards even though
// it's nowhere near the actual end. A reload wipes ALL scroll progress
// (Maps is a single-page app -- there's no way to resume mid-list), so it
// must only ever fire as a genuine last resort for a truly hung page, never
// as a routine response to ordinary slow loading. These thresholds give a
// stalled search roughly 3-4 minutes of real, patient retrying before ever
// reloading -- previously this was under 20 seconds, which was reloading
// constantly and burning most of every run re-scrolling ground already
// covered instead of making forward progress.
const MAPS_SCROLL_RETRIES=5;
const MAPS_STALL_RETRY_MS=9000;
const MAPS_RELOAD_AFTER_STALLS=8;
const MAPS_RELOAD_RETRY_MS=8000;
function normalizedMapsSearchTerms(campaign){
  const raw=Array.isArray(campaign?.mapsSearchTerms)?campaign.mapsSearchTerms:[];
  const out=[]; const seen=new Set();
  for(const value of raw.slice(0,5)){
    const term=String(value||'').trim();
    if(!term)continue;
    const key=term.toLowerCase();
    if(seen.has(key))continue;
    seen.add(key);out.push(term);
  }
  return out;
}
function mapsSearchUrl(term){return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(term)}`;}
async function getOrCreateMapsTab(term){
  const active=await activeTab();
  if(active?.url?.includes('google.com/maps')||active?.url?.includes('maps.google.com'))return active;
  const existing=await chrome.tabs.query({url:['https://www.google.com/maps/*','https://maps.google.com/*']});
  if(existing?.length)return existing[0];
  return await chrome.tabs.create({url:mapsSearchUrl(term),active:true});
}
async function openMapsSearch(tabId,term){
  if(!tabId)throw new Error('The Google Maps search tab is no longer available.');
  await updateProgress({phase:'scrolling',currentSearchTerm:term,currentAction:`Opening Google Maps search "${term}" and waiting for it to fully load before reading anything…`});
  await chrome.tabs.update(tabId,{url:mapsSearchUrl(term),active:true});
  await waitForTabLoad(tabId,20000);
  // Extra settle time before the very first read of a new search -- the
  // results feed can still be populating for a moment even after the tab
  // itself reports "loaded", and strictly checking listings one by one only
  // means something if the list it's checking is actually complete.
  await new Promise(res=>setTimeout(res,4500));
}
async function beginNextMapsSearch(s,index,terms){
  const tab=await getOrCreateMapsTab(terms[index]);
  await openMapsSearch(tab.id,terms[index]);
  const batch=await collectVisibleBatch(tab.id);
  const listings=batch.listings;
  const latest=await getState();
  const prospects=mergeListings(latest.prospects,listings,latest.settings.maxReviews);
  await save({prospects,stats:{...latest.stats,found:prospects.length},outreach:{...latest.outreach,running:true,phase:'ready',mapsTabId:tab.id,multiSearchActive:true,mapsSearchIndex:index,mapsSearchTotal:terms.length,currentSearchTerm:terms[index],completedSearches:index,discoveryComplete:false,batches:Number(latest.outreach.batches||0)+1,rowsCollected:Number(latest.outreach.rowsCollected||0)+listings.length,lastBatchSignature:batchSignature(listings),mapsStallCount:0,currentAction:`Reading search ${index+1} of ${terms.length}: “${terms[index]}”. No emails will be sent until all searches are finished.`,updatedAt:Date.now()}});
  if(batch.endReached){await scheduleJob(0);return;}
  await scheduleJob(0);
}
async function finishOrAdvanceSearch(latest,listings,sig){
  const terms=normalizedMapsSearchTerms(latest.campaign);
  const idx=Number(latest.outreach.mapsSearchIndex||0);
  const prospects=mergeListings(latest.prospects,listings,latest.settings.maxReviews);
  if(latest.outreach.multiSearchActive && idx<terms.length-1){
    const nextIndex=idx+1;
    await save({prospects,stats:{...latest.stats,found:prospects.length},outreach:{...latest.outreach,running:true,phase:'ready',discoveryComplete:false,completedSearches:nextIndex,mapsSearchIndex:nextIndex,lastBatchSignature:sig,mapsStallCount:0,currentAction:`Finished search ${idx+1} of ${terms.length}. Moving to search ${nextIndex+1}: “${terms[nextIndex]}”…`,updatedAt:Date.now()}});
    await beginNextMapsSearch(latest,nextIndex,terms);
    return true;
  }
  await save({prospects,stats:{...latest.stats,found:prospects.length},outreach:{...latest.outreach,running:true,phase:'ready',discoveryComplete:true,completedSearches:terms.length||latest.outreach.completedSearches,mapsSearchIndex:Math.max(0,terms.length-1),lastBatchSignature:sig,mapsStallCount:0,currentAction:terms.length>1?`Finished all ${terms.length} Google Maps searches. ${prospects.filter(p=>p.status==='queued').length} companies are queued. Starting emails one by one…`:`Reached the end of the Google Maps results. ${prospects.filter(p=>p.status==='queued').length} companies are queued. Starting emails one by one…`,updatedAt:Date.now()}});
  await scheduleJob(0);
  return true;
}
async function advanceBatch(s){
  await updateProgress({phase:'scrolling',currentAction:'Reading more Google Maps listings before sending any emails…'});
  try{
    const tabId=s.outreach.mapsTabId;
    if(!tabId)throw new Error('The Google Maps search tab is no longer available.');
    let latest=await getState();
    let stallCount=Number(latest.outreach.mapsStallCount||0);
    for(let attempt=1;attempt<=MAPS_SCROLL_RETRIES;attempt++){
      await updateProgress({phase:'scrolling',currentAction:`Reading more companies from Google Maps… attempt ${attempt}/${MAPS_SCROLL_RETRIES}. No emails will be sent yet.`});
      await scrollForMore(tabId);
      const batch=await collectVisibleBatch(tabId);
      const listings=batch.listings;
      const sig=batchSignature(listings);
      if(batch.endReached){
        await finishOrAdvanceSearch(latest,listings,sig);
        return;
      }
      if(listings.length && sig!==latest.outreach.lastBatchSignature){
        const prospects=mergeListings(latest.prospects,listings,latest.settings.maxReviews);
        const batches=Number(latest.outreach.batches||0)+1;
        await save({prospects,stats:{...latest.stats,found:prospects.length},outreach:{...latest.outreach,running:true,phase:'ready',discoveryComplete:false,batches,rowsCollected:Number(latest.outreach.rowsCollected||0)+listings.length,lastBatchSignature:sig,mapsStallCount:0,currentAction:`Read another ${listings.length} visible listing(s) — ${prospects.length} companies queued/being prepared. Still scanning; no emails sent yet.`,updatedAt:Date.now()}});
        await scheduleJob(0); return;
      }
      latest=await getState();
    }
    stallCount+=1;
    if(stallCount>=MAPS_RELOAD_AFTER_STALLS){
      await updateProgress({phase:'scrolling',currentAction:'Google Maps has paused loading results — refreshing the search automatically to continue reading the list…'});
      await reloadMapsResults(tabId);
      const batch=await collectVisibleBatch(tabId); const afterReload=batch.listings; const reloadSig=batchSignature(afterReload); latest=await getState();
      if(batch.endReached){
        await finishOrAdvanceSearch(latest,afterReload,reloadSig);
        return;
      }
      if(afterReload.length && reloadSig!==latest.outreach.lastBatchSignature){
        const prospects=mergeListings(latest.prospects,afterReload,latest.settings.maxReviews); const batches=Number(latest.outreach.batches||0)+1;
        await save({prospects,stats:{...latest.stats,found:prospects.length},outreach:{...latest.outreach,running:true,phase:'ready',discoveryComplete:false,batches,rowsCollected:Number(latest.outreach.rowsCollected||0)+afterReload.length,lastBatchSignature:reloadSig,mapsStallCount:0,currentAction:`Google Maps refreshed and more listings were read — ${prospects.length} companies found so far. Still scanning; no emails sent yet.`,updatedAt:Date.now()}});
        await scheduleJob(0); return;
      }
      await save({outreach:{...latest.outreach,running:true,phase:'scrolling',discoveryComplete:false,mapsStallCount:0,currentAction:'Google Maps refreshed. Continuing to read the results before any emails are sent…',updatedAt:Date.now()}});
      await scheduleJob(MAPS_RELOAD_RETRY_MS); return;
    }
    await save({outreach:{...latest.outreach,running:true,phase:'scrolling',discoveryComplete:false,mapsStallCount:stallCount,currentAction:`No new listings yet. Google Maps will retry automatically in ${Math.round(MAPS_STALL_RETRY_MS/1000)} seconds…`,updatedAt:Date.now()}});
    await scheduleJob(MAPS_STALL_RETRY_MS);
  }catch(e){
    await updateProgress({running:false,phase:'error',currentCompany:'',currentEmail:'',currentAction:'Automatic outreach was interrupted. Recovery will retry automatically if there is remaining work.',lastResult:e.message,error:e.message});
    await scheduleRecovery(60000);
  }
}

async function startAutomaticOutreach(){
  const s=await getState();
  if(s.outreach.running)return {ok:true,message:'Automatic outreach is already running.'};
  if(!s.gmailConnected)throw new Error('Connect Gmail before starting automatic outreach.');
  const sender=activeSender(s.campaign);
  if(!(sender.senderName||'').trim()||!(sender.senderCompany||'').trim())throw new Error(`Add your ${s.campaign.region} sender name and company in the Campaign tab before starting.`);
  if(!s.campaign.contract?.title&&!s.campaign.contract?.scope)throw new Error('Add the opportunity/contract you\'re reaching out about first.');
  const terms=normalizedMapsSearchTerms(s.campaign);
  const resumableMulti=!!s.outreach.multiSearchActive&&terms.length>0&&Number(s.outreach.mapsSearchIndex||0)<terms.length;
  if(terms.length && s.outreach.discoveryComplete && hasPendingWork(s)){
    await save({paused:false,outreach:{...s.outreach,running:true,phase:'ready',currentAction:`All ${terms.length} Google Maps searches are already complete. Resuming the queued email processing…`,updatedAt:Date.now()}});
    await scheduleJob(0);
    return {ok:true,message:`All ${terms.length} Google Maps searches are already complete. Resuming the queued emails.`};
  }
  if(terms.length){
    const startIndex=resumableMulti?Number(s.outreach.mapsSearchIndex||0):0;
    const tab=await getOrCreateMapsTab(terms[startIndex]);
    if(!resumableMulti){
      await save({paused:false,outreach:{...DEFAULTS.outreach,running:true,phase:'scrolling',startedAt:Date.now(),updatedAt:Date.now(),currentAction:`Starting Google Maps search 1 of ${terms.length}: “${terms[0]}”…`,mapsTabId:tab.id,mapsStallCount:0,recoveryAttempts:0,lastRecoveryAt:null,discoveryComplete:false,multiSearchActive:true,mapsSearchIndex:0,mapsSearchTotal:terms.length,currentSearchTerm:terms[0],completedSearches:0}});
      try{await openMapsSearch(tab.id,terms[0]);const batch=await collectVisibleBatch(tab.id);const latest=await getState();const prospects=mergeListings(latest.prospects,batch.listings,latest.settings.maxReviews);await save({prospects,stats:{...latest.stats,found:prospects.length},outreach:{...latest.outreach,running:true,phase:'ready',mapsTabId:tab.id,batches:1,rowsCollected:batch.listings.length,lastBatchSignature:batchSignature(batch.listings),currentAction:`Reading search 1 of ${terms.length}: “${terms[0]}”. No emails will be sent until all searches are finished.`,updatedAt:Date.now()}});if(batch.endReached){await finishOrAdvanceSearch(await getState(),batch.listings,batchSignature(batch.listings));}else{await scheduleJob(0);}return {ok:true,message:`Started the 5-search queue. Reading search 1 of ${terms.length} first; the extension will move through each search before sending any email.`};}catch(e){await updateProgress({running:false,phase:'error',error:e.message,currentAction:'Automatic outreach was interrupted while opening the first Google Maps search.',lastResult:e.message});await scheduleRecovery(60000);throw e}
    }
    await save({paused:false,outreach:{...s.outreach,running:true,phase:'scrolling',mapsTabId:tab.id,mapsSearchTotal:terms.length,currentSearchTerm:terms[startIndex],discoveryComplete:false,updatedAt:Date.now(),currentAction:`Resuming search ${startIndex+1} of ${terms.length}: “${terms[startIndex]}”…`}});
    await scheduleJob(0);
    return {ok:true,message:`Resuming Google Maps search ${startIndex+1} of ${terms.length}.`};
  }
  const tab=await activeTab();
  if(!tab?.url?.includes('google.com/maps')&&!tab?.url?.includes('maps.google.com'))throw new Error('Open a Google Maps search results page first, or add Google Maps search terms in Campaign.');
  await save({paused:false,outreach:{...DEFAULTS.outreach,running:true,phase:'scrolling',startedAt:Date.now(),updatedAt:Date.now(),currentAction:'Reading visible Google Maps results…',mapsTabId:tab.id,mapsStallCount:0,recoveryAttempts:0,lastRecoveryAt:null,discoveryComplete:false}});
  try{
    const batch=await collectVisibleBatch(tab.id);
    const listings=batch.listings;
    const st=await getState();
    const prospects=mergeListings(st.prospects,listings,st.settings.maxReviews);
    const discoveryComplete=!!batch.endReached;
    await save({prospects,stats:{...st.stats,found:prospects.length},outreach:{...st.outreach,running:true,phase:'ready',batches:1,rowsCollected:listings.length,lastBatchSignature:batchSignature(listings),discoveryComplete,currentAction:discoveryComplete?`Reached the end of the Google Maps results. ${prospects.filter(p=>p.status==='queued').length} companies are queued. Starting emails one by one…`:`Read ${listings.length} companies on screen. Continuing through the Google Maps list before sending.`,updatedAt:Date.now()}});
    await scheduleJob(0);
    return {ok:true,message:discoveryComplete?`Started. Read the entire Maps result set (${listings.length} listings). Email queue is ready.`:`Started. Read ${listings.length} visible listings. The extension will finish reading the Google Maps results before sending any email.`};
  }catch(e){await updateProgress({running:false,phase:'error',error:e.message,currentAction:'Automatic outreach was interrupted. Recovery will retry automatically if there is remaining work.',lastResult:e.message});await scheduleRecovery(60000);throw e}
}
async function processAutomaticOne(){
  let s=await getState();
  if(!s.outreach.running)return;
  if(s.paused){await updateProgress({running:false,phase:'paused',currentAction:'Paused by user.'});return}
  const action=nextAction(s.prospects);
  if(!action){
    if(!s.outreach.discoveryComplete){await advanceBatch(s);return;}
    const sentToday=s.prospects.filter(p=>p.lastSentAt&&new Date(p.lastSentAt).toDateString()===new Date().toDateString()).length;
    if(sentToday>=s.campaign.dailyLimit){await updateProgress({running:false,phase:'limit',currentAction:`Daily limit reached (${s.campaign.dailyLimit}).`,lastResult:'Daily send limit reached.'});return;}
    await updateProgress({running:false,phase:'complete',currentCompany:'',currentEmail:'',currentAction:'Finished. Google Maps was read to the end and all queued emails have been processed.',lastResult:'Automatic outreach completed.'});
    return;
  }
  // Discovery phase may resolve websites/emails, but it is not allowed to send.
  if(!s.outreach.discoveryComplete && action.type==='send'){await advanceBatch(s);return;}
  if(s.outreach.discoveryComplete){
    const sentToday=s.prospects.filter(p=>p.lastSentAt&&new Date(p.lastSentAt).toDateString()===new Date().toDateString()).length;
    if(sentToday>=s.campaign.dailyLimit){await updateProgress({running:false,phase:'limit',currentAction:`Daily limit reached (${s.campaign.dailyLimit}).`,lastResult:'Daily send limit reached.'});return;}
  }
  if(action.type==='discover'){
    const p=action.prospect;
    let website=p.website;
    let websiteFoundVia='maps';
    if(!website){
      await updateProgress({phase:'finding_email',currentCompany:p.name,currentEmail:'',currentAction:`Opening ${p.name}'s Maps listing to find their website…`});
      try{website=await resolveWebsiteFromMaps(p.mapsUrl)}catch{website=''}
    }
    if(!website){
      // Not every real business has its website linked on its Maps listing --
      // some haven't added it there yet, some rely entirely on Maps/social for
      // discovery. Either way, a plain Google search for the business name
      // often still finds their actual site even when Maps doesn't have it.
      await updateProgress({phase:'finding_email',currentCompany:p.name,currentEmail:'',currentAction:`No website on ${p.name}'s Maps listing — searching Google directly…`});
      try{website=await findWebsiteViaGoogleSearch(p.name,s.outreach?.currentSearchTerm||'');websiteFoundVia='google_search'}catch{website=''}
    }
    if(!website){
      const latest=await getState();
      const prospects=latest.prospects.map(x=>x.id===p.id?{...x,status:'skipped',skipReason:'No website found on Maps or via a Google search',checkedAt:Date.now(),statusAt:Date.now()}:x);
      await save({prospects,outreach:{...latest.outreach,currentAction:`No website found for ${p.name} (checked Maps and Google) — skipped.`,recoveryAttempts:0,lastRecoveryAt:null,updatedAt:Date.now()}});
      await scheduleJob(1200);
      return;
    }
    await updateProgress({phase:'finding_email',currentCompany:p.name,currentEmail:'',currentAction:`Checking ${website} for an email…`});
    let email='';
    try{email=await findEmailOnWebsite(website)}catch{email=''}
    const latest=await getState();
    const prospects=latest.prospects.map(x=>x.id===p.id?{...x,website,email,websiteFoundVia,status:email?'queued':'skipped',skipReason:email?'':'No email found on the website',checkedAt:Date.now(),statusAt:email?Date.now():Date.now()}:x);
    await save({prospects,outreach:{...latest.outreach,currentAction:email?`Found an email for ${p.name}.`:`No email found for ${p.name} — skipped.`,recoveryAttempts:0,lastRecoveryAt:null,updatedAt:Date.now()}});
    await scheduleJob(1200);
    return;
  }
  const p=action.prospect;
  await updateProgress({phase:'preparing',currentCompany:p.name,currentEmail:p.email,currentAction:`Checking your plan before drafting for ${p.name}…`});
  try{
    await sbaCheckAndIncrementUsage();
  }catch(e){
    if(e.signedOutElsewhere){
      await updateProgress({running:false,phase:'signed_out',currentAction:`Stopped: signed in on another device. ${e.message}`,lastResult:e.message});
    }else if(e.limitReached){
      await updateProgress({running:false,phase:'limit',currentAction:`Stopped: ${e.message}`,lastResult:e.message});
    }else{
      await updateProgress({running:false,phase:'error',currentAction:`Stopped: ${e.message}`,lastResult:e.message,error:e.message});
    }
    return;
  }
  await updateProgress({phase:'preparing',currentCompany:p.name,currentEmail:p.email,currentAction:`Drafting an email for ${p.name}…`});
  try{
    const r=await draft(p);
    await updateProgress({phase:'preparing',currentAction:`Deliverability check passed (${r.deliverability?.score||100}/100) for ${p.name}…`});
    await new Promise(res=>setTimeout(res,350));
    await updateProgress({phase:'sending',currentAction:`Sending to ${p.name}…`});
    const trackingId=await createTracking(p,r.subject);
    const gmailResult=await gmailSend({to:p.email,subject:r.subject,body:r.body,trackingId});
    const latest=await getState();
    const sentAt=Date.now();
    await markTrackingSent(trackingId,sentAt,gmailResult?.id);
    const prospects=latest.prospects.map(x=>x.id===p.id?{...x,status:'active',lastSentAt:sentAt,statusAt:sentAt,lastSubject:r.subject,lastBody:r.body,deliverability:r.deliverability||null,trackingId:trackingId||x.trackingId||null,trackingIds:[...(Array.isArray(x.trackingIds)?x.trackingIds:[]),trackingId].filter(Boolean),followupStage:0,followupNextDueAt:null,followupCompleted:false,followupPaused:false,followupBaseSentAt:sentAt,followupStatus:'waiting for an open'}:x);
    await save({prospects,stats:{...latest.stats,sent:latest.stats.sent+1,sentToday:latest.stats.sentToday+1},outreach:{...latest.outreach,sent:latest.outreach.sent+1,processed:latest.outreach.processed+1,currentAction:`Sent to ${p.name}.`,lastResult:`Sent to ${p.name}.`,recoveryAttempts:0,lastRecoveryAt:null,updatedAt:Date.now()}});
  }catch(e){
    const latest=await getState();
    const prospects=latest.prospects.map(x=>x.id===p.id?{...x,status:'failed',lastError:e.message,statusAt:Date.now()}:x);
    await save({prospects,stats:{...latest.stats,failed:latest.stats.failed+1},outreach:{...latest.outreach,failed:latest.outreach.failed+1,processed:latest.outreach.processed+1,currentAction:`Failed for ${p.name}: ${e.message}`,lastResult:e.message,recoveryAttempts:0,lastRecoveryAt:null,updatedAt:Date.now()}});
  }
  const s2=await getState();
  await scheduleJob(randomDelay(s2.settings.minDelay,s2.settings.maxDelay));
}

async function clearUnsentProspects(){const s=await getState();const kept=s.prospects.filter(p=>p.lastSentAt);const removed=s.prospects.length-kept.length;await save({prospects:kept,stats:{...s.stats,found:kept.length}});return {message:`Removed ${removed} prospect(s) that hadn't been emailed yet. ${kept.length} already-contacted prospect(s) kept so they won't be emailed again.`}}
async function retryFailedProspects(){
  const s=await getState();
  let n=0;
  const prospects=s.prospects.map(p=>{
    if(p.status!=='failed')return p;
    n++;
    return {...p,status:'queued',lastError:'',statusAt:Date.now()};
  });
  if(!n)return {message:'No failed prospects to retry.'};
  await save({prospects,stats:{...s.stats,failed:Math.max(0,(s.stats.failed||0)-n)},outreach:{...s.outreach,failed:Math.max(0,(s.outreach.failed||0)-n)}});
  return {message:`${n} failed prospect(s) reset to queued. Start (or resume) Automatic Outreach to retry them.`};
}
async function resetEverything(){await save({prospects:[],stats:{found:0,sent:0,sentToday:0,sentTodayDate:'',failed:0,skipped:0},followups:{...DEFAULTS.followups,intervals:[3,7,14]},outreach:{...DEFAULTS.outreach},commitments:[],commitmentMonitor:{enabled:true,lastScanAt:null,lastScanCount:0,lastNewCount:0,lastError:'',scannedMessageIds:[],updatedAt:null}});return {message:'Cleared. Note: duplicate protection for previously emailed companies was also reset.'}}

chrome.runtime.onInstalled.addListener(async()=>{
  await getState();
  await chrome.alarms.create(RECOVERY_ALARM,{periodInMinutes:1});
  await chrome.alarms.create(UPDATE_CHECK_ALARM,{periodInMinutes:360});
  await chrome.alarms.create(FOLLOWUP_ALARM,{periodInMinutes:15});
  await chrome.alarms.create(TRACKING_ALARM,{periodInMinutes:1});
  await chrome.alarms.create(COMMITMENT_ALARM,{periodInMinutes:15});
});
chrome.runtime.onStartup?.addListener(async()=>{
  const s=await getState();
  await chrome.alarms.create(RECOVERY_ALARM,{periodInMinutes:1});
  await chrome.alarms.create(UPDATE_CHECK_ALARM,{periodInMinutes:360});
  await chrome.alarms.create(FOLLOWUP_ALARM,{periodInMinutes:15});
  await chrome.alarms.create(TRACKING_ALARM,{periodInMinutes:1});
  await chrome.alarms.create(COMMITMENT_ALARM,{periodInMinutes:15});
  if(s.outreach.running&&!s.paused)await scheduleJob(0);
  else if(s.outreach.phase==='error'&&!s.paused&&hasPendingWork(s))await scheduleRecovery(30000);
});
chrome.alarms.onAlarm.addListener(a=>{
  if(a.name===JOB_ALARM)processAutomaticOne().catch(async e=>{
    await updateProgress({running:false,phase:'error',currentAction:'Automatic outreach was interrupted. Recovery will retry automatically if there is remaining work.',error:e.message});
    await scheduleRecovery(60000);
  });
  if(a.name===RECOVERY_ALARM)checkForStalledOutreach().catch(()=>{});
  if(a.name===UPDATE_CHECK_ALARM)checkForUpdate().catch(()=>{});
  if(a.name===FOLLOWUP_ALARM)processDueFollowups().catch(()=>{});
  if(a.name===TRACKING_ALARM)syncTrackingEvents().catch(()=>{});
  if(a.name===COMMITMENT_ALARM)processCommitmentScan().catch(async e=>{const s=await getState();await save({commitmentMonitor:{...(s.commitmentMonitor||{}),lastError:e.message,lastScanAt:Date.now(),updatedAt:Date.now()}});});
});
// ---- Extension update checker ----
// ---- Open notifications ----
let trackingSyncInFlight=false;
async function notifyEmailOpen(row, prospect){
  const st=await getState();
  const prefs={enabled:true,desktop:true,email:true,...(st.openNotifications||{})};
  if(!prefs.enabled)return false;
  const recipient=row.recipient_email||prospect?.email||'Unknown recipient';
  const person=prospect?.contactName||prospect?.name||recipient;
  const company=prospect?.name&&prospect?.contactName?` at ${prospect.name}`:'';
  const subject=row.subject||prospect?.lastSubject||'(no subject)';
  const when=row.first_opened_at?new Date(row.first_opened_at).toLocaleString():new Date().toLocaleString();
  let emailSent=false;
  if(prefs.email){
    try{
      const account=st.gmailEmail||st.campaign?.us?.senderEmail||st.campaign?.uk?.senderEmail;
      if(account){
        const noteSubject=`Email opened: ${prospect?.name||recipient}`;
        const noteBody=`An open was detected for your outreach email.\n\nRecipient: ${person}${company}\nEmail: ${recipient}\nSubject: ${subject}\nFirst open detected: ${when}\n\nThis notification was generated by SBA Outreach Assistant. An email open indicates that the tracking image was requested; it does not guarantee that the recipient read the entire message.`;
        await gmailSend({to:account,subject:noteSubject,body:noteBody});
        emailSent=true;
      }
    }catch(e){ console.warn('Open notification email failed:',e); }
  }
  if(prefs.desktop){
    try{
      await chrome.notifications.create(`sba-open-${row.tracking_id}`,{
        type:'basic',
        iconUrl:'../icons/icon128.png',
        title:'SBA Outreach Assistant — Email opened',
        message:`${person}${company} opened your email.\nSubject: ${subject}`,
        priority:1
      });
    }catch(e){ console.warn('Desktop open notification failed:',e); }
  }
  return emailSent || prefs.desktop;
}

async function syncTrackingEvents(){
  if(trackingSyncInFlight)return;
  trackingSyncInFlight=true;
  try{
    const session=await sbaSession(); if(!session?.user?.id)return;
    const r=await sbaFetch(`${SBA_SUPABASE_URL}/rest/v1/email_tracking?user_id=eq.${encodeURIComponent(session.user.id)}&select=tracking_id,first_opened_at,last_opened_at,open_count,sent_at,gmail_message_id,recipient_email,subject`).catch(()=>null);
    if(!r?.ok)return; const rows=await r.json().catch(()=>[]); if(!Array.isArray(rows)||!rows.length)return;
    const byId=new Map(rows.map(x=>[x.tracking_id,x])); const st=await getState(); let changed=false;
    const newlyOpened=[];
    const prospects=st.prospects.map(p=>{
      const ids=[...(Array.isArray(p.trackingIds)?p.trackingIds:[]),p.trackingId].filter(Boolean);
      if(!ids.length)return p;
      const matched=ids.map(id=>byId.get(id)).filter(Boolean);
      if(!matched.length)return p;
      const opens=matched.filter(x=>Number(x.open_count||0)>0);
      const firsts=opens.map(x=>x.first_opened_at).filter(Boolean).sort();
      const lasts=opens.map(x=>x.last_opened_at).filter(Boolean).sort();
      const count=opens.reduce((n,x)=>n+Number(x.open_count||0),0);
      let n={...p,openCount:count,firstOpenedAt:firsts[0]||null,lastOpenedAt:lasts[lasts.length-1]||null};
      if(n.openCount!==p.openCount||n.firstOpenedAt!==p.firstOpenedAt||n.lastOpenedAt!==p.lastOpenedAt)changed=true;
      for(const row of opens){
        if(!p.openNotificationIds?.includes(row.tracking_id) && Number(row.open_count||0)>0 && row.first_opened_at){
          newlyOpened.push({row,prospect:p});
        }
      }
      if(st.followups.enabled && count>0 && p.lastSentAt && !p.followupCompleted && !p.followupPaused && !p.followupNextDueAt){
        const days=Number(st.followups.intervals?.[0]||3);
        n={...n,followupStage:0,followupNextDueAt:Number(p.followupBaseSentAt||p.lastSentAt)+days*86400000,followupStatus:'waiting'}; changed=true;
      }
      return n;
    });
    if(changed)await save({prospects});
    if(newlyOpened.length){
      let current=await getState();
      for(const item of newlyOpened){
        const ok=await notifyEmailOpen(item.row,item.prospect);
        if(ok){
          const ids=[...(current.prospects.find(x=>x.id===item.prospect.id)?.openNotificationIds||[]),item.row.tracking_id];
          const unique=[...new Set(ids)];
          const updated=current.prospects.map(x=>x.id===item.prospect.id?{...x,openNotificationIds:unique}:x);
          await save({prospects:updated}); current=await getState();
        }
      }
    }
  }finally{trackingSyncInFlight=false;}
}

async function gmailHasReply(prospect){
  if(!prospect?.email||!prospect?.lastSentAt)return false;
  try{
    const token=await gmailToken(false);
    const d=new Date(Number(prospect.lastSentAt)-86400000);
    const after=`${d.getUTCFullYear()}/${String(d.getUTCMonth()+1).padStart(2,'0')}/${String(d.getUTCDate()).padStart(2,'0')}`;
    const q=`from:${prospect.email} after:${after}`;
    const r=await fetch(`https://gmail.googleapis.com/gmail/v1/users/me/messages?q=${encodeURIComponent(q)}&maxResults=10`,{headers:{Authorization:`Bearer ${token}`}});
    if(!r.ok)return false;
    const data=await r.json();
    return Array.isArray(data.messages)&&data.messages.length>0;
  }catch{return false}
}

async function generateFollowup(prospect,stage){
  const s=await getState(); const sender=activeSender(s.campaign);
  const previous=prospect.lastSubject||'';
  const region=s.campaign.region==='UK'?'UK':'US'; const regional=region==='UK'?'Use natural UK tender/public-sector language.':'Use natural US government-contracting language.'; const r=await geminiJson(`Write follow-up #${stage+1} for a real consulting outreach conversation. ${regional} The goal is to earn a reply without sounding persistent or automated. Do not claim the recipient opened the previous email. Do not invent facts. If there is a specific opportunity, add one useful piece of context from it and remind the recipient what the consultant can help with (understanding requirements, bid/tender preparation, supporting/technical documents, and submission support) without listing everything. If there is no specific opportunity, reinforce that the sender can identify suitable contracts/tenders for the business. End with an easy CTA such as offering to send a short breakdown or a few relevant opportunities. Keep it 70-110 words, plain text, concise and human. Do not add a signature. Return JSON exactly {"subject":"...","body":"..."}. Recipient: ${JSON.stringify({name:prospect.contactName||prospect.name,company:prospect.name,email:prospect.email,website:prospect.website,context:prospect.rawText})} Original subject: ${JSON.stringify(previous)} Original email: ${JSON.stringify(prospect.lastBody||'')} Opportunity: ${JSON.stringify(s.campaign.contract)} Sender: ${JSON.stringify({name:sender.senderName,title:sender.senderTitle,company:sender.senderCompany})}`);
  const safe=await spamSafeDraft(r,prospect,s.campaign,s.campaign.contract,sender); const sig=buildSignature(sender);
  return {subject:safe.subject,body:sig?`${safe.body}\n\n${sig}`:safe.body,deliverability:safe.review};
}

async function processDueFollowups(){
  const s=await getState(); if(!s.followups.enabled)return;
  await syncTrackingEvents();
  let st=await getState();
  const now=Date.now();
  for(const p of st.prospects){
    if(!p.email||!p.lastSentAt||p.followupCompleted||p.followupPaused||!p.followupNextDueAt||p.followupNextDueAt>now)continue;
    if(s.followups.onlyOpened&&!Number(p.openCount||0)){continue;}
    if(s.followups.stopOnReply && await gmailHasReply(p)){
      const prospects=st.prospects.map(x=>x.id===p.id?{...x,followupPaused:true,followupStatus:'stopped — reply detected',followupNextDueAt:null}:x); await save({prospects}); st=await getState(); continue;
    }
    try{
      await sbaCheckAndIncrementUsage();
      const stage=Number(p.followupStage||0); const draft=await generateFollowup(p,stage); const trackingId=await createTracking(p,draft.subject);
      const result=await gmailSend({to:p.email,subject:draft.subject,body:draft.body,trackingId}); const sentAt=Date.now(); await markTrackingSent(trackingId,sentAt,result?.id);
      const intervals=st.followups.intervals||[3,7,14]; const nextIndex=stage+1; const hasNext=nextIndex<intervals.length;
      const prospects=st.prospects.map(x=>x.id===p.id?{...x,lastSentAt:sentAt,lastSubject:draft.subject,lastBody:draft.body,trackingIds:[...(Array.isArray(x.trackingIds)?x.trackingIds:[]),trackingId].filter(Boolean),followupStage:nextIndex,followupNextDueAt:hasNext?Number(x.followupBaseSentAt||sentAt)+Number(intervals[nextIndex])*86400000:null,followupCompleted:!hasNext,followupStatus:hasNext?`follow-up ${nextIndex} scheduled`:'sequence complete'}:x);
      await save({prospects,stats:{...st.stats,sent:st.stats.sent+1,sentToday:st.stats.sentToday+1}}); st=await getState();
    }catch(e){
      const prospects=st.prospects.map(x=>x.id===p.id?{...x,followupStatus:`failed: ${e.message}`,followupNextDueAt:null}:x); await save({prospects}); st=await getState();
    }
  }
}

async function getGmailTrackingForRow(messageId,subject,recipient){
  try{
    const fields='tracking_id,recipient_email,subject,gmail_message_id,sent_at,first_opened_at,last_opened_at,open_count';

    // 1) Most reliable: exact Gmail message ID.
    if(messageId){
      const r=await sbaFetch(`${SBA_SUPABASE_URL}/rest/v1/email_tracking?gmail_message_id=eq.${encodeURIComponent(messageId)}&select=${fields}&limit=1`).catch(()=>null);
      if(r?.ok){
        const rows=await r.json().catch(()=>[]);
        if(Array.isArray(rows)&&rows[0])return rows[0];
      }
    }

    // 2) Exact subject + recipient when Gmail exposes the recipient address.
    if(subject&&recipient){
      const email=String(recipient).trim().toLowerCase();
      const r=await sbaFetch(`${SBA_SUPABASE_URL}/rest/v1/email_tracking?recipient_email=eq.${encodeURIComponent(email)}&subject=eq.${encodeURIComponent(subject)}&select=${fields}&order=sent_at.desc&limit=1`).catch(()=>null);
      if(r?.ok){
        const rows=await r.json().catch(()=>[]);
        if(Array.isArray(rows)&&rows[0])return rows[0];
      }
    }

    // 3) Gmail Sent-list rows often expose the subject but not the recipient
    // email. Search by exact subject alone; RLS limits results to this user.
    if(subject){
      const r=await sbaFetch(`${SBA_SUPABASE_URL}/rest/v1/email_tracking?subject=eq.${encodeURIComponent(subject)}&select=${fields}&order=sent_at.desc&limit=1`).catch(()=>null);
      if(r?.ok){
        const rows=await r.json().catch(()=>[]);
        if(Array.isArray(rows)&&rows[0])return rows[0];
      }
    }
  }catch{}
  return null;
}

async function checkForUpdate(){
  try{
    const controller=new AbortController();
    const timer=setTimeout(()=>controller.abort(),8000);
    const r=await fetch(UPDATE_URL,{cache:'no-store',signal:controller.signal});
    clearTimeout(timer);
    if(!r.ok)return {ok:false};
    const data=await r.json();
    const current=chrome.runtime.getManifest().version;
    const latest=String(data.version||'').trim();
    if(!latest)return {ok:false};
    const compareVersions=(a,b)=>{
      const aa=String(a).split('.').map(x=>parseInt(x,10)||0),bb=String(b).split('.').map(x=>parseInt(x,10)||0);
      for(let i=0;i<Math.max(aa.length,bb.length);i++){if((aa[i]||0)!==(bb[i]||0))return (aa[i]||0)>(bb[i]||0)?1:-1;}
      return 0;
    };
    const result={ok:true,currentVersion:current,latestVersion:latest,newer:compareVersions(latest,current)>0,downloadUrl:data.downloadUrl||'https://dgtandassociatesuk.tech/extension/SBA-Outreach-Assistant-latest.zip',releaseNotes:data.releaseNotes||''};
    await chrome.storage.local.set({sba_update:result,sba_update_checked_at:Date.now()});
    return result;
  }catch(e){return {ok:false,error:e.message}}
}

chrome.runtime.onMessage.addListener((m,sr,send)=>{(async()=>{try{switch(m.type){
  case 'STATE':{await syncTrackingEvents().catch(()=>{});return {ok:true,...await getState()};}
  case 'CONNECT_GMAIL':return await connect();
  case 'CHECK_GMAIL':return await checkGmail();
  case 'CHECK_AI':return await checkAI();
  case 'START_AUTOMATIC':return await startAutomaticOutreach();
  case 'PAUSE':{const st=await getState();await save({paused:true,outreach:{...st.outreach,running:false,phase:'paused',currentAction:'Paused by user.',updatedAt:Date.now()}});await chrome.alarms.clear(JOB_ALARM);return {message:'Sending paused.'}}
  case 'ANALYZE_CONTRACT':{const analysis=await analyzeContractSource(m.source||'',m.file||null,m.region||'US');return {ok:true,analysis};}
  case 'SAVE_CAMPAIGN':{const current=await getState();const campaign={...DEFAULTS.campaign,...(m.campaign||{}),mapsSearchTerms:(Array.isArray(m.campaign?.mapsSearchTerms)?m.campaign.mapsSearchTerms:current.campaign.mapsSearchTerms||[]).slice(0,5).map(x=>String(x||'').trim())};const oldTerms=normalizedMapsSearchTerms(current.campaign),newTerms=normalizedMapsSearchTerms(campaign);const changed=JSON.stringify(oldTerms)!==JSON.stringify(newTerms);if(changed&&!current.outreach.running){await save({campaign,outreach:{...current.outreach,multiSearchActive:false,mapsSearchIndex:0,mapsSearchTotal:newTerms.length,currentSearchTerm:newTerms[0]||'',completedSearches:0,discoveryComplete:false,lastBatchSignature:'',mapsStallCount:0}});}else{await save({campaign});}return {message:changed?'Campaign and Google Maps search queue saved.':'Campaign saved.'};}
  case 'CHECK_CALENDAR':return await checkCalendar();
  case 'CONNECT_CALENDAR':return await connectCalendar();
  case 'SCAN_COMMITMENTS':return await processCommitmentScan({force:true});
  case 'ADD_COMMITMENT_TO_CALENDAR':return await addCommitmentToCalendar(m.id);
  case 'DISMISS_COMMITMENT':return await dismissCommitment(m.id);
  case 'SAVE_COMMITMENT_SETTINGS':{const current=await getState();const settings={...DEFAULTS.settings,...current.settings,commitmentScanEnabled:m.settings?.enabled!==false,commitmentLookbackDays:Math.max(1,Math.min(365,Number(m.settings?.lookbackDays)||30)),autoCalendarMeetings:m.settings?.autoCalendarMeetings!==false,calendarReminders:(Array.isArray(m.settings?.calendarReminders)?m.settings.calendarReminders:[180,60,30,10]).map(Number).filter(x=>x>=0).slice(0,5)};await save({settings,commitmentMonitor:{...(current.commitmentMonitor||{}),enabled:settings.commitmentScanEnabled}});return {message:'Commitment monitoring settings saved.',settings}}
  case 'SAVE_FOLLOWUPS':{const followups={enabled:!!m.followups?.enabled,onlyOpened:m.followups?.onlyOpened!==false,stopOnReply:m.followups?.stopOnReply!==false,intervals:(Array.isArray(m.followups?.intervals)?m.followups.intervals:[3,7,14]).map(Number).filter(x=>x>0).slice(0,5)};if(!followups.intervals.length)followups.intervals=[3,7,14];await save({followups});return {message:'Follow-up settings saved.',followups}}
  case 'SAVE_OPEN_NOTIFICATIONS':{const openNotifications={enabled:m.openNotifications?.enabled!==false,desktop:m.openNotifications?.desktop!==false,email:m.openNotifications?.email!==false};await save({openNotifications});return {message:'Open notification settings saved.',openNotifications}}
  case 'SAVE_SETTINGS':{const settings={...DEFAULTS.settings,...(m.settings||{})};settings.geminiApiKey=String(settings.geminiApiKey||'').trim();settings.geminiModel=String(settings.geminiModel||'gemini-3.5-flash-lite').trim()||'gemini-3.5-flash-lite';settings.minDelay=Math.max(0,Number(settings.minDelay)||30);settings.maxDelay=Math.max(settings.minDelay,Number(settings.maxDelay)||60);await save({settings});return {message:'Settings saved.',settings}}
  case 'DRAFT_INITIAL':return {ok:true,...await draft(m.prospect)};
  case 'CHECK_DELIVERABILITY':{const st=await getState();const sender=activeSender(st.campaign);const p=m.prospect||{};const safe=await spamSafeDraft({subject:m.subject,body:m.body},p,st.campaign,st.campaign.contract,sender);return {ok:true,...safe}};
  case 'SEND_MANUAL':{let p=m.prospect;if(!p?.email)throw new Error('Enter a recipient email first.');p={...p,id:p.id||('manual-'+crypto.randomUUID())};await sbaCheckAndIncrementUsage();const sender=activeSender((await getState()).campaign);const safe=await spamSafeDraft({subject:m.subject,body:m.body},p,(await getState()).campaign,(await getState()).campaign.contract,sender);if(safe.review.score<65)throw new Error(`Deliverability check blocked this email (${safe.review.score}/100). Rewrite the draft and try again.`);const trackingId=await createTracking(p,safe.subject);const gmailResult=await gmailSend({to:p.email,subject:safe.subject,body:safe.body,trackingId});const st=await getState();const sentAt=Date.now();await markTrackingSent(trackingId,sentAt,gmailResult?.id);const existing=st.prospects.find(x=>x.id===p.id||x.email?.toLowerCase()===p.email.toLowerCase());const saved={...p,status:'active',lastSentAt:sentAt,statusAt:sentAt,lastSubject:safe.subject,lastBody:safe.body,deliverability:safe.review,trackingId:trackingId||null,trackingIds:[...(Array.isArray(existing?.trackingIds)?existing.trackingIds:[]),trackingId].filter(Boolean),followupStage:0,followupNextDueAt:null,followupCompleted:false,followupPaused:false,followupBaseSentAt:sentAt};const prospects=existing?st.prospects.map(x=>x.id===existing.id?{...x,...saved,id:x.id}:x):[...st.prospects,saved];await save({prospects,stats:{...st.stats,sent:st.stats.sent+1,sentToday:st.stats.sentToday+1}});return {message:`Sent to ${p.name||p.email}.`,deliverability:safe.review}}
  case 'GET_ACCOUNT':return {ok:true,account:await sbaGetAccount()};
  case 'SUBMIT_PAYMENT':return await sbaSubmitPayment(m);
  case 'ADMIN_LIST_USERS':return {ok:true,users:await sbaAdminListUsers()};
  case 'ADMIN_SET_PLAN':return await sbaAdminSetPlan(m);
  case 'SBA_SIGN_OUT':return await sbaSignOut();
  case 'CLEAR_UNSENT':return await clearUnsentProspects();
  case 'RETRY_FAILED':return await retryFailedProspects();
  case 'RESET_ALL':return await resetEverything();
  case 'GET_GMAIL_ACCOUNT':{const st=await getState();let email=String(st.gmailEmail||'').trim().toLowerCase();if(!email){try{const token=await gmailToken(false);const r=await fetch('https://gmail.googleapis.com/gmail/v1/users/me/profile',{headers:{Authorization:`Bearer ${token}`}});if(r.ok){const d=await r.json();email=String(d.emailAddress||'').trim().toLowerCase();if(email)await save({gmailEmail:email,gmailConnected:true});}}catch{}}return {ok:true,email}}
  case 'GET_GMAIL_TRACKING':return {ok:true,tracking:await getGmailTrackingForRow(m.messageId||'',m.subject||'',m.recipient||'')};
  case 'CHECK_UPDATE':return await checkForUpdate();
  case 'GET_UPDATE_INFO':return (await chrome.storage.local.get('sba_update')).sba_update||await checkForUpdate();
  case 'OPEN_UPDATE':{const u=(await chrome.storage.local.get('sba_update')).sba_update;const url=u?.downloadUrl||'https://dgtandassociatesuk.tech/extension/SBA-Outreach-Assistant-latest.zip';await chrome.tabs.create({url});return {ok:true,url};}
  default:return {error:'Unknown action'}
  }}catch(e){return {ok:false,error:e.message,signedOutElsewhere:!!e.signedOutElsewhere,limitReached:!!e.limitReached}}})().then(send);return true});
